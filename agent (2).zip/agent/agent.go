package main

import (
	"encoding/json"
	"fmt"
	"strings"
	"time"
)

const (
	MAX_LOOPS = 30
)

func runAgentLoop() {
	loadMemory()
	loadTasks()
	loadChatSessions()
	for task := range taskQueue {
		auditLog("INFO", fmt.Sprintf("Task: %s", task))
		relevantContext := findRelevantMemories(task)
		messages := []Message{{Role: "system", Content: buildSystemPrompt()}}
		if len(relevantContext) > 0 {
			messages = append(messages, Message{
				Role:    "system",
				Content: fmt.Sprintf("RELEVANT MEMORY CONTEXT:\n%s", strings.Join(relevantContext, "\n")),
			})
			auditLog("CONTEXT", fmt.Sprintf("Injected %d memories.", len(relevantContext)))
		}
		messages = append(messages, Message{Role: "user", Content: task})
		chatRecorded := false
		for i := 0; i < MAX_LOOPS; i++ {
			response, err := chatWithMainLLM(messages)
			if err != nil {
				auditLog("ERROR", fmt.Sprintf("Main LLM Error: %v", err))
				mu.Lock()
				chatMessages = append(chatMessages, ChatMessage{Role: "agent",
					Content: fmt.Sprintf("I ran into an error: %v", err), Timestamp: time.Now()})
				mu.Unlock()
				chatRecorded = true
				break
			}
			response = strings.TrimSpace(response)
			response = strings.TrimPrefix(response, "```json")
			response = strings.TrimPrefix(response, "```")
			response = strings.TrimSuffix(response, "```")
			response = strings.TrimSpace(response)
			var parsed map[string]interface{}
			if err := json.Unmarshal([]byte(response), &parsed); err != nil {
				auditLog("INFO", "Non-JSON response — using as direct chat reply")
				mu.Lock()
				chatMessages = append(chatMessages, ChatMessage{Role: "agent", Content: response, Timestamp: time.Now()})
				mu.Unlock()
				chatRecorded = true
				messages = append(messages, Message{Role: "assistant", Content: response})
				break
			}
			if status, ok := parsed["status"].(string); ok && status == "complete" {
				summary := ""
				if s, ok2 := parsed["summary"].(string); ok2 {
					summary = s
				}
				if summary == "" {
					auditLog("INFO", "Empty summary — requesting explicit reply")
					messages = append(messages, Message{Role: "assistant", Content: response})
					messages = append(messages, Message{Role: "user",
						Content: `Your summary was empty. Respond with {"status":"complete","summary":"<your actual reply to the user here>"}`})
					continue
				}
				mu.Lock()
				chatMessages = append(chatMessages, ChatMessage{Role: "agent", Content: summary, Timestamp: time.Now()})
				mu.Unlock()
				chatRecorded = true
				mu.Lock()
				for j := len(tasksDb) - 1; j >= 0; j-- {
					if tasksDb[j].Status == "running" {
						tasksDb[j].Status = "complete"
						tasksDb[j].Result = truncate(summary, 200)
						tasksDb[j].UpdatedAt = time.Now()
						saveTasksLocked()
						break
					}
				}
				mu.Unlock()
				auditLog("SUCCESS", "Task Complete")
				break
			}
			toolName, ok := parsed["tool"].(string)
			if !ok {
				messages = append(messages, Message{Role: "user", Content: "Invalid format. Need 'tool' and 'arguments'."})
				continue
			}
			toolParams, _ := parsed["arguments"].(map[string]interface{})
			toolFunc, exists := tools[toolName]
			if !exists {
				messages = append(messages, Message{Role: "user", Content: fmt.Sprintf("Tool %s not found.", toolName)})
				continue
			}
			result := toolFunc(toolParams)
			messages = append(messages, Message{Role: "assistant", Content: response})
			messages = append(messages, Message{Role: "user", Content: fmt.Sprintf("Tool Result: %s", result)})
		}
		if !chatRecorded {
			auditLog("INFO", "No chat response recorded — requesting forced reply")
			messages = append(messages, Message{Role: "user",
				Content: `Summarize what you did and respond to the user. Reply ONLY as valid JSON: {"status":"complete","summary":"<your reply to the user>"}`})
			if fr, ferr := chatWithMainLLM(messages); ferr == nil {
				fr = strings.TrimSpace(strings.TrimSuffix(strings.TrimPrefix(strings.TrimPrefix(strings.TrimSpace(fr), "```json"), "```"), "```"))
				var fp map[string]interface{}
				if json.Unmarshal([]byte(fr), &fp) == nil {
					if s, ok := fp["summary"].(string); ok && s != "" {
						mu.Lock()
						chatMessages = append(chatMessages, ChatMessage{Role: "agent", Content: s, Timestamp: time.Now()})
						mu.Unlock()
					}
				} else if len(fr) > 4 {
					mu.Lock()
					chatMessages = append(chatMessages, ChatMessage{Role: "agent", Content: fr, Timestamp: time.Now()})
					mu.Unlock()
				}
			}
		}
	}
}

func findRelevantMemories(task string) []string {
	taskLower := strings.ToLower(task)
	stopWords := map[string]bool{"the": true, "is": true, "at": true, "which": true, "on": true, "a": true, "an": true, "and": true}
	var keywords []string
	for _, w := range strings.Fields(taskLower) {
		if len(w) > 3 && !stopWords[w] {
			keywords = append(keywords, w)
		}
	}
	var relevant []string
	mu.RLock()
	defer mu.RUnlock()
	for _, mem := range memoryDb {
		memLower := strings.ToLower(mem.Content)
		for _, kw := range keywords {
			if strings.Contains(memLower, kw) {
				relevant = append(relevant, fmt.Sprintf("- %s", mem.Content))
				break
			}
		}
	}
	return relevant
}

// buildSystemPrompt constructs the system prompt including expert LLM specialties.
func buildSystemPrompt() string {
	mu.RLock()
	personality := currentPersonality
	// Gather enabled expert LLMs and their specialties
	var expertLines []string
	if llm1Enabled && llm1Mode == "using" && llm1Specialty != "" {
		expertLines = append(expertLines, fmt.Sprintf("- LLM1 (tool: llm1): %s", llm1Specialty))
	}
	if llm2Enabled && llm2Mode == "using" && llm2Specialty != "" {
		expertLines = append(expertLines, fmt.Sprintf("- LLM2 (tool: llm2): %s", llm2Specialty))
	}
	if llm3Enabled && llm3Mode == "using" && llm3Specialty != "" {
		expertLines = append(expertLines, fmt.Sprintf("- LLM3 (tool: llm3): %s", llm3Specialty))
	}
	mu.RUnlock()

	const base = `
You are a fully autonomous AI agent with Long-Term Memory, a Task Management System, and a Maintenance Heartbeat.

CORE DIRECTIVES:
1. AUTONOMOUS MEMORY: Learn user preferences and project details immediately. Use 'store_memory'.
2. TASK MANAGEMENT: Use the task system to track work. Create tasks with 'create_task', update progress
   with 'update_task', and mark done with 'complete_task'. Never use files for task tracking.
3. HEARTBEAT MODE: Periodically (every 30 mins), use 'list_tasks' to find pending work and execute it.
4. DELEGATION: You have access to three expert LLMs with specific specialties. Delegate tasks to them when appropriate.
5. SPECIALISATION: Each expert LLM has a defined role. Use the right tool for the right job.

TOOLS:
1.  write_file (path, content): Write text to a file.
2.  read_file (path): Read file contents.
3.  list_directory (path): List files.
4.  run_command (command): Execute shell command. Full root access when host credentials are configured.
5.  store_memory (content, tags): Permanently store a fact. Tags: user_pref, project, config.
6.  recall_memory (query): Search stored memories.
7.  edit_own_code (search_string, replacement_string): Edit your own source code.
8.  llm1 (prompt): Delegate a task to LLM1. Use this when the task matches its specialty.
9.  llm2 (prompt): Delegate a task to LLM2.
10. llm3 (prompt): Delegate a task to LLM3.
11. create_task (title, description, priority): Add a new task. Priority: 1=high, 2=normal, 3=low.
12. list_tasks (status): List tasks filtered by status (pending/running/complete/failed/all).
13. update_task (id, status, result): Update a task's status and optionally set a result note.
14. complete_task (id, result): Mark a task complete with a result summary.
15. add_module (module_path, version): Add a Go module dependency.
16. remove_module (module_path): Remove a Go module dependency.
17. list_modules (): List all current Go module dependencies.
18. web_search (query): Search the web using the configured provider (DuckDuckGo/Google/Brave). Use this whenever you need current information, facts, news, or research.
19. fetch_url (url): Fetch and read the text content of any web page. Use after web_search to read full articles.
20. send_discord (message): Send a message to the configured Discord channel.
21. send_telegram (message): Send a message to the configured Telegram chat.
22. send_slack (message): Send a message to the configured Slack channel.
23. send_twitter (message): Post a tweet to Twitter/X.
24. send_whatsapp (message): Send a WhatsApp message via Twilio.

OUTPUT RULES:
- Respond ONLY in valid JSON. No markdown.
- Tool format: {"tool": "tool_name", "arguments": {"key": "value"}}
- Complete format: {"status": "complete", "summary": "text"}
- ALWAYS set "summary" in complete responses. This is shown directly to the user as your reply in the chat window. It must be a clear, helpful, human-readable response — not just "done". If the user asked a question, answer it in summary. If you did work, describe the result.
- FILE OUTPUTS: When writing generated content, code, or module outputs to disk, save them inside the documents/ folder. Use documents/code/ for code, documents/content/ for written content, documents/media/ for media, documents/modules/ for module-related files. Create subfolders as needed.
`

	prompt := base

	if len(expertLines) > 0 {
		prompt += "\n\nAVAILABLE EXPERT LLMs:\n" + strings.Join(expertLines, "\n") + "\n"
	}
	if personality != "" {
		prompt += "\n\nPERSONALITY & BEHAVIOR TRAITS (follow these strictly):\n" + personality + "\n"
	}
	return prompt
}