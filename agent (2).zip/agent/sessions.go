package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"time"
)

const (
	SESSIONS_FILE = "chat_sessions.json"
)

func loadChatSessions() {
	mu.Lock()
	defer mu.Unlock()
	data, err := os.ReadFile(SESSIONS_FILE)
	if err == nil {
		json.Unmarshal(data, &chatSessions)
	}
}

func saveChatSessionsLocked() {
	data, _ := json.MarshalIndent(chatSessions, "", "  ")
	os.WriteFile(SESSIONS_FILE, data, 0644)
}

func newChat() ChatSession {
	mu.Lock()
	defer mu.Unlock()
	sessionLogs := make([]AuditEntry, len(auditLogs))
	copy(sessionLogs, auditLogs)
	title := "Untitled Session"
	for _, entry := range sessionLogs {
		if entry.Level == "INFO" {
			title = entry.Content
			if len(title) > 60 {
				title = title[:60] + "..."
			}
			break
		}
	}
	session := ChatSession{
		ID:        len(chatSessions) + 1,
		Title:     title,
		CreatedAt: time.Now(),
		Logs:      sessionLogs,
	}
	chatSessions = append(chatSessions, session)
	saveChatSessionsLocked()
	auditLogs = []AuditEntry{}
	chatMessages = []ChatMessage{}
	return session
}

// HTTP handlers
func init() {
	http.HandleFunc("/api/sessions", func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		defer mu.RUnlock()
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(chatSessions)
	})

	http.HandleFunc("/api/new_chat", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "Invalid method", 405)
			return
		}
		session := newChat()
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(session)
		auditLog("SYSTEM", fmt.Sprintf("New chat started. Session #%d archived.", session.ID))
	})

	http.HandleFunc("/api/chat_messages", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		msgs := make([]ChatMessage, len(chatMessages))
		copy(msgs, chatMessages)
		mu.Unlock()
		if msgs == nil {
			msgs = []ChatMessage{}
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(msgs)
	})
}