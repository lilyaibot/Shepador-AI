package main

import (
	"bytes"
	"crypto/hmac"
	"crypto/sha1"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"sort"
	"strings"
	"time"
)

func init() {
	registerTool("send_discord", sendDiscord)
	registerTool("send_telegram", sendTelegram)
	registerTool("send_slack", sendSlack)
	registerTool("send_twitter", sendTwitter)
	registerTool("send_whatsapp", sendWhatsApp)
	http.HandleFunc("/api/social_config", socialConfigHandler)
	http.HandleFunc("/api/social_test", socialTestHandler)
}

func sendDiscord(params map[string]interface{}) string {
	msg, _ := params["message"].(string)
	if msg == "" {
		return "Error: 'message' required."
	}
	mu.RLock()
	token := discordToken
	channelID := discordChannelID
	mu.RUnlock()
	if token == "" || channelID == "" {
		return "Discord not configured. Set token and channel ID in the Social tab."
	}
	url := fmt.Sprintf("https://discord.com/api/v10/channels/%s/messages", channelID)
	payload, _ := json.Marshal(map[string]string{"content": msg})
	req, _ := http.NewRequest("POST", url, bytes.NewBuffer(payload))
	req.Header.Set("Authorization", "Bot "+token)
	req.Header.Set("Content-Type", "application/json")
	resp, err := (&http.Client{Timeout: 10 * time.Second}).Do(req)
	if err != nil {
		return fmt.Sprintf("Discord error: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 200 && resp.StatusCode < 300 {
		auditLog("SOCIAL", fmt.Sprintf("Discord message sent to channel %s", channelID))
		return "Discord message sent."
	}
	b, _ := io.ReadAll(resp.Body)
	return fmt.Sprintf("Discord error %d: %s", resp.StatusCode, string(b))
}

func sendTelegram(params map[string]interface{}) string {
	msg, _ := params["message"].(string)
	if msg == "" {
		return "Error: 'message' required."
	}
	mu.RLock()
	token := telegramToken
	chatID := telegramChatID
	mu.RUnlock()
	if token == "" || chatID == "" {
		return "Telegram not configured. Set token and chat ID in the Social tab."
	}
	url := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", token)
	payload, _ := json.Marshal(map[string]string{"chat_id": chatID, "text": msg, "parse_mode": "Markdown"})
	resp, err := (&http.Client{Timeout: 10 * time.Second}).Post(url, "application/json", bytes.NewBuffer(payload))
	if err != nil {
		return fmt.Sprintf("Telegram error: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode == 200 {
		auditLog("SOCIAL", fmt.Sprintf("Telegram message sent to chat %s", chatID))
		return "Telegram message sent."
	}
	b, _ := io.ReadAll(resp.Body)
	return fmt.Sprintf("Telegram error %d: %s", resp.StatusCode, string(b))
}

func sendSlack(params map[string]interface{}) string {
	msg, _ := params["message"].(string)
	if msg == "" {
		return "Error: 'message' required."
	}
	mu.RLock()
	token := slackToken
	channel := slackChannel
	mu.RUnlock()
	if token == "" || channel == "" {
		return "Slack not configured. Set token and channel in the Social tab."
	}
	payload, _ := json.Marshal(map[string]string{"channel": channel, "text": msg})
	req, _ := http.NewRequest("POST", "https://slack.com/api/chat.postMessage", bytes.NewBuffer(payload))
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")
	resp, err := (&http.Client{Timeout: 10 * time.Second}).Do(req)
	if err != nil {
		return fmt.Sprintf("Slack error: %v", err)
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	var result map[string]interface{}
	json.Unmarshal(b, &result)
	if ok, _ := result["ok"].(bool); ok {
		auditLog("SOCIAL", fmt.Sprintf("Slack message sent to %s", channel))
		return "Slack message sent."
	}
	return fmt.Sprintf("Slack error: %s", string(b))
}

func sendTwitter(params map[string]interface{}) string {
	msg, _ := params["message"].(string)
	if msg == "" {
		return "Error: 'message' required."
	}
	mu.RLock()
	consumerKey := twitterKey
	consumerSecret := twitterSecret
	accessToken := twitterToken
	accessSecret := twitterTokenSec
	mu.RUnlock()
	if consumerKey == "" || accessToken == "" {
		return "Twitter/X not configured. Set keys in the Social tab."
	}
	// Post tweet via Twitter API v2
	payload, _ := json.Marshal(map[string]string{"text": msg})
	req, _ := http.NewRequest("POST", "https://api.twitter.com/2/tweets", bytes.NewBuffer(payload))
	req.Header.Set("Content-Type", "application/json")
	// OAuth 1.0a header (simplified)
	authHeader := buildOAuth1Header("POST", "https://api.twitter.com/2/tweets",
		consumerKey, consumerSecret, accessToken, accessSecret)
	req.Header.Set("Authorization", authHeader)
	resp, err := (&http.Client{Timeout: 10 * time.Second}).Do(req)
	if err != nil {
		return fmt.Sprintf("Twitter error: %v", err)
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	if resp.StatusCode == 201 {
		auditLog("SOCIAL", "Tweet posted successfully")
		return "Tweet posted."
	}
	return fmt.Sprintf("Twitter error %d: %s", resp.StatusCode, string(b))
}

func sendWhatsApp(params map[string]interface{}) string {
	msg, _ := params["message"].(string)
	if msg == "" {
		return "Error: 'message' required."
	}
	mu.RLock()
	sid := whatsAppSID
	token := whatsAppToken
	from := whatsAppFrom
	to := whatsAppTo
	mu.RUnlock()
	if sid == "" || token == "" {
		return "WhatsApp not configured. Set Twilio credentials in the Social tab."
	}
	apiURL := fmt.Sprintf("https://api.twilio.com/2010-04-01/Accounts/%s/Messages.json", sid)
	formData := url.Values{}
	formData.Set("From", "whatsapp:"+from)
	formData.Set("To", "whatsapp:"+to)
	formData.Set("Body", msg)
	req, _ := http.NewRequest("POST", apiURL, strings.NewReader(formData.Encode()))
	req.SetBasicAuth(sid, token)
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	resp, err := (&http.Client{Timeout: 10 * time.Second}).Do(req)
	if err != nil {
		return fmt.Sprintf("WhatsApp error: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode == 201 {
		auditLog("SOCIAL", fmt.Sprintf("WhatsApp message sent to %s", to))
		return "WhatsApp message sent."
	}
	b, _ := io.ReadAll(resp.Body)
	return fmt.Sprintf("WhatsApp error %d: %s", resp.StatusCode, string(b))
}

// buildOAuth1Header builds a fully-signed OAuth 1.0a Authorization header.
// It computes the HMAC-SHA1 signature over the canonical parameter string,
// so Twitter/X v2 will accept it.
func buildOAuth1Header(method, apiURL, consumerKey, consumerSecret, token, tokenSecret string) string {
	ts := fmt.Sprintf("%d", time.Now().Unix())
	nonce := fmt.Sprintf("%x", time.Now().UnixNano())

	// Step 1 — collect the OAuth parameters (no signature yet)
	oauthParams := map[string]string{
		"oauth_consumer_key":     consumerKey,
		"oauth_nonce":            nonce,
		"oauth_signature_method": "HMAC-SHA1",
		"oauth_timestamp":        ts,
		"oauth_token":            token,
		"oauth_version":          "1.0",
	}

	// Step 2 — percent-encode key=value pairs and sort them
	var paramParts []string
	for k, v := range oauthParams {
		paramParts = append(paramParts, url.QueryEscape(k)+"="+url.QueryEscape(v))
	}
	sort.Strings(paramParts)
	paramString := strings.Join(paramParts, "&")

	// Step 3 — build the signature base string
	sigBase := strings.ToUpper(method) + "&" +
		url.QueryEscape(apiURL) + "&" +
		url.QueryEscape(paramString)

	// Step 4 — signing key is percent-encoded secrets joined by &
	signingKey := url.QueryEscape(consumerSecret) + "&" + url.QueryEscape(tokenSecret)

	// Step 5 — HMAC-SHA1, then base64
	mac := hmac.New(sha1.New, []byte(signingKey))
	mac.Write([]byte(sigBase))
	sig := base64.StdEncoding.EncodeToString(mac.Sum(nil))

	// Step 6 — add signature and build the Authorization header value
	oauthParams["oauth_signature"] = sig
	var headerParts []string
	for k, v := range oauthParams {
		headerParts = append(headerParts, url.QueryEscape(k)+`="`+url.QueryEscape(v)+`"`)
	}
	sort.Strings(headerParts)
	return "OAuth " + strings.Join(headerParts, ", ")
}

// HTTP handlers
func socialConfigHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method == "GET" {
		mu.RLock()
		data := map[string]interface{}{
			"discord_token":     maskKey(discordToken),
			"discord_channel":   discordChannelID,
			"twitter_key":       maskKey(twitterKey),
			"twitter_secret":    maskKey(twitterSecret),
			"twitter_token":     maskKey(twitterToken),
			"twitter_token_sec": maskKey(twitterTokenSec),
			"telegram_token":    maskKey(telegramToken),
			"telegram_chat_id":  telegramChatID,
			"slack_token":       maskKey(slackToken),
			"slack_channel":     slackChannel,
			"whatsapp_sid":      maskKey(whatsAppSID),
			"whatsapp_token":    maskKey(whatsAppToken),
			"whatsapp_from":     whatsAppFrom,
			"whatsapp_to":       whatsAppTo,
		}
		mu.RUnlock()
		json.NewEncoder(w).Encode(data)
		return
	}
	if r.Method == "POST" {
		var req struct {
			DiscordToken    string `json:"discord_token"`
			DiscordChannel  string `json:"discord_channel"`
			TwitterKey      string `json:"twitter_key"`
			TwitterSecret   string `json:"twitter_secret"`
			TwitterToken    string `json:"twitter_token"`
			TwitterTokenSec string `json:"twitter_token_sec"`
			TelegramToken   string `json:"telegram_token"`
			TelegramChatID  string `json:"telegram_chat_id"`
			SlackToken      string `json:"slack_token"`
			SlackChannel    string `json:"slack_channel"`
			WhatsAppSID     string `json:"whatsapp_sid"`
			WhatsAppToken   string `json:"whatsapp_token"`
			WhatsAppFrom    string `json:"whatsapp_from"`
			WhatsAppTo      string `json:"whatsapp_to"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		mu.Lock()
		discordChannelID = req.DiscordChannel
		telegramChatID = req.TelegramChatID
		slackChannel = req.SlackChannel
		whatsAppFrom = req.WhatsAppFrom
		whatsAppTo = req.WhatsAppTo
		if req.DiscordToken != "" && !isAllAsterisks(req.DiscordToken) {
			discordToken = req.DiscordToken
		}
		if req.TwitterKey != "" && !isAllAsterisks(req.TwitterKey) {
			twitterKey = req.TwitterKey
		}
		if req.TwitterSecret != "" && !isAllAsterisks(req.TwitterSecret) {
			twitterSecret = req.TwitterSecret
		}
		if req.TwitterToken != "" && !isAllAsterisks(req.TwitterToken) {
			twitterToken = req.TwitterToken
		}
		if req.TwitterTokenSec != "" && !isAllAsterisks(req.TwitterTokenSec) {
			twitterTokenSec = req.TwitterTokenSec
		}
		if req.TelegramToken != "" && !isAllAsterisks(req.TelegramToken) {
			telegramToken = req.TelegramToken
		}
		if req.SlackToken != "" && !isAllAsterisks(req.SlackToken) {
			slackToken = req.SlackToken
		}
		if req.WhatsAppSID != "" && !isAllAsterisks(req.WhatsAppSID) {
			whatsAppSID = req.WhatsAppSID
		}
		if req.WhatsAppToken != "" && !isAllAsterisks(req.WhatsAppToken) {
			whatsAppToken = req.WhatsAppToken
		}
		saveConfigLocked()
		mu.Unlock()
		auditLog("CONFIG", "Social credentials updated.")
		json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
		return
	}
	http.Error(w, "Invalid method", 405)
}

func socialTestHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Invalid method", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	var req struct {
		Platform string `json:"platform"`
		Message  string `json:"message"`
	}
	json.NewDecoder(r.Body).Decode(&req)
	if req.Message == "" {
		req.Message = "Test message from agent."
	}
	var result string
	switch req.Platform {
	case "discord":
		result = sendDiscord(map[string]interface{}{"message": req.Message})
	case "telegram":
		result = sendTelegram(map[string]interface{}{"message": req.Message})
	case "slack":
		result = sendSlack(map[string]interface{}{"message": req.Message})
	case "twitter":
		result = sendTwitter(map[string]interface{}{"message": req.Message})
	case "whatsapp":
		result = sendWhatsApp(map[string]interface{}{"message": req.Message})
	default:
		result = "Unknown platform: " + req.Platform
	}
	ok := !strings.HasPrefix(result, "Error") && !strings.Contains(result, "not configured") && !strings.Contains(result, "error")
	json.NewEncoder(w).Encode(map[string]interface{}{"result": result, "ok": ok})
}