package main

import (
	"encoding/json"
	"net/http"
	"strings"
)

func init() {
	http.HandleFunc("/api/op_llm_config", opLLMConfigHandler)
	http.HandleFunc("/api/op_llm_test", opLLMTestHandler)
}

func opLLMConfigHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method == "GET" {
		mu.RLock()
		data := map[string]interface{}{
			"url":         opLLMURL,
			"model":       opLLMModel,
			"key":         maskKey(opLLMKey),
			"enabled":     opLLMEnabled,
			"mode":        opLLMMode,
			"control_url": opLLMControlURL,
			"timeout":     llmTimeoutSec,
		}
		mu.RUnlock()
		json.NewEncoder(w).Encode(data)
		return
	}
	if r.Method == "POST" {
		var req struct {
			URL        string `json:"url"`
			Model      string `json:"model"`
			Key        string `json:"key"`
			Enabled    bool   `json:"enabled"`
			Mode       string `json:"mode"`
			ControlURL string `json:"control_url"`
			Timeout    int    `json:"timeout"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		mu.Lock()
		opLLMURL = strings.TrimRight(req.URL, "/")
		opLLMModel = req.Model
		if req.Key != "" && !isAllAsterisks(req.Key) {
			opLLMKey = req.Key
		}
		opLLMEnabled = req.Enabled
		opLLMMode = req.Mode
		opLLMControlURL = req.ControlURL
		if req.Timeout > 0 {
			llmTimeoutSec = req.Timeout
		}
		saveConfigLocked()
		mu.Unlock()
		auditLog("CONFIG", "Operational LLM updated.")
		json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
		return
	}
	http.Error(w, "Invalid method", 405)
}
func opLLMTestHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Invalid method", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	result, err := callOperationalLLM(
		"Reply with exactly one sentence confirming you are online and state your model name.",
		"You are a helpful assistant.",
	)
	if err != nil {
		json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		return
	}
	auditLog("CONFIG", "Operational LLM test connection successful.")
	json.NewEncoder(w).Encode(map[string]string{"response": result})
}
