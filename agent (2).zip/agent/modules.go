package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"strings"
	"time"
)

const (
	SOURCE_FILE = "agent.go" // used for edit_own_code and go mod workdir
)

type ModuleResult struct {
	Path     string `json:"path"`
	Synopsis string `json:"synopsis"`
	Version  string `json:"version"`
	License  string `json:"license"`
}

type InstalledModule struct {
	Path    string `json:"path"`
	Version string `json:"version"`
}

func init() {
	registerTool("add_module", addModule)
	registerTool("remove_module", removeModule)
	registerTool("list_modules", listModules)
	http.HandleFunc("/api/modules/search", modulesSearchHandler)
	http.HandleFunc("/api/modules/installed", modulesInstalledHandler)
	http.HandleFunc("/api/modules/add", modulesAddHandler)
	http.HandleFunc("/api/modules/remove", modulesRemoveHandler)
	http.HandleFunc("/api/modules/gomod", modulesGoModHandler)
}

func goModWorkDir() string {
	if _, err := os.Stat("go.mod"); err == nil {
		return "."
	}
	// Try directory of SOURCE_FILE
	dir := strings.TrimSuffix(SOURCE_FILE, "agent.go")
	if dir == "" {
		dir = "."
	}
	return dir
}

func addModule(params map[string]interface{}) string {
	modPath, _ := params["module_path"].(string)
	version, _ := params["version"].(string)
	if modPath == "" {
		return "Error: 'module_path' is required."
	}
	if version == "" {
		version = "latest"
	}
	spec := modPath + "@" + version
	auditLog("MODULE", fmt.Sprintf("Adding module: %s", spec))
	cmd := exec.Command("go", "get", spec)
	cmd.Dir = goModWorkDir()
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Sprintf("go get failed: %v\n%s", err, string(out))
	}
	exec.Command("go", "mod", "tidy").Run()
	auditLog("MODULE", fmt.Sprintf("Module added: %s", spec))
	// Snapshot go.mod to documents/modules/
	if modData, merr := os.ReadFile("go.mod"); merr == nil {
		timestamp := time.Now().Format("20060102-150405")
		os.WriteFile(docPath("modules", fmt.Sprintf("gomod_%s.txt", timestamp)), modData, 0644)
	}
	return fmt.Sprintf("Added %s\n%s", spec, strings.TrimSpace(string(out)))
}

func removeModule(params map[string]interface{}) string {
	modPath, _ := params["module_path"].(string)
	if modPath == "" {
		return "Error: 'module_path' is required."
	}
	auditLog("MODULE", fmt.Sprintf("Removing module: %s", modPath))
	cmd := exec.Command("go", "get", modPath+"@none")
	cmd.Dir = goModWorkDir()
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Sprintf("go get @none failed: %v\n%s", err, string(out))
	}
	exec.Command("go", "mod", "tidy").Run()
	auditLog("MODULE", fmt.Sprintf("Module removed: %s", modPath))
	return fmt.Sprintf("Removed %s\n%s", modPath, strings.TrimSpace(string(out)))
}

func listModules(params map[string]interface{}) string {
	cmd := exec.Command("go", "list", "-m", "all")
	cmd.Dir = goModWorkDir()
	out, err := cmd.CombinedOutput()
	if err != nil {
		data, ferr := os.ReadFile("go.mod")
		if ferr != nil {
			return fmt.Sprintf("Error listing modules: %v", err)
		}
		return string(data)
	}
	return strings.TrimSpace(string(out))
}

func readGoMod() string {
	data, err := os.ReadFile("go.mod")
	if err != nil {
		return ""
	}
	return string(data)
}

func searchGoPackages(query string) ([]ModuleResult, error) {
	url := "https://pkg.go.dev/search?q=" + strings.ReplaceAll(query, " ", "+") + "&m=package"
	client := &http.Client{Timeout: 15 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return nil, fmt.Errorf("search request failed: %v", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	html := string(body)

	var results []ModuleResult
	searchStart := `<div class="SearchSnippet"`
	pos := 0
	for {
		idx := strings.Index(html[pos:], searchStart)
		if idx < 0 || len(results) >= 12 {
			break
		}
		pos += idx
		end := strings.Index(html[pos+len(searchStart):], searchStart)
		var block string
		if end < 0 {
			block = html[pos:]
		} else {
			block = html[pos : pos+len(searchStart)+end]
		}
		pos += len(searchStart)

		r := ModuleResult{}

		if hIdx := strings.Index(block, `href="/`); hIdx >= 0 {
			sub := block[hIdx+7:]
			if eIdx := strings.IndexAny(sub, `"?#`); eIdx >= 0 {
				candidate := sub[:eIdx]
				if strings.Contains(candidate, ".") && !strings.HasPrefix(candidate, "?") &&
					candidate != "pkg.go.dev" && !strings.HasPrefix(candidate, "about") &&
					!strings.HasPrefix(candidate, "account") && !strings.HasPrefix(candidate, "search") {
					r.Path = candidate
				}
			}
		}
		if r.Path == "" {
			continue
		}

		synTag := `SearchSnippet-synopsis`
		if sIdx := strings.Index(block, synTag); sIdx >= 0 {
			sub := block[sIdx:]
			if oIdx := strings.Index(sub, ">"); oIdx >= 0 {
				sub = sub[oIdx+1:]
				if cIdx := strings.Index(sub, "<"); cIdx >= 0 {
					r.Synopsis = strings.TrimSpace(sub[:cIdx])
				}
			}
		}

		if vIdx := strings.Index(block, `Version`); vIdx >= 0 {
			sub := block[vIdx:]
			if oIdx := strings.Index(sub, ">"); oIdx >= 0 {
				sub = sub[oIdx+1:]
				if cIdx := strings.Index(sub, "<"); cIdx >= 0 {
					v := strings.TrimSpace(sub[:cIdx])
					if strings.HasPrefix(v, "v") {
						r.Version = v
					}
				}
			}
		}

		if lIdx := strings.Index(block, `License`); lIdx >= 0 {
			sub := block[lIdx:]
			if oIdx := strings.Index(sub, ">"); oIdx >= 0 {
				sub = sub[oIdx+1:]
				if cIdx := strings.Index(sub, "<"); cIdx >= 0 {
					r.License = strings.TrimSpace(sub[:cIdx])
				}
			}
		}
		results = append(results, r)
	}
	return results, nil
}

func getInstalledModules() []InstalledModule {
	data, err := os.ReadFile("go.mod")
	if err != nil {
		return []InstalledModule{}
	}
	var mods []InstalledModule
	lines := strings.Split(string(data), "\n")
	inRequire := false
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "require (" {
			inRequire = true
			continue
		}
		if inRequire && line == ")" {
			inRequire = false
			continue
		}
		if inRequire || strings.HasPrefix(line, "require ") {
			parts := strings.Fields(strings.TrimPrefix(line, "require "))
			if len(parts) >= 2 {
				mods = append(mods, InstalledModule{Path: parts[0], Version: parts[1]})
			}
		}
	}
	return mods
}

// HTTP handlers
func modulesSearchHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	q := r.URL.Query().Get("q")
	if q == "" {
		json.NewEncoder(w).Encode(map[string]interface{}{"results": []interface{}{}})
		return
	}
	results, err := searchGoPackages(q)
	if err != nil {
		json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		return
	}
	json.NewEncoder(w).Encode(map[string]interface{}{"results": results})
}

func modulesInstalledHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	mods := getInstalledModules()
	json.NewEncoder(w).Encode(map[string]interface{}{"modules": mods})
}

func modulesAddHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Invalid method", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	var req struct {
		ModulePath string `json:"module_path"`
		Version    string `json:"version"`
	}
	json.NewDecoder(r.Body).Decode(&req)
	if req.ModulePath == "" {
		json.NewEncoder(w).Encode(map[string]string{"error": "module_path required"})
		return
	}
	if req.Version == "" {
		req.Version = "latest"
	}
	result := addModule(map[string]interface{}{"module_path": req.ModulePath, "version": req.Version})
	if strings.HasPrefix(result, "go get failed") || strings.HasPrefix(result, "Error") {
		json.NewEncoder(w).Encode(map[string]string{"error": result})
		return
	}
	json.NewEncoder(w).Encode(map[string]string{"status": "ok", "output": result})
}

func modulesRemoveHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Invalid method", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	var req struct {
		ModulePath string `json:"module_path"`
	}
	json.NewDecoder(r.Body).Decode(&req)
	if req.ModulePath == "" {
		json.NewEncoder(w).Encode(map[string]string{"error": "module_path required"})
		return
	}
	result := removeModule(map[string]interface{}{"module_path": req.ModulePath})
	if strings.HasPrefix(result, "go get") || strings.HasPrefix(result, "Error") {
		json.NewEncoder(w).Encode(map[string]string{"error": result})
		return
	}
	json.NewEncoder(w).Encode(map[string]string{"status": "ok", "output": result})
}

func modulesGoModHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	content := readGoMod()
	json.NewEncoder(w).Encode(map[string]string{"content": content})
}