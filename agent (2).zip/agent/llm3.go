package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strings"
	"time"
)

func init() {
	registerTool("llm3", llm3Tool)
	http.HandleFunc("/api/llm3_config", llm3ConfigHandler)
	http.HandleFunc("/api/llm3_test", llm3TestHandler)
}

func llm3Tool(params map[string]interface{}) string {
	prompt, _ := params["prompt"].(string)
	if prompt == "" {
		return "Error: 'prompt' argument is required."
	}
	mu.RLock()
	specialty := llm3Specialty
	mu.RUnlock()

	auditLog("LLM3", fmt.Sprintf("Delegating to LLM3 (%s): %s", specialty, truncate(prompt, 80)))
	system := "You are an expert AI. " + specialty
	result, err := callExpertLLM(3, prompt, system)
	if err != nil {
		auditLog("ERROR", fmt.Sprintf("LLM3 error: %v", err))
		return fmt.Sprintf("LLM3 Error: %v", err)
	}
	auditLog("LLM3", fmt.Sprintf("LLM3 responded (%d chars)", len(result)))
	// Save output to documents/llm3/
	timestamp := time.Now().Format("20060102-150405")
	outFile := docPath("llm3", fmt.Sprintf("llm3_%s.md", timestamp))
	os.WriteFile(outFile, []byte(fmt.Sprintf("# LLM3 Output\n**Prompt:** %s\n\n%s", truncate(prompt, 200), result)), 0644)
	auditLog("LLM3", fmt.Sprintf("Saved to %s", outFile))
	return result
}

func llm3ConfigHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method == "GET" {
		mu.Lock()
		data := map[string]interface{}{
			"url":         llm3URL,
			"model":       llm3Model,
			"key":         maskKey(llm3Key),
			"specialty":   llm3Specialty,
			"enabled":     llm3Enabled,
			"mode":        llm3Mode,
			"control_url": llm3ControlURL,
			"timeout":     llmTimeoutSec,
		}
		mu.RUnlock()
		json.NewEncoder(w).Encode(data)
		return
	}
	if r.Method == "POST" {
		var req struct {
			URL        string `json:"url"`
			Model      string `json:"model"`
			Key        string `json:"key"`
			Specialty  string `json:"specialty"`
			Enabled    bool   `json:"enabled"`
			Mode       string `json:"mode"`
			ControlURL string `json:"control_url"`
			Timeout    int    `json:"timeout"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		mu.Lock()
		llm3URL = strings.TrimRight(req.URL, "/")
		llm3Model = req.Model
		if req.Key != "" && !isAllAsterisks(req.Key) {
			llm3Key = req.Key
		}
		llm3Specialty = req.Specialty
		llm3Enabled = req.Enabled
		llm3Mode = req.Mode
		llm3ControlURL = req.ControlURL
		if req.Timeout > 0 {
			llmTimeoutSec = req.Timeout
		}
		saveConfigLocked()
		mu.Unlock()
		auditLog("CONFIG", fmt.Sprintf("LLM3 updated: specialty=%s enabled=%v mode=%s", req.Specialty, req.Enabled, req.Mode))
		json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
		return
	}
	http.Error(w, "Invalid method", 405)
}

func llm3TestHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Invalid method", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	result, err := callExpertLLM(3, "Reply with exactly one sentence confirming you are online and state your model name.", "You are a helpful assistant.")
	if err != nil {
		json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		return
	}
	auditLog("LLM3", "Test connection successful.")
	json.NewEncoder(w).Encode(map[string]string{"response": result})
}