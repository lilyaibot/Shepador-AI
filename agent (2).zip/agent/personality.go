package main

import (
	"encoding/json"
	"net/http"
)

func init() {
	http.HandleFunc("/api/personality", personalityHandler)
}

func personalityHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method == "GET" {
		mu.RLock()
		p := currentPersonality
		mu.RUnlock()
		json.NewEncoder(w).Encode(map[string]string{"personality": p})
		return
	}
	if r.Method == "POST" {
		var req struct{ Personality string `json:"personality"` }
		json.NewDecoder(r.Body).Decode(&req)
		mu.Lock()
		currentPersonality = req.Personality
		saveConfigLocked()
		mu.Unlock()
		auditLog("CONFIG", "Personality updated.")
		json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
		return
	}
	http.Error(w, "Invalid method", 405)
}