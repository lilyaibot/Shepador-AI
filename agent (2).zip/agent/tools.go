package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

const (
	DOCS_DIR = "documents"
)

// ensureDocDir creates documents/<subdir> and returns full path for output files
func ensureDocDir(subdir string) string {
	dir := filepath.Join(DOCS_DIR, subdir)
	os.MkdirAll(dir, 0755)
	return dir
}

// docPath returns a path inside documents/<subdir>/<filename>
func docPath(subdir, filename string) string {
	return filepath.Join(ensureDocDir(subdir), filename)
}

func writeFile(params map[string]interface{}) string {
	path, _ := params["path"].(string)
	content, _ := params["content"].(string)
	auditLog("ACTION", fmt.Sprintf("Writing: %s", path))
	if err := os.WriteFile(path, []byte(content), 0644); err != nil {
		return fmt.Sprintf("Error: %v", err)
	}
	return "Success"
}

func readFile(params map[string]interface{}) string {
	path, _ := params["path"].(string)
	auditLog("ACTION", fmt.Sprintf("Reading: %s", path))
	content, err := os.ReadFile(path)
	if err != nil {
		return fmt.Sprintf("Error: %v", err)
	}
	return string(content)
}

func runCommand(params map[string]interface{}) string {
	cmdStr, _ := params["command"].(string)
	if strings.Contains(cmdStr, "kill") && strings.Contains(cmdStr, "agent") {
		return "Refusing self-termination."
	}

	mu.RLock()
	user, pass := hostUser, hostPass
	mu.RUnlock()

	var cmd *exec.Cmd
	if pass != "" {
		rootUser := user
		if rootUser == "" {
			rootUser = "root"
		}
		wrapped := fmt.Sprintf("echo %s | sudo -S -u %s bash -c %s",
			shellQuote(pass), shellQuote(rootUser), shellQuote(cmdStr))
		auditLog("ACTION", fmt.Sprintf("Exec (as %s): %s", rootUser, cmdStr))
		cmd = exec.Command("bash", "-c", wrapped)
	} else {
		auditLog("ACTION", fmt.Sprintf("Exec: %s", cmdStr))
		cmd = exec.Command("bash", "-c", cmdStr)
	}

	output, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Sprintf("Cmd Failed: %v\nOutput: %s", err, string(output))
	}
	return string(output)
}

func editOwnCode(params map[string]interface{}) string {
	search, _ := params["search_string"].(string)
	replacement, _ := params["replacement_string"].(string)
	if search == "" {
		return "Error: 'search_string' is required."
	}
	auditLog("MODIFICATION", "Searching source files for edit target...")

	goFiles, err := filepath.Glob("*.go")
	if err != nil || len(goFiles) == 0 {
		return "Error: no .go source files found in working directory."
	}

	for _, filename := range goFiles {
		content, err := os.ReadFile(filename)
		if err != nil {
			continue
		}
		if !strings.Contains(string(content), search) {
			continue
		}
		newContent := strings.Replace(string(content), search, replacement, 1)
		// Write backup first
		if werr := os.WriteFile(filename+".bak", content, 0644); werr != nil {
			return fmt.Sprintf("Error writing backup for %s: %v", filename, werr)
		}
		if werr := os.WriteFile(filename, []byte(newContent), 0644); werr != nil {
			return fmt.Sprintf("Error writing %s: %v", filename, werr)
		}
		auditLog("SUCCESS", fmt.Sprintf("Code updated in %s.", filename))
		return fmt.Sprintf("Code updated successfully in %s.", filename)
	}
	return fmt.Sprintf("Search string not found in any of %d .go source files.", len(goFiles))
}

func init() {
	registerTool("write_file", writeFile)
	registerTool("read_file", readFile)
	registerTool("run_command", runCommand)
	registerTool("list_directory", func(p map[string]interface{}) string {
		return "Use run_command 'ls -la'"
	})
	registerTool("edit_own_code", editOwnCode)
}