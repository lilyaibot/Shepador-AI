package main

const htmlTemplate = `<!DOCTYPE html>
<html>
<head>
    <title>__TITLE__</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', sans-serif; background: #1a1a1a; color: #d4d4d4; height: 100vh; display: flex; flex-direction: column; overflow: hidden; }

        /* ── HEADER ── */
        .header { background: #252526; border-bottom: 1px solid #333; padding: 8px 16px; display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
        .header h1 { font-size: 1rem; color: #fff; letter-spacing: 0.05em; white-space: nowrap; }
        .header-badges { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; flex: 1; }
        .status-dot { height: 9px; width: 9px; background: #4ec9b0; border-radius: 50%; display: inline-block; animation: pulse 2s infinite; flex-shrink: 0; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.3} }
        .header-badge { font-size: 0.68rem; padding: 2px 7px; border-radius: 10px; font-weight: bold; white-space: nowrap; }
        .hb-main      { background: #0e3a5a; color: #4fc1ff; border: 1px solid #1177bb; }
        .hb-llm1      { background: #2d1a4a; color: #c586c0; border: 1px solid #5a2d82; }
        .hb-llm2      { background: #1a3a2a; color: #44aa88; border: 1px solid #2a6a4a; }
        .hb-llm3      { background: #3a1a3a; color: #c586c0; border: 1px solid #5a2d82; }
        .hb-opllm     { background: #1a2a3a; color: #4fc1ff; border: 1px solid #1177bb; }
        .hb-off       { background: #2a2a2a; color: #555;    border: 1px solid #444; }
        .hb-root      { background: #3a1a1a; color: #f44747; border: 1px solid #7a1e1e; }
        .hb-task-pend { background: #3a2a1a; color: #ce9178; border: 1px solid #7a4a1e; }
        .hb-task-run  { background: #0e2a3a; color: #4fc1ff; border: 1px solid #1177bb; }

        /* ── TOP TAB BAR ── */
        .top-tabs { display: flex; background: #2d2d2d; border-bottom: 1px solid #3a3a3a; flex-shrink: 0; overflow-x: auto; scrollbar-width: none; }
        .top-tabs::-webkit-scrollbar { display: none; }
        .ttab { padding: 10px 16px; cursor: pointer; font-size: 0.78rem; color: #888; border-bottom: 2px solid transparent; white-space: nowrap; transition: all 0.15s; user-select: none; flex-shrink: 0; }
        .ttab:hover { color: #ccc; background: #333; }
        .ttab.active { color: #4ec9b0; border-bottom-color: #4ec9b0; background: #252526; }

        /* ── CONTENT AREA ── */
        .tab-content { flex: 1; overflow: hidden; display: flex; flex-direction: column; background: #1e1e1e; }
        .tab-pane { display: none; flex: 1; flex-direction: column; overflow: hidden; padding: 14px; }
        .tab-pane.active { display: flex; }

        /* ── BUTTONS ── */
        .btn { border: none; padding: 7px 14px; border-radius: 4px; cursor: pointer; font-weight: bold; font-size: 0.82rem; transition: background 0.15s; }
        .btn-blue   { background: #0e639c; color: #fff; } .btn-blue:hover   { background: #1177bb; }
        .btn-green  { background: #2d6e2d; color: #fff; } .btn-green:hover  { background: #3a8a3a; }
        .btn-amber  { background: #7a4a1e; color: #fff; } .btn-amber:hover  { background: #9a5e2a; }
        .btn-purple { background: #5a2d82; color: #fff; } .btn-purple:hover { background: #6e3a9a; }
        .btn-teal   { background: #0e5a5a; color: #fff; } .btn-teal:hover   { background: #0e7070; }
        .btn-red    { background: #7a1e1e; color: #fff; } .btn-red:hover    { background: #9a2a2a; }

        /* ── CHAT PANE ── */
        .chat-wrap { display: flex; flex-direction: column; flex: 1; overflow: hidden; }
        .chat-hdr { padding: 9px 16px; border-bottom: 1px solid #333; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0; background: #252526; border-radius: 8px 8px 0 0; }
        .chat-hdr h2 { font-size: 0.92rem; color: #fff; }
        .chat-body { flex: 1; display: flex; overflow: hidden; gap: 0; }
        .chat-messages { flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 10px; background: #1e1e1e; }
        .msg-row { display: flex; gap: 10px; max-width: 85%; }
        .msg-row.user { align-self: flex-end; flex-direction: row-reverse; }
        .msg-row.agent { align-self: flex-start; }
        .msg-avatar { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1rem; flex-shrink: 0; margin-top: 2px; }
        .msg-avatar.user-av  { background: #0e3a5a; }
        .msg-avatar.agent-av { background: #1a3a2a; }
        .msg-bubble { padding: 9px 13px; border-radius: 12px; font-size: 0.85rem; line-height: 1.55; word-break: break-word; max-width: 100%; }
        .msg-row.user  .msg-bubble { background: #0e3a5a; color: #d4eeff; border-radius: 12px 3px 12px 12px; }
        .msg-row.agent .msg-bubble { background: #252526; color: #d4d4d4; border: 1px solid #333; border-radius: 3px 12px 12px 12px; }
        .msg-time { font-size: 0.65rem; color: #555; margin-top: 3px; text-align: right; }
        .msg-row.agent .msg-time { text-align: left; }
        .chat-activity { width: 320px; flex-shrink: 0; border-left: 1px solid #333; display: flex; flex-direction: column; background: #1a1a1a; }
        .activity-hdr { padding: 8px 12px; border-bottom: 1px solid #333; font-size: 0.72rem; font-weight: bold; color: #666; text-transform: uppercase; letter-spacing: 0.06em; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0; }
        .activity-toggle { font-size: 0.68rem; color: #4ec9b0; cursor: pointer; text-transform: none; letter-spacing: 0; }
        #activity-feed { flex: 1; overflow-y: auto; padding: 6px; font-family: monospace; font-size: 0.75rem; }
        .act-entry { margin-bottom: 3px; padding: 3px 7px; border-left: 2px solid #444; border-radius: 0 2px 2px 0; line-height: 1.35; word-break: break-word; color: #888; }
        .act-INFO        { border-color: #569cd6; color: #7aaad4; }
        .act-ACTION      { border-color: #dcdcaa; color: #b0a870; }
        .act-ERROR       { border-color: #f44747; color: #d47070; background: #2a1a1a; }
        .act-MEMORY      { border-color: #c586c0; color: #9a6a95; }
        .act-CONTEXT     { border-color: #4ec9b0; }
        .act-SUCCESS     { border-color: #6a9955; color: #6a9955; }
        .act-HEARTBEAT   { border-color: #555; color: #555; }
        .act-CONFIG      { border-color: #ce9178; color: #9a7058; }
        .act-SYSTEM      { border-color: #555; }
        .act-MODIFICATION{ border-color: #f44747; }
        .act-LLM1        { border-color: #c586c0; background: #1e1830; }
        .act-LLM2        { border-color: #44aa88; background: #101a14; }
        .act-LLM3        { border-color: #c586c0; background: #1a1030; }
        .act-WEBSEARCH   { border-color: #4ec9b0; background: #0e1a1a; }
        .act-SOCIAL      { border-color: #569cd6; background: #0e1a2a; }
        .act-TASK        { border-color: #dcdcaa; background: #1a1a10; }
        .act-MODULE      { border-color: #4ec9b0; background: #0e1a1a; }
        .chat-footer { padding: 10px 12px; border-top: 1px solid #333; flex-shrink: 0; background: #252526; border-radius: 0 0 8px 8px; }
        .input-row { display: flex; gap: 8px; align-items: flex-end; }
        .chat-input-wrap { flex: 1; position: relative; }
        #user-input { width: 100%; resize: none; height: 42px; max-height: 120px; overflow-y: auto; line-height: 1.5; padding: 9px 12px; border-radius: 8px; font-size: 0.88rem; }
        .send-btn { width: 40px; height: 42px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; padding: 0; flex-shrink: 0; }
        .log-entry { margin-bottom: 4px; padding: 5px 8px; border-left: 3px solid #555; background: #2a2a2a; border-radius: 0 3px 3px 0; line-height: 1.4; word-break: break-word; }
        .log-INFO        { border-color: #569cd6; }
        .log-ACTION      { border-color: #dcdcaa; }
        .log-ERROR       { border-color: #f44747; }
        .log-MEMORY      { border-color: #c586c0; }
        .log-CONTEXT     { border-color: #4ec9b0; }
        .log-SUCCESS     { border-color: #6a9955; }
        .log-HEARTBEAT   { border-color: #aaa; background: #333; font-weight: bold; }
        .log-CONFIG      { border-color: #ce9178; }
        .log-SYSTEM      { border-color: #666; }
        .log-MODIFICATION{ border-color: #f44747; }
        .log-LLM1        { border-color: #c586c0; background: #2d2040; }
        .log-LLM2        { border-color: #44aa88; background: #1a3a2a; }
        .log-LLM3        { border-color: #c586c0; background: #2d1a3a; }
        .log-WEBSEARCH   { border-color: #4ec9b0; background: #1a2a2a; }
        .log-SOCIAL      { border-color: #569cd6; background: #1a2a3a; }
        .log-TASK        { border-color: #dcdcaa; background: #2a2a18; }
        .log-MODULE      { border-color: #4ec9b0; background: #1a2a2a; }
        .empty-state { color: #555; font-size: 0.85rem; text-align: center; margin-top: 30px; }

        /* ── SHARED INPUTS ── */
        input[type="text"], input[type="password"], textarea, select {
            background: #3c3c3c; border: 1px solid #555; color: #d4d4d4;
            padding: 7px 10px; border-radius: 4px; font-family: inherit; font-size: 0.86rem;
        }
        input:focus, textarea:focus, select:focus { outline: none; border-color: #0e639c; }

        /* ── SCROLLABLE LISTS ── */
        .scroll-list { flex: 1; overflow-y: auto; }
        .search-bar { width: 100%; margin-bottom: 8px; flex-shrink: 0; }

        /* ── MEMORY ── */
        .mem-item { background: #2e2e2e; padding: 7px 9px; margin-bottom: 5px; border-radius: 3px; border-left: 2px solid #c586c0; font-size: 0.8rem; line-height: 1.4; }
        .mem-meta { font-size: 0.7rem; color: #777; margin-bottom: 3px; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 4px; }
        .tag { font-size: 0.68rem; background: #444; padding: 1px 5px; border-radius: 3px; color: #aaa; }

        /* ── SESSIONS ── */
        .session-item { background: #2e2e2e; padding: 8px 10px; margin-bottom: 5px; border-radius: 3px; border-left: 2px solid #569cd6; cursor: pointer; font-size: 0.8rem; transition: background 0.1s; }
        .session-item:hover { background: #383838; }
        .session-title { color: #d4d4d4; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 3px; }
        .session-meta { font-size: 0.7rem; color: #777; }

        /* ── PERSONA ── */
        #personality-text { width: 100%; flex: 1; resize: none; font-size: 0.83rem; line-height: 1.55; padding: 9px; border-radius: 4px; }
        .personality-hint { font-size: 0.75rem; color: #666; margin-bottom: 8px; line-height: 1.6; flex-shrink: 0; }
        #personality-status { font-size: 0.75rem; color: #6a9955; margin-top: 5px; text-align: center; min-height: 1em; flex-shrink: 0; }

        /* ── AUDIT ── */
        .audit-entry { font-size: 0.78rem; padding: 4px 6px; margin-bottom: 3px; border-left: 2px solid #555; background: #2a2a2a; border-radius: 0 2px 2px 0; word-break: break-word; }

        /* ── LLM CONFIG PANELS ── */
        .llm-config-panel { display: flex; flex-direction: column; gap: 0; max-width: 600px; overflow-y: auto; }
        .field-group { margin-bottom: 11px; flex-shrink: 0; }
        .field-label { font-size: 0.75rem; color: #aaa; margin-bottom: 4px; display: block; font-weight: bold; }
        .field-hint  { font-size: 0.70rem; color: #555; margin-top: 3px; line-height: 1.4; }
        .field-input { width: 100%; }
        .llm-status-badge { display: inline-flex; align-items: center; gap: 5px; font-size: 0.72rem; padding: 3px 8px; border-radius: 10px; margin-bottom: 10px; flex-shrink: 0; }
        .badge-ok   { background: #1a3a1a; color: #6a9955; border: 1px solid #2d6e2d; }
        .badge-warn { background: #3a2a1a; color: #ce9178; border: 1px solid #7a4a1e; }
        .badge-dot  { width: 6px; height: 6px; border-radius: 50%; background: currentColor; flex-shrink: 0; }
        .llm-save-status { font-size: 0.75rem; color: #6a9955; margin-top: 6px; min-height: 1em; flex-shrink: 0; }
        .divider { border: none; border-top: 1px solid #333; margin: 10px 0; flex-shrink: 0; }
        .test-result { background: #1a2a1a; border: 1px solid #2d6e2d; border-radius: 4px; padding: 8px; font-size: 0.78rem; color: #6a9955; margin-top: 8px; max-height: 90px; overflow-y: auto; word-break: break-word; display: none; flex-shrink: 0; }

        /* ── TASKS ── */
        .task-item { background: #2e2e2e; padding: 8px 10px; margin-bottom: 6px; border-radius: 4px; border-left: 3px solid #555; font-size: 0.8rem; line-height: 1.4; }
        .task-pending  { border-color: #ce9178; }
        .task-running  { border-color: #4fc1ff; background: #1a2a3a; }
        .task-complete { border-color: #6a9955; }
        .task-failed   { border-color: #f44747; background: #2a1a1a; }
        .task-title    { font-weight: bold; color: #d4d4d4; margin-bottom: 3px; }
        .task-desc     { color: #888; font-size: 0.75rem; margin-bottom: 3px; }
        .task-result   { color: #6a9955; font-size: 0.75rem; margin-top: 3px; font-style: italic; }
        .task-meta     { font-size: 0.70rem; color: #666; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 4px; }
        .task-badge    { font-size: 0.68rem; padding: 1px 6px; border-radius: 3px; font-weight: bold; }
        .tb-pending  { background: #3a2a1a; color: #ce9178; }
        .tb-running  { background: #0e2a3a; color: #4fc1ff; }
        .tb-complete { background: #1a3a1a; color: #6a9955; }
        .tb-failed   { background: #3a1a1a; color: #f44747; }
        .tb-p1 { color: #f44747; } .tb-p2 { color: #888; } .tb-p3 { color: #555; }
        .task-add-form { background: #252526; border: 1px solid #3a3a3a; border-radius: 6px; padding: 12px; margin-bottom: 10px; flex-shrink: 0; max-width: 680px; }
        .task-actions { display: flex; gap: 5px; margin-top: 6px; }
        .task-act-btn { font-size: 0.68rem; padding: 2px 8px; border-radius: 3px; border: none; cursor: pointer; font-weight: bold; }
        .tact-edit    { background: #0e3a5a; color: #4fc1ff; } .tact-edit:hover    { background: #1177bb; }
        .tact-delete  { background: #5a0e0e; color: #f44747; } .tact-delete:hover  { background: #8a1a1a; }
        .tact-status  { background: #2d2d2d; color: #aaa; border: 1px solid #444; } .tact-status:hover { background: #444; }
        .task-edit-row { background: #1e2a1e; border: 1px solid #2d6e2d; border-radius: 6px; padding: 10px; margin-bottom: 6px; }
        .task-edit-row input, .task-edit-row textarea, .task-edit-row select { width: 100%; margin-bottom: 6px; font-size: 0.82rem; }
        .task-edit-row textarea { resize: none; height: 54px; }
        .task-edit-btns { display: flex; gap: 6px; }
        .tasks-wrap { display: flex; gap: 14px; flex: 1; overflow: hidden; }
        .tasks-main  { flex: 1; display: flex; flex-direction: column; overflow: hidden; min-width: 0; }
        .tasks-stats { width: 180px; flex-shrink: 0; display: flex; flex-direction: column; gap: 8px; }
        .stat-card { background: #252526; border: 1px solid #333; border-radius: 6px; padding: 10px; text-align: center; }
        .stat-num  { font-size: 1.6rem; font-weight: bold; line-height: 1; }
        .stat-label{ font-size: 0.70rem; color: #666; margin-top: 3px; }
        .stat-pend { color: #ce9178; } .stat-run  { color: #4fc1ff; }
        .stat-done { color: #6a9955; } .stat-fail { color: #f44747; }
        .task-add-form input, .task-add-form textarea, .task-add-form select { width: 100%; margin-bottom: 6px; }
        .task-add-form textarea { resize: none; height: 54px; }
        .task-filters { display: flex; gap: 5px; margin-bottom: 8px; flex-shrink: 0; flex-wrap: wrap; }
        .filter-btn { font-size: 0.70rem; padding: 3px 10px; border-radius: 10px; border: 1px solid #444; background: #2a2a2a; color: #777; cursor: pointer; }
        .filter-btn.active { background: #0e3a5a; color: #4fc1ff; border-color: #1177bb; }

        /* ── MODULES ── */
        .mod-search-row { display:flex; gap:6px; margin-bottom:10px; flex-shrink:0; max-width:600px; }
        .mod-search-row input { flex:1; }
        .mod-result { background:#2e2e2e; border:1px solid #3a3a3a; border-radius:4px; padding:8px 10px; margin-bottom:6px; font-size:0.8rem; line-height:1.5; }
        .mod-result:hover { border-color:#555; }
        .mod-name { font-weight:bold; color:#4fc1ff; font-size:0.85rem; word-break:break-all; }
        .mod-synopsis { color:#aaa; font-size:0.75rem; margin:2px 0 4px; }
        .mod-meta { font-size:0.70rem; color:#666; display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
        .mod-ver { color:#ce9178; } .mod-license { color:#6a9955; }
        .mod-btn { font-size:0.70rem; padding:2px 8px; border-radius:3px; border:none; cursor:pointer; font-weight:bold; margin-left:auto; }
        .mod-btn-add { background:#0e5a0e; color:#6a9955; } .mod-btn-add:hover { background:#1a8a1a; }
        .mod-btn-rm  { background:#5a0e0e; color:#f44747; } .mod-btn-rm:hover  { background:#8a1a1a; }
        .installed-mod { background:#1a2a1a; border:1px solid #2d6e2d; border-radius:4px; padding:7px 10px; margin-bottom:5px; font-size:0.78rem; display:flex; align-items:center; gap:8px; }
        .installed-mod-path { color:#4ec9b0; flex:1; word-break:break-all; font-family:monospace; }
        .installed-mod-ver  { color:#ce9178; font-size:0.72rem; white-space:nowrap; }
        .mod-tabs { display:flex; gap:0; margin-bottom:10px; flex-shrink:0; border-bottom:1px solid #333; }
        .mod-tab { font-size:0.75rem; padding:6px 14px; cursor:pointer; color:#777; border-bottom:2px solid transparent; }
        .mod-tab.active { color:#4ec9b0; border-bottom-color:#4ec9b0; }
        .mod-status { font-size:0.75rem; min-height:1.2em; margin-bottom:6px; flex-shrink:0; }

        /* ── HOST ── */
        .host-panel { display:flex; flex-direction:column; gap:0; max-width:500px; }
        .warning-box { background:#2a1a1a; border:1px solid #7a1e1e; border-radius:4px; padding:9px 10px; margin-bottom:10px; font-size:0.75rem; color:#ce9178; line-height:1.55; flex-shrink:0; }
        .warning-box b { color:#f44747; }
        .verify-result { background:#1a1a2a; border:1px solid #569cd6; border-radius:4px; padding:8px; font-size:0.78rem; color:#4fc1ff; margin-top:8px; max-height:80px; overflow-y:auto; word-break:break-word; display:none; flex-shrink:0; font-family:monospace; }

        /* ── WEB SEARCH TAB ── */
        .search-provider-grid { display:grid; grid-template-columns:1fr 1fr 1fr; gap:8px; margin-bottom:12px; }
        .provider-card { background:#2e2e2e; border:2px solid #3a3a3a; border-radius:6px; padding:10px; text-align:center; cursor:pointer; transition:all 0.15s; }
        .provider-card:hover { border-color:#555; }
        .provider-card.selected { border-color:#4ec9b0; background:#1a2a2a; }
        .provider-icon { font-size:1.5rem; margin-bottom:4px; }
        .provider-name { font-size:0.75rem; font-weight:bold; color:#aaa; }
        .search-test-box { background:#1a1a1a; border:1px solid #333; border-radius:4px; padding:10px; margin-top:8px; font-family:monospace; font-size:0.75rem; color:#888; max-height:200px; overflow-y:auto; white-space:pre-wrap; display:none; }

        /* ── SOCIAL TAB ── */
        .social-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:14px; overflow-y:auto; }
        .social-card { background:#252526; border:1px solid #333; border-radius:8px; padding:14px; display:flex; flex-direction:column; gap:0; }
        .social-card-hdr { display:flex; align-items:center; gap:8px; margin-bottom:10px; padding-bottom:8px; border-bottom:1px solid #333; }
        .social-icon { font-size:1.4rem; }
        .social-name { font-size:0.85rem; font-weight:bold; color:#fff; flex:1; }
        .social-status-dot { width:8px; height:8px; border-radius:50%; background:#555; flex-shrink:0; }
        .social-status-dot.on { background:#4ec9b0; animation:pulse 2s infinite; }
        .social-field { margin-bottom:7px; }
        .social-field label { font-size:0.70rem; color:#888; display:block; margin-bottom:3px; font-weight:bold; }
        .social-field input { width:100%; font-size:0.82rem; }
        .social-btns { display:flex; gap:6px; margin-top:8px; }
        .social-save-status { font-size:0.72rem; min-height:1.2em; margin-top:5px; }

        /* ── PERSONALITY BADGE ── */
        .personality-applied { font-size:0.70rem; color:#6a9955; background:#1a2a1a; border:1px solid #2d6e2d; border-radius:3px; padding:2px 7px; display:inline-block; margin-bottom:8px; }

        /* ── MODAL ── */
        .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.75); z-index: 200; align-items: center; justify-content: center; }
        .modal-overlay.open { display: flex; }
        .modal { background: #252526; border: 1px solid #444; border-radius: 8px; width: 680px; max-width: 95vw; max-height: 80vh; display: flex; flex-direction: column; overflow: hidden; }
        .modal-hdr { padding: 12px 15px; border-bottom: 1px solid #333; display: flex; align-items: center; justify-content: space-between; }
        .modal-hdr span { font-weight: bold; color: #fff; font-size: 0.9rem; }
        .modal-body { padding: 12px; overflow-y: auto; flex: 1; font-family: monospace; font-size: 0.83rem; }
        .close-btn { background: #3c3c3c; border: 1px solid #555; color: #aaa; padding: 4px 12px; border-radius: 3px; cursor: pointer; font-size: 0.82rem; }
        .close-btn:hover { background: #4a4a4a; }
    </style>
</head>
<body>

<div class="header">
    <span class="status-dot" title="Agent Active"></span>
    <h1 id="header-title">__TITLE__</h1>
    <div class="header-badges">
        <span id="hdr-main"  class="header-badge hb-off">Main: —</span>
        <span id="hdr-llm1"  class="header-badge hb-off">LLM1: —</span>
        <span id="hdr-llm2"  class="header-badge hb-off">LLM2: —</span>
        <span id="hdr-llm3"  class="header-badge hb-off">LLM3: —</span>
        <span id="hdr-opllm" class="header-badge hb-off">OpLLM: —</span>
        <span id="hdr-tasks" class="header-badge hb-off">Tasks: idle</span>
        <span id="hdr-root"  class="header-badge hb-off">Root: off</span>
    </div>
</div>

<div class="top-tabs">
    <div class="ttab active" onclick="switchTab('chat')">💬 Chat</div>
    <div class="ttab" onclick="switchTab('memory')">🧠 Memory</div>
    <div class="ttab" onclick="switchTab('tasks')">📋 Tasks</div>
    <div class="ttab" onclick="switchTab('sessions')">📁 Sessions</div>
    <div class="ttab" onclick="switchTab('personality')">🎭 Persona</div>
    <div class="ttab" onclick="switchTab('main-llm')">⚙ Main LLM</div>
    <div class="ttab" onclick="switchTab('llm1')">🧠 LLM1</div>
    <div class="ttab" onclick="switchTab('llm2')">🧠 LLM2</div>
    <div class="ttab" onclick="switchTab('llm3')">🧠 LLM3</div>
    <div class="ttab" onclick="switchTab('opllm')">⚙️ Op LLM</div>
    <div class="ttab" onclick="switchTab('websearch')">🔍 Web Search</div>
    <div class="ttab" onclick="switchTab('social')">📡 Social</div>
    <div class="ttab" onclick="switchTab('modules')">📦 Modules</div>
    <div class="ttab" onclick="switchTab('host')">🖥 Host</div>
    <div class="ttab" onclick="switchTab('audit')">📜 Audit</div>
</div>

<div class="tab-content">

    <!-- ===== CHAT ===== -->
    <div id="pane-chat" class="tab-pane active">
        <div class="chat-wrap">
            <div class="chat-hdr">
                <h2>💬 Agent Chat</h2>
                <div style="display:flex;gap:8px;align-items:center;">
                    <span id="agent-typing" style="font-size:0.72rem;color:#4ec9b0;display:none;">Agent is working...</span>
                    <button class="btn btn-amber" onclick="newChat()" style="padding:5px 12px;">+ New Chat</button>
                </div>
            </div>
            <div class="chat-body">
                <div class="chat-messages" id="chat-messages">
                    <div class="empty-state" id="chat-empty" style="margin:auto;">Send a message to get started.</div>
                </div>
                <div class="chat-activity" id="chat-activity-panel">
                    <div class="activity-hdr">
                        <span>Live Activity</span>
                        <span class="activity-toggle" onclick="toggleActivity()">hide</span>
                    </div>
                    <div id="activity-feed"></div>
                </div>
            </div>
            <div class="chat-footer">
                <div class="input-row">
                    <div class="chat-input-wrap">
                        <textarea id="user-input" placeholder="Give the agent a task... (Enter to send, Shift+Enter for newline)" rows="1"></textarea>
                    </div>
                    <button class="btn btn-blue send-btn" onclick="sendTask()" title="Send">➤</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== MEMORY ===== -->
    <div id="pane-memory" class="tab-pane">
        <input type="text" class="search-bar" id="mem-search" placeholder="Search memories..." oninput="filterMemory()" style="max-width:500px;">
        <div class="scroll-list" id="memory-list"><div class="empty-state">No memories yet.</div></div>
    </div>

    <!-- ===== TASKS ===== -->
    <div id="pane-tasks" class="tab-pane">
        <div class="tasks-wrap">
            <div class="tasks-main">
                <div class="task-add-form">
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:6px;">
                        <input type="text" id="task-title" placeholder="Task title (required)" style="grid-column:1/-1;">
                        <textarea id="task-desc" placeholder="Description (optional)" style="grid-column:1/-1;resize:none;height:52px;"></textarea>
                        <select id="task-priority">
                            <option value="1">🔴 High priority</option>
                            <option value="2" selected>🟡 Normal priority</option>
                            <option value="3">🟢 Low priority</option>
                        </select>
                        <button class="btn btn-blue" onclick="addTask()">+ Add Task</button>
                    </div>
                    <div id="task-add-status" style="font-size:0.73rem;color:#6a9955;min-height:1em;"></div>
                </div>
                <div class="task-filters">
                    <span class="filter-btn active" onclick="setTaskFilter('all',this)">All</span>
                    <span class="filter-btn" onclick="setTaskFilter('pending',this)">Pending</span>
                    <span class="filter-btn" onclick="setTaskFilter('running',this)">Running</span>
                    <span class="filter-btn" onclick="setTaskFilter('complete',this)">Done</span>
                    <span class="filter-btn" onclick="setTaskFilter('failed',this)">Failed</span>
                </div>
                <div class="scroll-list" id="task-list"><div class="empty-state">No tasks yet.</div></div>
            </div>
            <div class="tasks-stats">
                <div class="stat-card"><div class="stat-num stat-pend" id="stat-pending">0</div><div class="stat-label">Pending</div></div>
                <div class="stat-card"><div class="stat-num stat-run"  id="stat-running">0</div><div class="stat-label">Running</div></div>
                <div class="stat-card"><div class="stat-num stat-done" id="stat-complete">0</div><div class="stat-label">Complete</div></div>
                <div class="stat-card"><div class="stat-num stat-fail" id="stat-failed">0</div><div class="stat-label">Failed</div></div>
            </div>
        </div>
    </div>

    <!-- ===== SESSIONS ===== -->
    <div id="pane-sessions" class="tab-pane">
        <div style="font-size:0.80rem;color:#666;margin-bottom:10px;flex-shrink:0;">Click a session to view its full log.</div>
        <div class="scroll-list" id="session-list"><div class="empty-state">No sessions yet.</div></div>
    </div>

    <!-- ===== PERSONALITY ===== -->
    <div id="pane-personality" class="tab-pane">
        <div style="max-width:600px;display:flex;flex-direction:column;flex:1;overflow:hidden;">
            <div style="margin-bottom:10px;flex-shrink:0;">
                <label class="field-label" for="ui-title-input">Agent Name (header title)</label>
                <div style="display:flex;gap:6px;">
                    <input type="text" id="ui-title-input" placeholder="Lily" style="flex:1;">
                    <button class="btn btn-green" onclick="saveUITitle()" style="padding:7px 14px;">Save</button>
                </div>
                <div id="ui-title-status" style="font-size:0.73rem;color:#6a9955;margin-top:4px;min-height:1em;"></div>
            </div>
            <hr class="divider">
            <div class="personality-applied">✓ Personality is applied to Main LLM and all Expert LLMs</div>
            <div class="personality-hint">
                Define how the agent thinks and behaves. Changes take effect on the next task.<br><br>
                <b style="color:#aaa">Examples:</b> Always explain reasoning step by step · Prefer Python · Be concise · Ask before acting
            </div>
            <textarea id="personality-text" placeholder="Enter personality traits, one per line..."></textarea>
            <button class="btn btn-green" style="margin-top:8px;width:100%;padding:9px" onclick="savePersonality()">Save Personality</button>
            <div id="personality-status"></div>
        </div>
    </div>

    <!-- ===== MAIN LLM ===== -->
    <div id="pane-main-llm" class="tab-pane">
        <div class="llm-config-panel">
            <div id="main-llm-badge" class="llm-status-badge badge-warn"><span class="badge-dot"></span><span id="main-llm-badge-text">Loading...</span></div>
            <div class="field-group">
                <label class="field-label" for="main-llm-url">Base URL</label>
                <input type="text" id="main-llm-url" class="field-input" placeholder="http://localhost:11434">
                <div class="field-hint">Root address — <code>/v1/chat/completions</code> appended automatically. Works with Ollama, LM Studio, vLLM, OpenAI, Groq, etc.</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="main-llm-model">Model Name</label>
                <input type="text" id="main-llm-model" class="field-input" placeholder="llama3 / gpt-4o / mistral">
            </div>
            <div class="field-group">
                <label class="field-label" for="main-llm-key">API Key</label>
                <input type="password" id="main-llm-key" class="field-input" placeholder="sk-... (leave blank if not required)">
                <div class="field-hint">Sent as <code>Authorization: Bearer &lt;key&gt;</code>.</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="main-llm-timeout">Request Timeout (seconds)</label>
                <input type="number" id="main-llm-timeout" class="field-input" placeholder="300" min="10" max="3600">
                <div class="field-hint">How long to wait for a response. Default 300s. Retries up to 2× on timeout.</div>
            </div>
            <hr class="divider">
            <button class="btn btn-green" style="width:100%;padding:9px;margin-bottom:6px" onclick="saveMainLLM()">💾 Save</button>
            <button class="btn btn-teal"  style="width:100%;padding:9px" onclick="testMainLLM()">⚡ Test Connection</button>
            <div id="main-llm-status" class="llm-save-status"></div>
            <div id="main-llm-test-result" class="test-result"></div>
        </div>
    </div>

    <!-- ===== LLM1 ===== -->
    <div id="pane-llm1" class="tab-pane">
        <div class="llm-config-panel">
            <div id="llm1-badge" class="llm-status-badge badge-warn"><span class="badge-dot"></span><span id="llm1-badge-text">Not configured</span></div>
            <div class="field-group">
                <label class="field-label" for="llm1-url">Base URL</label>
                <input type="text" id="llm1-url" class="field-input" placeholder="http://localhost:11434">
                <div class="field-hint"><code>/v1/chat/completions</code> appended automatically.</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm1-model">Model Name</label>
                <input type="text" id="llm1-model" class="field-input" placeholder="llama3 / gpt-4o">
            </div>
            <div class="field-group">
                <label class="field-label" for="llm1-key">API Key</label>
                <input type="password" id="llm1-key" class="field-input" placeholder="sk-... (leave blank if not required)">
            </div>
            <div class="field-group">
                <label class="field-label" for="llm1-specialty">Specialty</label>
                <input type="text" id="llm1-specialty" class="field-input" placeholder="e.g., coding, marketing, research">
                <div class="field-hint">Describes what this expert LLM is good at. Injected into system prompt when delegating.</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm1-enabled">Enabled</label>
                <input type="checkbox" id="llm1-enabled" checked>
                <span style="color:#aaa;font-size:0.75rem;margin-left:8px;">Uncheck to disable delegation to this LLM</span>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm1-mode">Mode</label>
                <select id="llm1-mode" class="field-input">
                    <option value="using">Using (available for inference)</option>
                    <option value="training">Training (offline, not available)</option>
                </select>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm1-control-url">Control URL</label>
                <input type="text" id="llm1-control-url" class="field-input" placeholder="http://localhost:8081/control">
                <div class="field-hint">Endpoint for suspend/wake commands (optional).</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm1-timeout">Request Timeout (seconds)</label>
                <input type="number" id="llm1-timeout" class="field-input" placeholder="300" min="10" max="3600">
                <div class="field-hint">Default 300s. Affects all LLMs.</div>
            </div>
            <hr class="divider">
            <button class="btn btn-green" style="width:100%;padding:9px;margin-bottom:6px" onclick="saveLLM1()">💾 Save</button>
            <button class="btn btn-teal"  style="width:100%;padding:9px" onclick="testLLM1()">⚡ Test Connection</button>
            <div id="llm1-status" class="llm-save-status"></div>
            <div id="llm1-test-result" class="test-result"></div>
        </div>
    </div>

    <!-- ===== LLM2 ===== -->
    <div id="pane-llm2" class="tab-pane">
        <div class="llm-config-panel">
            <div id="llm2-badge" class="llm-status-badge badge-warn"><span class="badge-dot"></span><span id="llm2-badge-text">Not configured</span></div>
            <div class="field-group">
                <label class="field-label" for="llm2-url">Base URL</label>
                <input type="text" id="llm2-url" class="field-input" placeholder="http://localhost:11434">
                <div class="field-hint"><code>/v1/chat/completions</code> appended automatically.</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm2-model">Model Name</label>
                <input type="text" id="llm2-model" class="field-input" placeholder="llama3 / gpt-4o">
            </div>
            <div class="field-group">
                <label class="field-label" for="llm2-key">API Key</label>
                <input type="password" id="llm2-key" class="field-input" placeholder="sk-... (leave blank if not required)">
            </div>
            <div class="field-group">
                <label class="field-label" for="llm2-specialty">Specialty</label>
                <input type="text" id="llm2-specialty" class="field-input" placeholder="e.g., content writing, data analysis">
                <div class="field-hint">Describes what this expert LLM is good at.</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm2-enabled">Enabled</label>
                <input type="checkbox" id="llm2-enabled" checked>
                <span style="color:#aaa;font-size:0.75rem;margin-left:8px;">Uncheck to disable delegation to this LLM</span>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm2-mode">Mode</label>
                <select id="llm2-mode" class="field-input">
                    <option value="using">Using (available for inference)</option>
                    <option value="training">Training (offline, not available)</option>
                </select>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm2-control-url">Control URL</label>
                <input type="text" id="llm2-control-url" class="field-input" placeholder="http://localhost:8082/control">
                <div class="field-hint">Endpoint for suspend/wake commands (optional).</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm2-timeout">Request Timeout (seconds)</label>
                <input type="number" id="llm2-timeout" class="field-input" placeholder="300" min="10" max="3600">
                <div class="field-hint">Default 300s. Affects all LLMs.</div>
            </div>
            <hr class="divider">
            <button class="btn btn-green" style="width:100%;padding:9px;margin-bottom:6px" onclick="saveLLM2()">💾 Save</button>
            <button class="btn btn-teal"  style="width:100%;padding:9px" onclick="testLLM2()">⚡ Test Connection</button>
            <div id="llm2-status" class="llm-save-status"></div>
            <div id="llm2-test-result" class="test-result"></div>
        </div>
    </div>

    <!-- ===== LLM3 ===== -->
    <div id="pane-llm3" class="tab-pane">
        <div class="llm-config-panel">
            <div id="llm3-badge" class="llm-status-badge badge-warn"><span class="badge-dot"></span><span id="llm3-badge-text">Not configured</span></div>
            <div class="field-group">
                <label class="field-label" for="llm3-url">Base URL</label>
                <input type="text" id="llm3-url" class="field-input" placeholder="http://localhost:11434">
                <div class="field-hint"><code>/v1/chat/completions</code> appended automatically.</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm3-model">Model Name</label>
                <input type="text" id="llm3-model" class="field-input" placeholder="llama3 / gpt-4o">
            </div>
            <div class="field-group">
                <label class="field-label" for="llm3-key">API Key</label>
                <input type="password" id="llm3-key" class="field-input" placeholder="sk-... (leave blank if not required)">
            </div>
            <div class="field-group">
                <label class="field-label" for="llm3-specialty">Specialty</label>
                <input type="text" id="llm3-specialty" class="field-input" placeholder="e.g., image generation, media, creative">
                <div class="field-hint">Describes what this expert LLM is good at.</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm3-enabled">Enabled</label>
                <input type="checkbox" id="llm3-enabled" checked>
                <span style="color:#aaa;font-size:0.75rem;margin-left:8px;">Uncheck to disable delegation to this LLM</span>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm3-mode">Mode</label>
                <select id="llm3-mode" class="field-input">
                    <option value="using">Using (available for inference)</option>
                    <option value="training">Training (offline, not available)</option>
                </select>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm3-control-url">Control URL</label>
                <input type="text" id="llm3-control-url" class="field-input" placeholder="http://localhost:8083/control">
                <div class="field-hint">Endpoint for suspend/wake commands (optional).</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="llm3-timeout">Request Timeout (seconds)</label>
                <input type="number" id="llm3-timeout" class="field-input" placeholder="300" min="10" max="3600">
                <div class="field-hint">Default 300s. Affects all LLMs.</div>
            </div>
            <hr class="divider">
            <button class="btn btn-green" style="width:100%;padding:9px;margin-bottom:6px" onclick="saveLLM3()">💾 Save</button>
            <button class="btn btn-teal"  style="width:100%;padding:9px" onclick="testLLM3()">⚡ Test Connection</button>
            <div id="llm3-status" class="llm-save-status"></div>
            <div id="llm3-test-result" class="test-result"></div>
        </div>
    </div>

    <!-- ===== OPERATIONAL LLM ===== -->
    <div id="pane-opllm" class="tab-pane">
        <div class="llm-config-panel">
            <div style="background:#1a1a2a;border:1px solid #1177bb;border-radius:4px;padding:8px 10px;margin-bottom:10px;font-size:0.75rem;color:#4fc1ff;flex-shrink:0;">
                ⚙️ <b>Operational LLM</b> — background model for memory consolidation, learning, and maintenance tasks. Woken by heartbeat.
            </div>
            <div id="opllm-badge" class="llm-status-badge badge-warn"><span class="badge-dot"></span><span id="opllm-badge-text">Not configured</span></div>
            <div class="field-group">
                <label class="field-label" for="opllm-url">Base URL</label>
                <input type="text" id="opllm-url" class="field-input" placeholder="http://localhost:11434">
                <div class="field-hint"><code>/v1/chat/completions</code> appended automatically.</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="opllm-model">Model Name</label>
                <input type="text" id="opllm-model" class="field-input" placeholder="llama3 / phi3 / mistral">
            </div>
            <div class="field-group">
                <label class="field-label" for="opllm-key">API Key</label>
                <input type="password" id="opllm-key" class="field-input" placeholder="sk-... (leave blank if not required)">
            </div>
            <div class="field-group">
                <label class="field-label" for="opllm-enabled">Enabled</label>
                <input type="checkbox" id="opllm-enabled" checked>
                <span style="color:#aaa;font-size:0.75rem;margin-left:8px;">Uncheck to disable operational LLM</span>
            </div>
            <div class="field-group">
                <label class="field-label" for="opllm-mode">Mode</label>
                <select id="opllm-mode" class="field-input">
                    <option value="using">Using (available)</option>
                    <option value="training">Training (offline)</option>
                </select>
            </div>
            <div class="field-group">
                <label class="field-label" for="opllm-control-url">Control URL</label>
                <input type="text" id="opllm-control-url" class="field-input" placeholder="http://localhost:8084/control">
                <div class="field-hint">Heartbeat sends wake/suspend commands here.</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="opllm-timeout">Request Timeout (seconds)</label>
                <input type="number" id="opllm-timeout" class="field-input" placeholder="300" min="10" max="3600">
            </div>
            <hr class="divider">
            <button class="btn btn-green" style="width:100%;padding:9px;margin-bottom:6px" onclick="saveOpLLM()">💾 Save</button>
            <button class="btn btn-teal"  style="width:100%;padding:9px" onclick="testOpLLM()">⚡ Test Connection</button>
            <div id="opllm-status" class="llm-save-status"></div>
            <div id="opllm-test-result" class="test-result"></div>
        </div>
    </div>

    <!-- ===== WEB SEARCH ===== -->
    <div id="pane-websearch" class="tab-pane">
        <div style="max-width:700px;display:flex;flex-direction:column;gap:14px;overflow-y:auto;flex:1;">
            <div>
                <div class="field-label" style="margin-bottom:8px;">Search Provider</div>
                <div class="search-provider-grid">
                    <div class="provider-card selected" id="prov-duckduckgo" onclick="selectProvider('duckduckgo')">
                        <div class="provider-icon">🦆</div>
                        <div class="provider-name">DuckDuckGo</div>
                        <div style="font-size:0.65rem;color:#6a9955;margin-top:3px;">No key needed</div>
                    </div>
                    <div class="provider-card" id="prov-google" onclick="selectProvider('google')">
                        <div class="provider-icon">🔍</div>
                        <div class="provider-name">Google</div>
                        <div style="font-size:0.65rem;color:#ce9178;margin-top:3px;">API key required</div>
                    </div>
                    <div class="provider-card" id="prov-brave" onclick="selectProvider('brave')">
                        <div class="provider-icon">🦁</div>
                        <div class="provider-name">Brave Search</div>
                        <div style="font-size:0.65rem;color:#ce9178;margin-top:3px;">API key required</div>
                    </div>
                </div>
            </div>
            <div id="search-key-fields" style="display:none;">
                <div class="field-group">
                    <label class="field-label" for="search-api-key">API Key</label>
                    <input type="password" id="search-api-key" class="field-input" placeholder="Paste your API key...">
                    <div class="field-hint" id="search-key-hint">Required for the selected provider.</div>
                </div>
                <div class="field-group" id="search-cx-group" style="display:none;">
                    <label class="field-label" for="search-cx">Custom Search Engine ID (cx)</label>
                    <input type="text" id="search-cx" class="field-input" placeholder="Google Custom Search Engine ID">
                    <div class="field-hint">Create one at <code>programmablesearchengine.google.com</code></div>
                </div>
            </div>
            <div style="display:flex;gap:8px;">
                <button class="btn btn-green" onclick="saveSearchConfig()" style="padding:8px 18px;">💾 Save</button>
                <button class="btn btn-teal"  onclick="testSearch()"       style="padding:8px 18px;">⚡ Test Search</button>
            </div>
            <div id="search-status" class="llm-save-status"></div>
            <div>
                <div class="field-label" style="margin-bottom:6px;">Test Query</div>
                <input type="text" id="search-test-query" placeholder="e.g. latest AI news" style="width:100%;" onkeypress="if(event.key==='Enter')testSearch()">
            </div>
            <div class="search-test-box" id="search-test-box"></div>
            <div style="background:#1e2a1e;border:1px solid #2d6e2d;border-radius:6px;padding:12px;">
                <div style="font-size:0.75rem;font-weight:bold;color:#6a9955;margin-bottom:6px;">🤖 Autonomous Usage</div>
                <div style="font-size:0.75rem;color:#666;line-height:1.6;">
                    The agent calls <code>web_search(query)</code> and <code>fetch_url(url)</code> autonomously at any time.
                </div>
            </div>
        </div>
    </div>

    <!-- ===== SOCIAL ===== -->
    <div id="pane-social" class="tab-pane">
        <div style="display:flex;flex-direction:column;gap:0;flex:1;overflow:hidden;">
            <div style="display:flex;gap:8px;margin-bottom:10px;flex-shrink:0;align-items:center;">
                <button class="btn btn-green" onclick="saveSocialConfig()" style="padding:7px 16px;">💾 Save All</button>
                <div id="social-save-status" style="font-size:0.75rem;color:#6a9955;min-height:1em;"></div>
            </div>
            <div class="social-grid">
                <div class="social-card">
                    <div class="social-card-hdr"><span class="social-icon">💬</span><span class="social-name">Discord</span><span class="social-status-dot" id="dot-discord"></span></div>
                    <div class="social-field"><label>Bot Token</label><input type="password" id="soc-discord-token" placeholder="Bot token..."></div>
                    <div class="social-field"><label>Channel ID</label><input type="text" id="soc-discord-channel" placeholder="Channel ID..."></div>
                    <div class="social-btns"><button class="btn btn-teal" style="flex:1;padding:5px;" onclick="testSocial('discord')">⚡ Test</button></div>
                    <div class="social-save-status" id="soc-status-discord"></div>
                </div>
                <div class="social-card">
                    <div class="social-card-hdr"><span class="social-icon">🐦</span><span class="social-name">Twitter / X</span><span class="social-status-dot" id="dot-twitter"></span></div>
                    <div class="social-field"><label>API Key (Consumer Key)</label><input type="password" id="soc-twitter-key" placeholder="API Key..."></div>
                    <div class="social-field"><label>API Secret</label><input type="password" id="soc-twitter-secret" placeholder="API Secret..."></div>
                    <div class="social-field"><label>Access Token</label><input type="password" id="soc-twitter-token" placeholder="Access Token..."></div>
                    <div class="social-field"><label>Access Token Secret</label><input type="password" id="soc-twitter-token-sec" placeholder="Access Token Secret..."></div>
                    <div class="social-btns"><button class="btn btn-teal" style="flex:1;padding:5px;" onclick="testSocial('twitter')">⚡ Test</button></div>
                    <div class="social-save-status" id="soc-status-twitter"></div>
                </div>
                <div class="social-card">
                    <div class="social-card-hdr"><span class="social-icon">✈️</span><span class="social-name">Telegram</span><span class="social-status-dot" id="dot-telegram"></span></div>
                    <div class="social-field"><label>Bot Token</label><input type="password" id="soc-telegram-token" placeholder="Bot token from @BotFather..."></div>
                    <div class="social-field"><label>Chat ID</label><input type="text" id="soc-telegram-chat" placeholder="Chat or group ID..."></div>
                    <div class="social-btns"><button class="btn btn-teal" style="flex:1;padding:5px;" onclick="testSocial('telegram')">⚡ Test</button></div>
                    <div class="social-save-status" id="soc-status-telegram"></div>
                </div>
                <div class="social-card">
                    <div class="social-card-hdr"><span class="social-icon">🔷</span><span class="social-name">Slack</span><span class="social-status-dot" id="dot-slack"></span></div>
                    <div class="social-field"><label>Bot Token (xoxb-...)</label><input type="password" id="soc-slack-token" placeholder="xoxb-..."></div>
                    <div class="social-field"><label>Channel</label><input type="text" id="soc-slack-channel" placeholder="#general or channel ID..."></div>
                    <div class="social-btns"><button class="btn btn-teal" style="flex:1;padding:5px;" onclick="testSocial('slack')">⚡ Test</button></div>
                    <div class="social-save-status" id="soc-status-slack"></div>
                </div>
                <div class="social-card">
                    <div class="social-card-hdr"><span class="social-icon">📱</span><span class="social-name">WhatsApp (Twilio)</span><span class="social-status-dot" id="dot-whatsapp"></span></div>
                    <div class="social-field"><label>Twilio Account SID</label><input type="password" id="soc-wa-sid" placeholder="ACxxxxxxxx..."></div>
                    <div class="social-field"><label>Auth Token</label><input type="password" id="soc-wa-token" placeholder="Auth token..."></div>
                    <div class="social-field"><label>From Number (+1234...)</label><input type="text" id="soc-wa-from" placeholder="+14155238886"></div>
                    <div class="social-field"><label>To Number (+1234...)</label><input type="text" id="soc-wa-to" placeholder="+15551234567"></div>
                    <div class="social-btns"><button class="btn btn-teal" style="flex:1;padding:5px;" onclick="testSocial('whatsapp')">⚡ Test</button></div>
                    <div class="social-save-status" id="soc-status-whatsapp"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== MODULES ===== -->
    <div id="pane-modules" class="tab-pane">
        <div class="mod-tabs">
            <div class="mod-tab active" onclick="switchModTab('browse',this)">Browse</div>
            <div class="mod-tab"        onclick="switchModTab('installed',this)">Installed</div>
            <div class="mod-tab"        onclick="switchModTab('gomod',this)">go.mod</div>
        </div>
        <div id="mod-pane-browse" style="display:flex;flex-direction:column;flex:1;overflow:hidden;">
            <div class="mod-search-row">
                <input type="text" id="mod-search-input" placeholder="Search pkg.go.dev..." onkeypress="if(event.key==='Enter')searchModules()">
                <button class="btn btn-blue" onclick="searchModules()" style="padding:6px 14px;">Search</button>
            </div>
            <div class="mod-status" id="mod-search-status"></div>
            <div class="scroll-list" id="mod-results"><div class="empty-state">Search for Go packages above.</div></div>
        </div>
        <div id="mod-pane-installed" style="display:none;flex-direction:column;flex:1;overflow:hidden;">
            <div style="display:flex;gap:6px;margin-bottom:8px;flex-shrink:0;max-width:500px;">
                <input type="text" id="mod-manual-input" placeholder="Module path (e.g. github.com/user/pkg)" style="flex:1;" onkeypress="if(event.key==='Enter')addModuleManual()">
                <button class="btn btn-green" onclick="addModuleManual()" style="padding:6px 12px;">+ Add</button>
            </div>
            <div class="mod-status" id="mod-install-status"></div>
            <div class="scroll-list" id="mod-installed-list"><div class="empty-state">Loading...</div></div>
        </div>
        <div id="mod-pane-gomod" style="display:none;flex-direction:column;flex:1;overflow:hidden;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;flex-shrink:0;">
                <span style="font-size:0.78rem;color:#aaa;">go.mod contents</span>
                <button class="btn btn-teal" onclick="loadGoMod()" style="padding:4px 10px;font-size:0.72rem;">↻ Refresh</button>
            </div>
            <textarea id="mod-gomod-content" style="flex:1;resize:none;font-family:monospace;font-size:0.76rem;line-height:1.5;padding:8px;background:#1a1a1a;border:1px solid #333;border-radius:4px;color:#d4d4d4;" readonly placeholder="go.mod not found"></textarea>
        </div>
    </div>

    <!-- ===== HOST ===== -->
    <div id="pane-host" class="tab-pane">
        <div class="host-panel">
            <div id="host-badge" class="llm-status-badge badge-warn"><span class="badge-dot"></span><span id="host-badge-text">No credentials set</span></div>
            <div class="warning-box"><b>⚠ Full Root Access</b><br>When credentials are saved, every shell command the agent runs will be executed via <code>sudo</code> as the specified user. The agent will have unrestricted host access.</div>
            <div class="field-group">
                <label class="field-label" for="host-user">Username</label>
                <input type="text" id="host-user" class="field-input" placeholder="root (or another sudoer)">
                <div class="field-hint">Leave blank to default to <code>root</code>.</div>
            </div>
            <div class="field-group">
                <label class="field-label" for="host-pass">Password</label>
                <input type="password" id="host-pass" class="field-input" placeholder="sudo / root password">
                <div class="field-hint">Passed to <code>sudo -S</code>. Stored in <code>config.json</code>.</div>
            </div>
            <hr class="divider">
            <button class="btn btn-green" style="width:100%;padding:9px;margin-bottom:6px" onclick="saveHostConfig()">💾 Save Credentials</button>
            <button class="btn btn-red"   style="width:100%;padding:9px;margin-bottom:6px" onclick="clearHostConfig()">🗑 Clear Credentials</button>
            <button class="btn btn-teal"  style="width:100%;padding:9px" onclick="verifyHostAccess()">⚡ Verify Root Access</button>
            <div id="host-status" class="llm-save-status"></div>
            <div id="host-verify-result" class="verify-result"></div>
        </div>
    </div>

    <!-- ===== AUDIT ===== -->
    <div id="pane-audit" class="tab-pane">
        <input type="text" class="search-bar" id="audit-search" placeholder="Filter audit log..." oninput="filterAudit()" style="max-width:500px;">
        <div class="scroll-list" id="audit-list"><div class="empty-state">No log entries yet.</div></div>
    </div>

</div><!-- end tab-content -->

<!-- Session modal -->
<div class="modal-overlay" id="session-modal" onclick="closeModal(event)">
    <div class="modal">
        <div class="modal-hdr">
            <span id="modal-title"></span>
            <button class="close-btn" onclick="document.getElementById('session-modal').classList.remove('open')">Close</button>
        </div>
        <div class="modal-body" id="modal-body"></div>
    </div>
</div>

<script>
var logs=[], memories=[], sessions=[];
var tabNames=['chat','memory','tasks','sessions','personality','main-llm','llm1','llm2','llm3','opllm','websearch','social','modules','host','audit'];

function switchTab(name){
    document.querySelectorAll('.ttab').forEach(function(t,i){ t.classList.toggle('active', tabNames[i]===name); });
    tabNames.forEach(function(n){ var p=document.getElementById('pane-'+n); if(p) p.classList.toggle('active', n===name); });
}

/* ---- Data polling ---- */
async function fetchData(){
    fetchTasks();
    fetchChatMessages();
    try{ var d=await(await fetch('/api/logs')).json(); if(d&&d.length!==logs.length){logs=d;renderActivity();filterAudit();showTyping(false);} }catch(e){}
    try{ var d=await(await fetch('/api/memory')).json(); if(d&&d.length!==memories.length){memories=d;filterMemory();} }catch(e){}
    try{ var d=await(await fetch('/api/sessions')).json(); if(d&&d.length!==sessions.length){sessions=d;renderSessions();} }catch(e){}
}

/* ---- Chat ---- */
var chatMsgs=[], activityVisible=true;

function toggleActivity(){
    var panel=document.getElementById('chat-activity-panel');
    activityVisible=!activityVisible;
    panel.style.display=activityVisible?'flex':'none';
    document.querySelector('.activity-toggle').textContent=activityVisible?'hide':'show';
}

async function fetchChatMessages(){
    try{
        var d=await(await fetch('/api/chat_messages')).json();
        if(JSON.stringify(d)!==JSON.stringify(chatMsgs)){
            chatMsgs=d||[];
            renderChatMessages();
        }
    }catch(e){}
}

function renderChatMessages(){
    var c=document.getElementById('chat-messages');
    if(!chatMsgs||!chatMsgs.length){
        c.innerHTML='<div class="empty-state" id="chat-empty" style="margin:auto;">Send a message to get started.</div>';
        return;
    }
    var h='';
    chatMsgs.forEach(function(m){
        var isUser=m.role==='user';
        var t=new Date(m.timestamp).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
        h+='<div class="msg-row '+(isUser?'user':'agent')+'">'
          +'<div class="msg-avatar '+(isUser?'user-av':'agent-av')+'">'+(isUser?'👤':'🤖')+'</div>'
          +'<div>'
          +'<div class="msg-bubble">'+esc(m.content)+'</div>'
          +'<div class="msg-time">'+t+'</div>'
          +'</div></div>';
    });
    c.innerHTML=h;
    c.scrollTop=c.scrollHeight;
}

function renderActivity(){
    var c=document.getElementById('activity-feed');
    if(!logs||!logs.length){c.innerHTML='';return;}
    var h='';
    logs.slice(-80).forEach(function(l){
        var t=new Date(l.timestamp).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'});
        h+='<div class="act-entry act-'+l.level+'">'+t+' '+esc(l.content)+'</div>';
    });
    c.innerHTML=h; c.scrollTop=c.scrollHeight;
}

function showTyping(on){
    var el=document.getElementById('agent-typing');
    if(el) el.style.display=on?'inline':'none';
}

/* ---- Memory ---- */
function filterMemory(){
    var q=document.getElementById('mem-search').value.toLowerCase();
    var c=document.getElementById('memory-list');
    var f=memories.filter(function(m){ return m.content.toLowerCase().includes(q)||((m.tags||[]).join(' ').toLowerCase().includes(q)); });
    if(!f.length){c.innerHTML='<div class="empty-state">No memories match.</div>';return;}
    var h='';
    f.slice().reverse().forEach(function(m){
        var tags=(m.tags||[]).map(function(t){return'<span class="tag">'+esc(t)+'</span>';}).join(' ');
        h+='<div class="mem-item"><div class="mem-meta"><div>'+tags+'</div><div>'+new Date(m.created_at).toLocaleDateString()+'</div></div>'+esc(m.content)+'</div>';
    });
    c.innerHTML=h;
}

/* ---- Sessions ---- */
function renderSessions(){
    var c=document.getElementById('session-list');
    if(!sessions.length){c.innerHTML='<div class="empty-state">No sessions yet.</div>';return;}
    var h='';
    sessions.slice().reverse().forEach(function(s){
        h+='<div class="session-item" onclick="viewSession('+s.id+')">'
          +'<div class="session-title">#'+s.id+': '+esc(s.title)+'</div>'
          +'<div class="session-meta">'+new Date(s.created_at).toLocaleString()+' &bull; '+(s.logs||[]).length+' entries</div></div>';
    });
    c.innerHTML=h;
}
function viewSession(id){
    var s=sessions.find(function(x){return x.id===id;});
    if(!s) return;
    document.getElementById('modal-title').textContent='#'+s.id+': '+s.title;
    var h='';
    (s.logs||[]).forEach(function(l){
        h+='<div class="log-entry log-'+l.level+'">['+new Date(l.timestamp).toLocaleTimeString()+'] <b>'+l.level+'</b>: '+esc(l.content)+'</div>';
    });
    document.getElementById('modal-body').innerHTML=h||'<div class="empty-state">No entries.</div>';
    document.getElementById('session-modal').classList.add('open');
}
function closeModal(e){ if(e.target.id==='session-modal') document.getElementById('session-modal').classList.remove('open'); }

/* ---- Audit ---- */
function filterAudit(){
    var q=document.getElementById('audit-search').value.toLowerCase();
    var c=document.getElementById('audit-list');
    var f=q?logs.filter(function(l){return l.content.toLowerCase().includes(q);}):logs;
    if(!f.length){c.innerHTML='<div class="empty-state">No entries.</div>';return;}
    var h='';
    f.slice().reverse().forEach(function(l){
        h+='<div class="audit-entry log-'+l.level+'">'+new Date(l.timestamp).toLocaleTimeString()+' <b>'+l.level+'</b> '+esc(l.content)+'</div>';
    });
    c.innerHTML=h;
}

/* ---- Personality ---- */
async function loadPersonality(){
    try{ var d=await(await fetch('/api/personality')).json(); document.getElementById('personality-text').value=d.personality||''; }catch(e){}
}
async function savePersonality(){
    var text=document.getElementById('personality-text').value;
    try{
        await fetch('/api/personality',{method:'POST',body:JSON.stringify({personality:text}),headers:{'Content-Type':'application/json'}});
        var s=document.getElementById('personality-status');
        s.textContent='Saved. Takes effect on next task.';
        setTimeout(function(){s.textContent='';},3000);
    }catch(e){}
}

/* ---- Generic LLM helpers ---- */
function updateBadge(badgeId, textId, url, model){
    var badge=document.getElementById(badgeId);
    var text=document.getElementById(textId);
    if(url&&model){ badge.className='llm-status-badge badge-ok'; text.textContent='Configured: '+model; }
    else           { badge.className='llm-status-badge badge-warn'; text.textContent='Not configured'; }
}
function updateLLMBadge(badgeId, textId, url, model, enabled, specialty){
    var badge=document.getElementById(badgeId);
    var text=document.getElementById(textId);
    if(url&&model&&enabled){
        badge.className='llm-status-badge badge-ok';
        text.textContent=model+(specialty?' ('+specialty+')':'');
    } else {
        badge.className='llm-status-badge badge-warn';
        text.textContent=enabled?'Not configured':'Disabled';
    }
}
function updateHeaderBadge(id, cls, label, model){
    var el=document.getElementById(id);
    el.className='header-badge '+(model?cls:'hb-off');
    el.textContent=label+(model?' '+model:'—');
}
function showStatus(id, msg, ok){
    var el=document.getElementById(id);
    el.textContent=msg; el.style.color=ok?'#6a9955':'#f44747';
    setTimeout(function(){el.textContent='';el.style.color='';},5000);
}

/* ---- Main LLM ---- */
async function loadMainLLM(){
    try{
        var d=await(await fetch('/api/main_llm_config')).json();
        document.getElementById('main-llm-url').value=d.url||'';
        document.getElementById('main-llm-model').value=d.model||'';
        document.getElementById('main-llm-key').value=d.key||'';
        document.getElementById('main-llm-timeout').value=d.timeout||300;
        updateBadge('main-llm-badge','main-llm-badge-text',d.url,d.model);
        updateHeaderBadge('hdr-main','hb-main','Main: ',d.model);
    }catch(e){}
}
async function saveMainLLM(){
    var url=document.getElementById('main-llm-url').value.trim();
    var model=document.getElementById('main-llm-model').value.trim();
    var key=document.getElementById('main-llm-key').value.trim();
    var timeout=parseInt(document.getElementById('main-llm-timeout').value)||300;
    try{
        await fetch('/api/main_llm_config',{method:'POST',body:JSON.stringify({url:url,model:model,key:key,timeout:timeout}),headers:{'Content-Type':'application/json'}});
        showStatus('main-llm-status','✓ Saved successfully.',true);
        updateBadge('main-llm-badge','main-llm-badge-text',url,model);
        updateHeaderBadge('hdr-main','hb-main','Main: ',model);
    }catch(e){ showStatus('main-llm-status','✗ Save failed: '+e,false); }
}
async function testMainLLM(){
    document.getElementById('main-llm-status').textContent='⏳ Testing...';
    document.getElementById('main-llm-status').style.color='#ce9178';
    document.getElementById('main-llm-test-result').style.display='none';
    try{
        var d=await(await fetch('/api/main_llm_test',{method:'POST'})).json();
        if(d.error){ showStatus('main-llm-status','✗ '+d.error,false); }
        else{
            showStatus('main-llm-status','✓ Connection successful!',true);
            var r=document.getElementById('main-llm-test-result');
            r.textContent=d.response; r.style.display='block';
        }
    }catch(e){ showStatus('main-llm-status','✗ Request failed: '+e,false); }
}

/* ---- LLM1 ---- */
async function loadLLM1(){
    try{
        var d=await(await fetch('/api/llm1_config')).json();
        document.getElementById('llm1-url').value=d.url||'';
        document.getElementById('llm1-model').value=d.model||'';
        document.getElementById('llm1-key').value=d.key||'';
        document.getElementById('llm1-specialty').value=d.specialty||'';
        document.getElementById('llm1-enabled').checked=d.enabled!==false;
        document.getElementById('llm1-mode').value=d.mode||'using';
        document.getElementById('llm1-control-url').value=d.control_url||'';
        document.getElementById('llm1-timeout').value=d.timeout||300;
        updateLLMBadge('llm1-badge','llm1-badge-text',d.url,d.model,d.enabled!==false,d.specialty);
        updateHeaderBadge('hdr-llm1','hb-llm1','LLM1: ',d.enabled&&d.model?d.model:'');
    }catch(e){}
}
async function saveLLM1(){
    var url=document.getElementById('llm1-url').value.trim();
    var model=document.getElementById('llm1-model').value.trim();
    var key=document.getElementById('llm1-key').value.trim();
    var specialty=document.getElementById('llm1-specialty').value.trim();
    var enabled=document.getElementById('llm1-enabled').checked;
    var mode=document.getElementById('llm1-mode').value;
    var controlURL=document.getElementById('llm1-control-url').value.trim();
    var timeout=parseInt(document.getElementById('llm1-timeout').value)||300;
    try{
        await fetch('/api/llm1_config',{method:'POST',
            body:JSON.stringify({url:url,model:model,key:key,specialty:specialty,enabled:enabled,mode:mode,control_url:controlURL,timeout:timeout}),
            headers:{'Content-Type':'application/json'}});
        showStatus('llm1-status','✓ Saved successfully.',true);
        updateLLMBadge('llm1-badge','llm1-badge-text',url,model,enabled,specialty);
        updateHeaderBadge('hdr-llm1','hb-llm1','LLM1: ',enabled&&model?model:'');
    }catch(e){ showStatus('llm1-status','✗ Save failed: '+e,false); }
}
async function testLLM1(){
    document.getElementById('llm1-status').textContent='⏳ Testing...';
    document.getElementById('llm1-status').style.color='#ce9178';
    document.getElementById('llm1-test-result').style.display='none';
    try{
        var d=await(await fetch('/api/llm1_test',{method:'POST'})).json();
        if(d.error){ showStatus('llm1-status','✗ '+d.error,false); }
        else{
            showStatus('llm1-status','✓ Connection successful!',true);
            var r=document.getElementById('llm1-test-result');
            r.textContent=d.response; r.style.display='block';
        }
    }catch(e){ showStatus('llm1-status','✗ Request failed: '+e,false); }
}

/* ---- LLM2 ---- */
async function loadLLM2(){
    try{
        var d=await(await fetch('/api/llm2_config')).json();
        document.getElementById('llm2-url').value=d.url||'';
        document.getElementById('llm2-model').value=d.model||'';
        document.getElementById('llm2-key').value=d.key||'';
        document.getElementById('llm2-specialty').value=d.specialty||'';
        document.getElementById('llm2-enabled').checked=d.enabled!==false;
        document.getElementById('llm2-mode').value=d.mode||'using';
        document.getElementById('llm2-control-url').value=d.control_url||'';
        document.getElementById('llm2-timeout').value=d.timeout||300;
        updateLLMBadge('llm2-badge','llm2-badge-text',d.url,d.model,d.enabled!==false,d.specialty);
        updateHeaderBadge('hdr-llm2','hb-llm2','LLM2: ',d.enabled&&d.model?d.model:'');
    }catch(e){}
}
async function saveLLM2(){
    var url=document.getElementById('llm2-url').value.trim();
    var model=document.getElementById('llm2-model').value.trim();
    var key=document.getElementById('llm2-key').value.trim();
    var specialty=document.getElementById('llm2-specialty').value.trim();
    var enabled=document.getElementById('llm2-enabled').checked;
    var mode=document.getElementById('llm2-mode').value;
    var controlURL=document.getElementById('llm2-control-url').value.trim();
    var timeout=parseInt(document.getElementById('llm2-timeout').value)||300;
    try{
        await fetch('/api/llm2_config',{method:'POST',
            body:JSON.stringify({url:url,model:model,key:key,specialty:specialty,enabled:enabled,mode:mode,control_url:controlURL,timeout:timeout}),
            headers:{'Content-Type':'application/json'}});
        showStatus('llm2-status','✓ Saved successfully.',true);
        updateLLMBadge('llm2-badge','llm2-badge-text',url,model,enabled,specialty);
        updateHeaderBadge('hdr-llm2','hb-llm2','LLM2: ',enabled&&model?model:'');
    }catch(e){ showStatus('llm2-status','✗ Save failed: '+e,false); }
}
async function testLLM2(){
    document.getElementById('llm2-status').textContent='⏳ Testing...';
    document.getElementById('llm2-status').style.color='#ce9178';
    document.getElementById('llm2-test-result').style.display='none';
    try{
        var d=await(await fetch('/api/llm2_test',{method:'POST'})).json();
        if(d.error){ showStatus('llm2-status','✗ '+d.error,false); }
        else{
            showStatus('llm2-status','✓ Connection successful!',true);
            var r=document.getElementById('llm2-test-result');
            r.textContent=d.response; r.style.display='block';
        }
    }catch(e){ showStatus('llm2-status','✗ Request failed: '+e,false); }
}

/* ---- LLM3 ---- */
async function loadLLM3(){
    try{
        var d=await(await fetch('/api/llm3_config')).json();
        document.getElementById('llm3-url').value=d.url||'';
        document.getElementById('llm3-model').value=d.model||'';
        document.getElementById('llm3-key').value=d.key||'';
        document.getElementById('llm3-specialty').value=d.specialty||'';
        document.getElementById('llm3-enabled').checked=d.enabled!==false;
        document.getElementById('llm3-mode').value=d.mode||'using';
        document.getElementById('llm3-control-url').value=d.control_url||'';
        document.getElementById('llm3-timeout').value=d.timeout||300;
        updateLLMBadge('llm3-badge','llm3-badge-text',d.url,d.model,d.enabled!==false,d.specialty);
        updateHeaderBadge('hdr-llm3','hb-llm3','LLM3: ',d.enabled&&d.model?d.model:'');
    }catch(e){}
}
async function saveLLM3(){
    var url=document.getElementById('llm3-url').value.trim();
    var model=document.getElementById('llm3-model').value.trim();
    var key=document.getElementById('llm3-key').value.trim();
    var specialty=document.getElementById('llm3-specialty').value.trim();
    var enabled=document.getElementById('llm3-enabled').checked;
    var mode=document.getElementById('llm3-mode').value;
    var controlURL=document.getElementById('llm3-control-url').value.trim();
    var timeout=parseInt(document.getElementById('llm3-timeout').value)||300;
    try{
        await fetch('/api/llm3_config',{method:'POST',
            body:JSON.stringify({url:url,model:model,key:key,specialty:specialty,enabled:enabled,mode:mode,control_url:controlURL,timeout:timeout}),
            headers:{'Content-Type':'application/json'}});
        showStatus('llm3-status','✓ Saved successfully.',true);
        updateLLMBadge('llm3-badge','llm3-badge-text',url,model,enabled,specialty);
        updateHeaderBadge('hdr-llm3','hb-llm3','LLM3: ',enabled&&model?model:'');
    }catch(e){ showStatus('llm3-status','✗ Save failed: '+e,false); }
}
async function testLLM3(){
    document.getElementById('llm3-status').textContent='⏳ Testing...';
    document.getElementById('llm3-status').style.color='#ce9178';
    document.getElementById('llm3-test-result').style.display='none';
    try{
        var d=await(await fetch('/api/llm3_test',{method:'POST'})).json();
        if(d.error){ showStatus('llm3-status','✗ '+d.error,false); }
        else{
            showStatus('llm3-status','✓ Connection successful!',true);
            var r=document.getElementById('llm3-test-result');
            r.textContent=d.response; r.style.display='block';
        }
    }catch(e){ showStatus('llm3-status','✗ Request failed: '+e,false); }
}

/* ---- Operational LLM ---- */
async function loadOpLLM(){
    try{
        var d=await(await fetch('/api/op_llm_config')).json();
        document.getElementById('opllm-url').value=d.url||'';
        document.getElementById('opllm-model').value=d.model||'';
        document.getElementById('opllm-key').value=d.key||'';
        document.getElementById('opllm-enabled').checked=d.enabled!==false;
        document.getElementById('opllm-mode').value=d.mode||'using';
        document.getElementById('opllm-control-url').value=d.control_url||'';
        document.getElementById('opllm-timeout').value=d.timeout||300;
        updateBadge('opllm-badge','opllm-badge-text',d.url,d.model);
        updateHeaderBadge('hdr-opllm','hb-opllm','OpLLM: ',d.enabled&&d.model?d.model:'');
    }catch(e){}
}
async function saveOpLLM(){
    var url=document.getElementById('opllm-url').value.trim();
    var model=document.getElementById('opllm-model').value.trim();
    var key=document.getElementById('opllm-key').value.trim();
    var enabled=document.getElementById('opllm-enabled').checked;
    var mode=document.getElementById('opllm-mode').value;
    var controlURL=document.getElementById('opllm-control-url').value.trim();
    var timeout=parseInt(document.getElementById('opllm-timeout').value)||300;
    try{
        await fetch('/api/op_llm_config',{method:'POST',
            body:JSON.stringify({url:url,model:model,key:key,enabled:enabled,mode:mode,control_url:controlURL,timeout:timeout}),
            headers:{'Content-Type':'application/json'}});
        showStatus('opllm-status','✓ Saved successfully.',true);
        updateBadge('opllm-badge','opllm-badge-text',url,model);
        updateHeaderBadge('hdr-opllm','hb-opllm','OpLLM: ',enabled&&model?model:'');
    }catch(e){ showStatus('opllm-status','✗ Save failed: '+e,false); }
}
async function testOpLLM(){
    document.getElementById('opllm-status').textContent='⏳ Testing...';
    document.getElementById('opllm-status').style.color='#ce9178';
    document.getElementById('opllm-test-result').style.display='none';
    try{
        var d=await(await fetch('/api/op_llm_test',{method:'POST'})).json();
        if(d.error){ showStatus('opllm-status','✗ '+d.error,false); }
        else{
            showStatus('opllm-status','✓ Connection successful!',true);
            var r=document.getElementById('opllm-test-result');
            r.textContent=d.response; r.style.display='block';
        }
    }catch(e){ showStatus('opllm-status','✗ Request failed: '+e,false); }
}

/* ---- New chat / send task ---- */
async function newChat(){
    if(!logs||!logs.length){alert('Nothing in the current chat to save.');return;}
    await fetch('/api/new_chat',{method:'POST'});
    logs=[];
    renderActivity();
    filterAudit();
    sessions=await(await fetch('/api/sessions')).json();
    renderSessions(); switchTab('sessions');
}
async function sendTask(){
    var inp=document.getElementById('user-input');
    var txt=inp.value.trim();
    if(!txt) return;
    inp.value=''; inp.style.height='42px';
    showTyping(true);
    await fetch('/api/task',{method:'POST',body:JSON.stringify({task:txt}),headers:{'Content-Type':'application/json'}});
    setTimeout(fetchChatMessages,200);
}
function handleEnter(e){
    if(e.key==='Enter'&&!e.shiftKey){ e.preventDefault(); sendTask(); }
}
document.addEventListener('DOMContentLoaded',function(){
    var inp=document.getElementById('user-input');
    if(inp){ inp.addEventListener('input',function(){
        this.style.height='42px';
        this.style.height=Math.min(this.scrollHeight,120)+'px';
    }); inp.addEventListener('keypress',handleEnter); }
});
function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

/* ---- Host / Root Access ---- */
async function loadHostConfig(){
    try{
        var d=await(await fetch('/api/host_config')).json();
        document.getElementById('host-user').value=d.user||'';
        document.getElementById('host-pass').value=d.pass||'';
        updateHostBadge(d.user, !!d.pass_set);
    }catch(e){}
}
function updateHostBadge(user, hasPass){
    var badge=document.getElementById('host-badge');
    var text=document.getElementById('host-badge-text');
    var hdr=document.getElementById('hdr-root');
    if(hasPass){
        badge.className='llm-status-badge badge-ok';
        text.textContent='Active: running as '+(user||'root');
        hdr.className='header-badge hb-root';
        hdr.textContent='Root: '+(user||'root');
    } else {
        badge.className='llm-status-badge badge-warn';
        text.textContent='No credentials set';
        hdr.className='header-badge hb-off';
        hdr.textContent='Root: off';
    }
}
async function saveHostConfig(){
    var user=document.getElementById('host-user').value.trim();
    var pass=document.getElementById('host-pass').value;
    try{
        await fetch('/api/host_config',{method:'POST',body:JSON.stringify({user:user,pass:pass}),headers:{'Content-Type':'application/json'}});
        showStatus('host-status','✓ Credentials saved.',true);
        updateHostBadge(user, pass.length>0);
    }catch(e){ showStatus('host-status','✗ Save failed: '+e,false); }
}
async function clearHostConfig(){
    if(!confirm('Clear host credentials? The agent will no longer run as root.')) return;
    try{
        await fetch('/api/host_config',{method:'POST',body:JSON.stringify({user:'',pass:''}),headers:{'Content-Type':'application/json'}});
        document.getElementById('host-user').value='';
        document.getElementById('host-pass').value='';
        showStatus('host-status','✓ Credentials cleared.',true);
        updateHostBadge('',false);
    }catch(e){ showStatus('host-status','✗ Failed: '+e,false); }
}
async function verifyHostAccess(){
    showStatus('host-status','⏳ Verifying...',true);
    document.getElementById('host-status').style.color='#ce9178';
    document.getElementById('host-verify-result').style.display='none';
    try{
        var r=await fetch('/api/host_verify',{method:'POST'});
        var d=await r.json();
        if(d.error){ showStatus('host-status','✗ '+d.error,false); }
        else{
            showStatus('host-status','✓ Access verified!',true);
            var el=document.getElementById('host-verify-result');
            el.textContent=d.output; el.style.display='block';
        }
    }catch(e){ showStatus('host-status','✗ Request failed: '+e,false); }
}

/* ---- UI Title ---- */
async function loadUITitle(){
    try{
        var d=await(await fetch('/api/ui_title')).json();
        var t=d.title||'Lily';
        document.getElementById('ui-title-input').value=t;
        document.title=t;
        document.getElementById('header-title').textContent=t;
    }catch(e){}
}
async function saveUITitle(){
    var t=document.getElementById('ui-title-input').value.trim()||'Lily';
    try{
        await fetch('/api/ui_title',{method:'POST',body:JSON.stringify({title:t}),headers:{'Content-Type':'application/json'}});
        document.title=t;
        document.getElementById('header-title').textContent=t;
        var s=document.getElementById('ui-title-status');
        s.textContent='✓ Saved'; s.style.color='#6a9955';
        setTimeout(function(){s.textContent='';},3000);
    }catch(e){
        var s=document.getElementById('ui-title-status');
        s.textContent='✗ Failed'; s.style.color='#f44747';
    }
}

/* ---- Tasks ---- */
var allTasks=[], taskFilter='all', editingTaskId=null;

function setTaskFilter(f, el){
    taskFilter=f;
    document.querySelectorAll('.filter-btn').forEach(function(b){ b.classList.remove('active'); });
    el.classList.add('active');
    renderTasks();
}

function renderTasks(){
    var c=document.getElementById('task-list');
    var f=taskFilter==='all'?allTasks:allTasks.filter(function(t){return t.status===taskFilter;});
    ['pending','running','complete','failed'].forEach(function(s){
        var el=document.getElementById('stat-'+s);
        if(el) el.textContent=allTasks.filter(function(t){return t.status===s;}).length;
    });
    if(!f.length){ c.innerHTML='<div class="empty-state">No tasks match.</div>'; return; }
    var h='';
    f.slice().reverse().forEach(function(t){
        var pLabel=['','🔴 High','🟡 Normal','🟢 Low'][t.priority]||'';
        var pClass=['','tb-p1','tb-p2','tb-p3'][t.priority]||'';
        if(editingTaskId===t.id){
            h+='<div class="task-edit-row" id="edit-row-'+t.id+'">'
              +'<input type="text" id="et-title-'+t.id+'" value="'+esc(t.title)+'" placeholder="Title">'
              +'<textarea id="et-desc-'+t.id+'" placeholder="Description">'+esc(t.description||'')+'</textarea>'
              +'<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">'
              +'<select id="et-status-'+t.id+'">'
              +['pending','running','complete','failed'].map(function(s){
                  return '<option value="'+s+'"'+(t.status===s?' selected':'')+'>'+s+'</option>';
              }).join('')+'</select>'
              +'<select id="et-prio-'+t.id+'">'
              +[['1','🔴 High'],['2','🟡 Normal'],['3','🟢 Low']].map(function(p){
                  return '<option value="'+p[0]+'"'+(t.priority==p[0]?' selected':'')+'>'+p[1]+'</option>';
              }).join('')+'</select>'
              +'</div>'
              +'<input type="text" id="et-result-'+t.id+'" value="'+esc(t.result||'')+'" placeholder="Result / notes">'
              +'<div class="task-edit-btns">'
              +'<button class="btn btn-green" style="padding:5px 12px;font-size:0.78rem;" onclick="saveTaskEdit('+t.id+')">💾 Save</button>'
              +'<button class="btn btn-amber" style="padding:5px 12px;font-size:0.78rem;" onclick="cancelTaskEdit()">Cancel</button>'
              +'</div></div>';
        } else {
            h+='<div class="task-item task-'+t.status+'">'
              +'<div class="task-title"><span class="task-badge tb-'+t.status+'">'+t.status.toUpperCase()+'</span> '+esc(t.title)+'</div>';
            if(t.description) h+='<div class="task-desc">'+esc(t.description)+'</div>';
            if(t.result) h+='<div class="task-result">→ '+esc(t.result)+'</div>';
            h+='<div class="task-meta"><span class="'+pClass+'">'+pLabel+'</span>'
              +'<span>#'+t.id+' · '+new Date(t.created_at).toLocaleString()+'</span></div>'
              +'<div class="task-actions">'
              +'<button class="task-act-btn tact-edit" onclick="startTaskEdit('+t.id+')">✏ Edit</button>'
              +'<button class="task-act-btn tact-status" onclick="cycleStatus('+t.id+',\''+t.status+'\')" title="Change status">⟳ Status</button>'
              +'<button class="task-act-btn tact-delete" onclick="deleteTask('+t.id+')">✕ Delete</button>'
              +'</div></div>';
        }
    });
    c.innerHTML=h;
}

function startTaskEdit(id){ editingTaskId=id; renderTasks(); var el=document.getElementById('edit-row-'+id); if(el) el.scrollIntoView({block:'nearest'}); }
function cancelTaskEdit(){ editingTaskId=null; renderTasks(); }

async function saveTaskEdit(id){
    var title  =document.getElementById('et-title-'+id).value.trim();
    var desc   =document.getElementById('et-desc-'+id).value.trim();
    var status =document.getElementById('et-status-'+id).value;
    var priority=parseInt(document.getElementById('et-prio-'+id).value);
    var result =document.getElementById('et-result-'+id).value.trim();
    if(!title) return;
    try{
        await fetch('/api/tasks/'+id,{method:'PUT',
            body:JSON.stringify({title:title,description:desc,status:status,priority:priority,result:result}),
            headers:{'Content-Type':'application/json'}});
        editingTaskId=null; fetchTasks();
    }catch(e){ alert('Save failed: '+e); }
}

async function deleteTask(id){
    if(!confirm('Delete this task?')) return;
    try{ await fetch('/api/tasks/'+id,{method:'DELETE'}); fetchTasks(); }catch(e){ alert('Delete failed: '+e); }
}

var statusCycle=['pending','running','complete','failed'];
async function cycleStatus(id, current){
    var next=statusCycle[(statusCycle.indexOf(current)+1)%statusCycle.length];
    try{ await fetch('/api/tasks/'+id,{method:'PUT',body:JSON.stringify({status:next}),headers:{'Content-Type':'application/json'}}); fetchTasks(); }catch(e){}
}

async function fetchTasks(){
    try{
        var d=await(await fetch('/api/tasks')).json();
        if(JSON.stringify(d)!==JSON.stringify(allTasks)){ allTasks=d||[]; renderTasks(); updateTaskBadge(); }
    }catch(e){}
}

function updateTaskBadge(){
    var pending=allTasks.filter(function(t){return t.status==='pending';}).length;
    var running=allTasks.filter(function(t){return t.status==='running';}).length;
    var hdr=document.getElementById('hdr-tasks');
    if(!hdr) return;
    if(running>0){ hdr.className='header-badge hb-task-run'; hdr.textContent='Tasks: '+running+' running'; }
    else if(pending>0){ hdr.className='header-badge hb-task-pend'; hdr.textContent='Tasks: '+pending+' pending'; }
    else{ hdr.className='header-badge hb-off'; hdr.textContent='Tasks: idle'; }
}

async function addTask(){
    var title=document.getElementById('task-title').value.trim();
    var desc=document.getElementById('task-desc').value.trim();
    var priority=parseInt(document.getElementById('task-priority').value);
    if(!title){ document.getElementById('task-add-status').textContent='Title is required.'; return; }
    try{
        var r=await fetch('/api/tasks',{method:'POST',
            body:JSON.stringify({title:title,description:desc,priority:priority}),
            headers:{'Content-Type':'application/json'}});
        var d=await r.json();
        document.getElementById('task-title').value='';
        document.getElementById('task-desc').value='';
        var s=document.getElementById('task-add-status');
        s.textContent='✓ Task #'+d.id+' created.'; s.style.color='#6a9955';
        setTimeout(function(){s.textContent='';},3000);
        fetchTasks();
    }catch(e){
        var s=document.getElementById('task-add-status');
        s.textContent='✗ Failed: '+e; s.style.color='#f44747';
    }
}

/* ---- Modules ---- */
function switchModTab(name, el){
    ['browse','installed','gomod'].forEach(function(t){ document.getElementById('mod-pane-'+t).style.display='none'; });
    document.getElementById('mod-pane-'+name).style.display='flex';
    document.getElementById('mod-pane-'+name).style.flexDirection='column';
    document.querySelectorAll('.mod-tab').forEach(function(b){ b.classList.remove('active'); });
    el.classList.add('active');
    if(name==='installed') loadInstalledModules();
    if(name==='gomod') loadGoMod();
}

async function searchModules(){
    var q=document.getElementById('mod-search-input').value.trim();
    if(!q) return;
    var s=document.getElementById('mod-search-status');
    s.textContent='⏳ Searching...'; s.style.color='#ce9178';
    document.getElementById('mod-results').innerHTML='';
    try{
        var r=await fetch('/api/modules/search?q='+encodeURIComponent(q));
        var d=await r.json();
        s.textContent='';
        renderModResults(d.results||[]);
    }catch(e){ s.textContent='✗ Search failed: '+e; s.style.color='#f44747'; }
}

function renderModResults(results){
    var c=document.getElementById('mod-results');
    if(!results.length){ c.innerHTML='<div class="empty-state">No results found.</div>'; return; }
    var h='';
    results.forEach(function(m){
        h+='<div class="mod-result">'
          +'<div class="mod-name">'+esc(m.path)+'</div>'
          +(m.synopsis?'<div class="mod-synopsis">'+esc(m.synopsis)+'</div>':'')
          +'<div class="mod-meta">'
          +(m.version?'<span class="mod-ver">'+esc(m.version)+'</span>':'')
          +(m.license?'<span class="mod-license">'+esc(m.license)+'</span>':'')
          +'<button class="mod-btn mod-btn-add" onclick="installModule(\''+esc(m.path)+'\',\'latest\')">+ Install</button>'
          +'</div></div>';
    });
    c.innerHTML=h;
}

async function installModule(path, version){
    var s=document.getElementById('mod-search-status');
    s.textContent='⏳ Installing '+path+'...'; s.style.color='#ce9178';
    try{
        var r=await fetch('/api/modules/add',{method:'POST',
            body:JSON.stringify({module_path:path,version:version||'latest'}),
            headers:{'Content-Type':'application/json'}});
        var d=await r.json();
        if(d.error){ s.textContent='✗ '+d.error; s.style.color='#f44747'; }
        else{ s.textContent='✓ Installed '+path; s.style.color='#6a9955'; }
        setTimeout(function(){s.textContent='';},4000);
    }catch(e){ s.textContent='✗ Failed: '+e; s.style.color='#f44747'; }
}

async function loadInstalledModules(){
    var c=document.getElementById('mod-installed-list');
    c.innerHTML='<div class="empty-state">Loading...</div>';
    try{
        var d=await(await fetch('/api/modules/installed')).json();
        renderInstalledMods(d.modules||[]);
    }catch(e){ c.innerHTML='<div class="empty-state">Error loading modules.</div>'; }
}

function renderInstalledMods(mods){
    var c=document.getElementById('mod-installed-list');
    if(!mods.length){ c.innerHTML='<div class="empty-state">No dependencies found.</div>'; return; }
    var h='';
    mods.forEach(function(m){
        if(m.path==='') return;
        h+='<div class="installed-mod">'
          +'<span class="installed-mod-path">'+esc(m.path)+'</span>'
          +(m.version?'<span class="installed-mod-ver">'+esc(m.version)+'</span>':'')
          +'<button class="mod-btn mod-btn-rm" onclick="removeModuleUI(\''+esc(m.path)+'\')">✕</button>'
          +'</div>';
    });
    c.innerHTML=h;
}

async function removeModuleUI(path){
    if(!confirm('Remove '+path+'?')) return;
    var s=document.getElementById('mod-install-status');
    s.textContent='⏳ Removing...'; s.style.color='#ce9178';
    try{
        var d=await(await fetch('/api/modules/remove',{method:'POST',
            body:JSON.stringify({module_path:path}),headers:{'Content-Type':'application/json'}})).json();
        if(d.error){ s.textContent='✗ '+d.error; s.style.color='#f44747'; }
        else{ s.textContent='✓ Removed '+path; s.style.color='#6a9955'; loadInstalledModules(); }
        setTimeout(function(){s.textContent='';},4000);
    }catch(e){ s.textContent='✗ Failed: '+e; s.style.color='#f44747'; }
}

async function addModuleManual(){
    var path=document.getElementById('mod-manual-input').value.trim();
    if(!path) return;
    installModule(path,'latest');
    document.getElementById('mod-manual-input').value='';
}

async function loadGoMod(){
    try{
        var d=await(await fetch('/api/modules/gomod')).json();
        document.getElementById('mod-gomod-content').value=d.content||'(go.mod not found)';
    }catch(e){}
}

/* ---- Web Search ---- */
var selectedProvider='duckduckgo';

function selectProvider(p){
    selectedProvider=p;
    document.querySelectorAll('.provider-card').forEach(function(c){ c.classList.remove('selected'); });
    document.getElementById('prov-'+p).classList.add('selected');
    var kf=document.getElementById('search-key-fields');
    var cxg=document.getElementById('search-cx-group');
    var hint=document.getElementById('search-key-hint');
    if(p==='duckduckgo'){ kf.style.display='none'; cxg.style.display='none'; }
    else if(p==='google'){
        kf.style.display='block'; cxg.style.display='block';
        if(hint) hint.textContent='Google Custom Search API key from console.developers.google.com';
    } else {
        kf.style.display='block'; cxg.style.display='none';
        if(hint) hint.textContent='Brave Search API key from api.search.brave.com';
    }
}

async function loadSearchConfig(){
    try{
        var d=await(await fetch('/api/websearch_config')).json();
        selectProvider(d.provider||'duckduckgo');
        document.getElementById('search-api-key').value=d.key||'';
        document.getElementById('search-cx').value=d.cx||'';
    }catch(e){}
}

async function saveSearchConfig(){
    var key=document.getElementById('search-api-key').value.trim();
    var cx=document.getElementById('search-cx').value.trim();
    try{
        await fetch('/api/websearch_config',{method:'POST',
            body:JSON.stringify({provider:selectedProvider,key:key,cx:cx}),
            headers:{'Content-Type':'application/json'}});
        showStatus('search-status','✓ Saved.',true);
    }catch(e){ showStatus('search-status','✗ '+e,false); }
}

async function testSearch(){
    var q=document.getElementById('search-test-query').value.trim()||'latest AI news';
    showStatus('search-status','⏳ Searching...',true);
    document.getElementById('search-status').style.color='#ce9178';
    var box=document.getElementById('search-test-box');
    box.style.display='none';
    try{
        var d=await(await fetch('/api/websearch_test',{method:'POST',
            body:JSON.stringify({query:q}),headers:{'Content-Type':'application/json'}})).json();
        showStatus('search-status','✓ Results received.',true);
        box.textContent=d.result||'No results.'; box.style.display='block';
    }catch(e){ showStatus('search-status','✗ '+e,false); }
}

/* ---- Social ---- */
async function loadSocialConfig(){
    try{
        var d=await(await fetch('/api/social_config')).json();
        document.getElementById('soc-discord-token').value=d.discord_token||'';
        document.getElementById('soc-discord-channel').value=d.discord_channel||'';
        document.getElementById('soc-twitter-key').value=d.twitter_key||'';
        document.getElementById('soc-twitter-secret').value=d.twitter_secret||'';
        document.getElementById('soc-twitter-token').value=d.twitter_token||'';
        document.getElementById('soc-twitter-token-sec').value=d.twitter_token_sec||'';
        document.getElementById('soc-telegram-token').value=d.telegram_token||'';
        document.getElementById('soc-telegram-chat').value=d.telegram_chat_id||'';
        document.getElementById('soc-slack-token').value=d.slack_token||'';
        document.getElementById('soc-slack-channel').value=d.slack_channel||'';
        document.getElementById('soc-wa-sid').value=d.whatsapp_sid||'';
        document.getElementById('soc-wa-token').value=d.whatsapp_token||'';
        document.getElementById('soc-wa-from').value=d.whatsapp_from||'';
        document.getElementById('soc-wa-to').value=d.whatsapp_to||'';
        ['discord','twitter','telegram','slack','whatsapp'].forEach(function(p){
            var dot=document.getElementById('dot-'+p); if(!dot) return;
            var hasKey=false;
            if(p==='discord')  hasKey=(d.discord_token||'').length>4;
            if(p==='twitter')  hasKey=(d.twitter_key||'').length>4;
            if(p==='telegram') hasKey=(d.telegram_token||'').length>4;
            if(p==='slack')    hasKey=(d.slack_token||'').length>4;
            if(p==='whatsapp') hasKey=(d.whatsapp_sid||'').length>4;
            dot.classList.toggle('on', hasKey);
        });
    }catch(e){}
}

async function saveSocialConfig(){
    var payload={
        discord_token: document.getElementById('soc-discord-token').value,
        discord_channel: document.getElementById('soc-discord-channel').value,
        twitter_key: document.getElementById('soc-twitter-key').value,
        twitter_secret: document.getElementById('soc-twitter-secret').value,
        twitter_token: document.getElementById('soc-twitter-token').value,
        twitter_token_sec: document.getElementById('soc-twitter-token-sec').value,
        telegram_token: document.getElementById('soc-telegram-token').value,
        telegram_chat_id: document.getElementById('soc-telegram-chat').value,
        slack_token: document.getElementById('soc-slack-token').value,
        slack_channel: document.getElementById('soc-slack-channel').value,
        whatsapp_sid: document.getElementById('soc-wa-sid').value,
        whatsapp_token: document.getElementById('soc-wa-token').value,
        whatsapp_from: document.getElementById('soc-wa-from').value,
        whatsapp_to: document.getElementById('soc-wa-to').value,
    };
    try{
        await fetch('/api/social_config',{method:'POST',body:JSON.stringify(payload),headers:{'Content-Type':'application/json'}});
        showStatus('social-save-status','✓ All credentials saved.',true);
        loadSocialConfig();
    }catch(e){ showStatus('social-save-status','✗ '+e,false); }
}

async function testSocial(platform){
    var s=document.getElementById('soc-status-'+platform);
    if(s){ s.textContent='⏳ Sending...'; s.style.color='#ce9178'; }
    try{
        var d=await(await fetch('/api/social_test',{method:'POST',
            body:JSON.stringify({platform:platform,message:'✅ Test from agent — '+new Date().toLocaleTimeString()}),
            headers:{'Content-Type':'application/json'}})).json();
        if(s){
            s.textContent=d.ok?'✓ '+d.result:'✗ '+d.result;
            s.style.color=d.ok?'#6a9955':'#f44747';
            setTimeout(function(){s.textContent='';s.style.color='';},5000);
        }
    }catch(e){ if(s){ s.textContent='✗ '+e; s.style.color='#f44747'; } }
}

/* ---- Init ---- */
loadPersonality();
loadUITitle();
loadHostConfig();
loadSearchConfig();
loadSocialConfig();
loadMainLLM();
loadLLM1();
loadLLM2();
loadLLM3();
loadOpLLM();
setInterval(fetchData,1000);
fetchData();

</script>
</body>
</html>`
