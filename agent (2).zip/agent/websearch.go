package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

type SearchResult struct {
	Title   string `json:"title"`
	URL     string `json:"url"`
	Snippet string `json:"snippet"`
}

func init() {
	registerTool("web_search", webSearch)
	registerTool("fetch_url", fetchURL)
	http.HandleFunc("/api/websearch_config", webSearchConfigHandler)
	http.HandleFunc("/api/websearch_test", webSearchTestHandler)
}

func webSearch(params map[string]interface{}) string {
	query, _ := params["query"].(string)
	if query == "" {
		return "Error: 'query' is required."
	}
	mu.RLock()
	provider := webSearchProvider
	key := webSearchKey
	cx := webSearchCX
	mu.RUnlock()

	auditLog("WEBSEARCH", fmt.Sprintf("Searching [%s]: %s", provider, query))

	var results []SearchResult
	var err error

	switch strings.ToLower(provider) {
	case "google":
		results, err = googleSearch(query, key, cx)
	case "brave":
		results, err = braveSearch(query, key)
	default:
		results, err = duckDuckGoSearch(query)
	}

	if err != nil {
		auditLog("ERROR", fmt.Sprintf("Web search failed: %v", err))
		return fmt.Sprintf("Search failed: %v", err)
	}
	if len(results) == 0 {
		return "No results found."
	}
	var lines []string
	for i, r := range results {
		lines = append(lines, fmt.Sprintf("[%d] %s\n    %s\n    %s", i+1, r.Title, r.URL, r.Snippet))
	}
	auditLog("WEBSEARCH", fmt.Sprintf("Got %d results for: %s", len(results), query))
	return strings.Join(lines, "\n\n")
}

func duckDuckGoSearch(query string) ([]SearchResult, error) {
	url := "https://html.duckduckgo.com/html/?q=" + strings.ReplaceAll(query, " ", "+")
	client := &http.Client{Timeout: 10 * time.Second}
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("User-Agent", "Mozilla/5.0 (compatible; AgentBot/1.0)")
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	html := string(body)

	var results []SearchResult
	marker := `class="result__title"`
	pos := 0
	for len(results) < 8 {
		idx := strings.Index(html[pos:], marker)
		if idx < 0 {
			break
		}
		pos += idx + len(marker)
		// Extract title
		tStart := strings.Index(html[pos:], ">")
		if tStart < 0 {
			continue
		}
		tSub := html[pos+tStart+1:]
		tEnd := strings.Index(tSub, "</a>")
		title := ""
		if tEnd >= 0 {
			title = stripHTML(tSub[:tEnd])
		}
		// Extract URL
		urlMarker := `class="result__url"`
		uIdx := strings.Index(html[pos:], urlMarker)
		href := ""
		if uIdx >= 0 {
			uSub := html[pos+uIdx:]
			uTagEnd := strings.Index(uSub, ">")
			if uTagEnd >= 0 {
				uText := uSub[uTagEnd+1:]
				uClose := strings.Index(uText, "<")
				if uClose >= 0 {
					href = "https://" + strings.TrimSpace(uText[:uClose])
				}
			}
		}
		// Extract snippet
		snipMarker := `class="result__snippet"`
		sIdx := strings.Index(html[pos:], snipMarker)
		snippet := ""
		if sIdx >= 0 {
			sSub := html[pos+sIdx:]
			sTagEnd := strings.Index(sSub, ">")
			if sTagEnd >= 0 {
				sText := sSub[sTagEnd+1:]
				sClose := strings.Index(sText, "</a>")
				if sClose >= 0 {
					snippet = stripHTML(sText[:sClose])
				}
			}
		}
		if title != "" {
			results = append(results, SearchResult{Title: title, URL: href, Snippet: snippet})
		}
	}
	return results, nil
}

func googleSearch(query, key, cx string) ([]SearchResult, error) {
	if key == "" || cx == "" {
		return nil, fmt.Errorf("Google API key and Custom Search Engine ID required")
	}
	url := fmt.Sprintf("https://www.googleapis.com/customsearch/v1?key=%s&cx=%s&q=%s&num=8", key, cx, strings.ReplaceAll(query, " ", "+"))
	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var data struct {
		Items []struct {
			Title   string `json:"title"`
			Link    string `json:"link"`
			Snippet string `json:"snippet"`
		} `json:"items"`
	}
	if err := json.Unmarshal(body, &data); err != nil {
		return nil, err
	}
	var results []SearchResult
	for _, item := range data.Items {
		results = append(results, SearchResult{Title: item.Title, URL: item.Link, Snippet: item.Snippet})
	}
	return results, nil
}

func braveSearch(query, key string) ([]SearchResult, error) {
	if key == "" {
		return nil, fmt.Errorf("Brave Search API key required")
	}
	url := "https://api.search.brave.com/res/v1/web/search?q=" + strings.ReplaceAll(query, " ", "+") + "&count=8"
	client := &http.Client{Timeout: 10 * time.Second}
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("Accept", "application/json")
	req.Header.Set("X-Subscription-Token", key)
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var data struct {
		Web struct {
			Results []struct {
				Title       string `json:"title"`
				URL         string `json:"url"`
				Description string `json:"description"`
			} `json:"results"`
		} `json:"web"`
	}
	if err := json.Unmarshal(body, &data); err != nil {
		return nil, err
	}
	var results []SearchResult
	for _, r := range data.Web.Results {
		results = append(results, SearchResult{Title: r.Title, URL: r.URL, Snippet: r.Description})
	}
	return results, nil
}

func stripHTML(s string) string {
	var b strings.Builder
	inTag := false
	for _, c := range s {
		if c == '<' {
			inTag = true
			continue
		}
		if c == '>' {
			inTag = false
			continue
		}
		if !inTag {
			b.WriteRune(c)
		}
	}
	out := b.String()
	out = strings.ReplaceAll(out, "&amp;", "&")
	out = strings.ReplaceAll(out, "&lt;", "<")
	out = strings.ReplaceAll(out, "&gt;", ">")
	out = strings.ReplaceAll(out, "&quot;", "\"")
	out = strings.ReplaceAll(out, "&#39;", "'")
	out = strings.ReplaceAll(out, "&nbsp;", " ")
	return strings.TrimSpace(out)
}

func fetchURL(params map[string]interface{}) string {
	url, _ := params["url"].(string)
	if url == "" {
		return "Error: 'url' is required."
	}
	auditLog("WEBSEARCH", fmt.Sprintf("Fetching URL: %s", url))
	client := &http.Client{Timeout: 15 * time.Second}
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return fmt.Sprintf("Error: %v", err)
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (compatible; AgentBot/1.0)")
	resp, err := client.Do(req)
	if err != nil {
		return fmt.Sprintf("Fetch failed: %v", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 32000))
	return truncate(stripHTML(string(body)), 4000)
}

// HTTP handlers
func webSearchConfigHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method == "GET" {
		mu.RLock()
		p, k, cx := webSearchProvider, webSearchKey, webSearchCX
		mu.RUnlock()
		json.NewEncoder(w).Encode(map[string]string{
			"provider": p,
			"key":      maskKey(k),
			"cx":       cx,
		})
		return
	}
	if r.Method == "POST" {
		var req struct {
			Provider string `json:"provider"`
			Key      string `json:"key"`
			CX       string `json:"cx"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		mu.Lock()
		webSearchProvider = req.Provider
		if req.Key != "" && !isAllAsterisks(req.Key) {
			webSearchKey = req.Key
		}
		webSearchCX = req.CX
		saveConfigLocked()
		mu.Unlock()
		auditLog("CONFIG", fmt.Sprintf("Web search configured: provider=%s", req.Provider))
		json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
		return
	}
	http.Error(w, "Invalid method", 405)
}

func webSearchTestHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Invalid method", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	var req struct{ Query string `json:"query"` }
	json.NewDecoder(r.Body).Decode(&req)
	if req.Query == "" {
		req.Query = "current time UTC"
	}
	result := webSearch(map[string]interface{}{"query": req.Query})
	json.NewEncoder(w).Encode(map[string]string{"result": result})
}