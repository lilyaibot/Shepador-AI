package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
)

func init() {
	http.HandleFunc("/api/main_llm_config", mainLLMConfigHandler)
	http.HandleFunc("/api/main_llm_test", mainLLMTestHandler)
}

func mainLLMConfigHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method == "GET" {
		mu.RLock()
		u, m, k, t := mainLLMURL, mainLLMModel, mainLLMKey, llmTimeoutSec
		mu.RUnlock()
		json.NewEncoder(w).Encode(map[string]interface{}{
			"url":     u,
			"model":   m,
			"key":     maskKey(k),
			"timeout": t,
		})
		return
	}
	if r.Method == "POST" {
		var req struct {
			URL     string `json:"url"`
			Model   string `json:"model"`
			Key     string `json:"key"`
			Timeout int    `json:"timeout"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		mu.Lock()
		mainLLMURL = strings.TrimRight(req.URL, "/")
		mainLLMModel = req.Model
		if req.Key != "" && !isAllAsterisks(req.Key) {
			mainLLMKey = req.Key
		}
		if req.Timeout > 0 {
			llmTimeoutSec = req.Timeout
		}
		saveConfigLocked()
		mu.Unlock()
		auditLog("CONFIG", fmt.Sprintf("Main LLM updated: model=%s url=%s timeout=%ds", req.Model, req.URL, req.Timeout))
		json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
		return
	}
	http.Error(w, "Invalid method", 405)
}

func mainLLMTestHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Invalid method", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	result, err := chatWithMainLLM([]Message{
		{Role: "system", Content: "You are a helpful assistant."},
		{Role: "user", Content: "Reply with exactly one sentence confirming you are online and state your model name."},
	})
	if err != nil {
		json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		return
	}
	auditLog("CONFIG", "Main LLM test connection successful.")
	json.NewEncoder(w).Encode(map[string]string{"response": result})
}