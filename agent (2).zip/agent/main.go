package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strings"
	"time"
)

const (
	WEB_PORT = "8080"
)

func runAgent() {
	loadConfig()
	go startWebServer()
	go startHeartbeat()
	fmt.Println("[System] Agent Core Online. Heartbeat active.")
	runAgentLoop()
}

func startWebServer() {
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		title := webUITitle
		mu.Unlock()
		page := strings.ReplaceAll(htmlTemplate, "__TITLE__", title)
		fmt.Fprint(w, page)
	})

	// Also register the API endpoint for submitting tasks (from chat)
	http.HandleFunc("/api/task", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "Invalid method", 405)
			return
		}
		var req struct{ Task string `json:"task"` }
		json.NewDecoder(r.Body).Decode(&req)
		if req.Task != "" {
			taskQueue <- req.Task
			mu.Lock()
			chatMessages = append(chatMessages, ChatMessage{Role: "user", Content: req.Task, Timestamp: time.Now()})
			chatTask := Task{
				ID:          len(tasksDb) + 1,
				Title:       truncate(req.Task, 80),
				Description: req.Task,
				Status:      "running",
				Priority:    2,
				CreatedAt:   time.Now(),
				UpdatedAt:   time.Now(),
			}
			tasksDb = append(tasksDb, chatTask)
			saveTasksLocked()
			mu.Unlock()
			auditLog("TASK", fmt.Sprintf("Chat task #%d auto-created: %s", chatTask.ID, chatTask.Title))
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]string{"status": "queued"})
	})

	// Add the UI title API endpoint
	http.HandleFunc("/api/ui_title", uiTitleHandler)

	fmt.Printf("[System] Web Interface ready at http://localhost:%s\n", WEB_PORT)
	http.ListenAndServe(":"+WEB_PORT, nil)
}

func uiTitleHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method == "GET" {
		mu.Lock()
		t := webUITitle
		mu.Unlock()
		json.NewEncoder(w).Encode(map[string]string{"title": t})
		return
	}
	if r.Method == "POST" {
		var req struct{ Title string `json:"title"` }
		json.NewDecoder(r.Body).Decode(&req)
		if req.Title == "" {
			req.Title = "Lily"
		}
		mu.Lock()
		webUITitle = req.Title
		saveConfigLocked()
		mu.Unlock()
		auditLog("CONFIG", fmt.Sprintf("UI title changed to: %s", req.Title))
		json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
		return
	}
	http.Error(w, "Invalid method", 405)
}

func main() {
	initCLI()

	if len(os.Args) < 2 {
		runAgent()
		return
	}

	cmdName := os.Args[1]
	cmdArgs := os.Args[2:]

	if cmdName == "-h" || cmdName == "--help" {
		printHelp()
		return
	}

	cmd, ok := cliCommands[cmdName]
	if !ok {
		fmt.Fprintf(os.Stderr, "Unknown command: %s\nRun 'agent help' for a list of commands.\n", cmdName)
		os.Exit(1)
	}
	cmd.run(cmdArgs)
}