package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"time"
)

const (
	AUDIT_LOG = "audit.log"
)

func auditLog(level, content string) {
	mu.Lock()
	defer mu.Unlock()
	entry := AuditEntry{Timestamp: time.Now(), Level: level, Content: content}
	auditLogs = append(auditLogs, entry)
	f, err := os.OpenFile(AUDIT_LOG, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err == nil {
		jsonEntry, _ := json.Marshal(entry)
		f.WriteString(string(jsonEntry) + "\n")
		f.Close()
	}
	fmt.Printf("[%s] %s\n", level, content)
}

func init() {
	http.HandleFunc("/api/logs", func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		logs := make([]AuditEntry, len(auditLogs))
		copy(logs, auditLogs)
		mu.RUnlock()
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(logs)
	})
}