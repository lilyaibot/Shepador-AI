package main

import (
	"encoding/json"
	"fmt"
	"os"
)

const (
	CONFIG_FILE = "config.json"
	DEFAULT_MAIN_LLM_URL   = "http://localhost:11434"
	DEFAULT_MAIN_LLM_MODEL = "llama3"
)

func loadConfig() {
	mu.Lock()
	defer mu.Unlock()

	// Defaults
	mainLLMURL = DEFAULT_MAIN_LLM_URL
	mainLLMModel = DEFAULT_MAIN_LLM_MODEL
	mainLLMKey = ""
	llm1URL, llm1Model, llm1Key, llm1Specialty = "", "", "", ""
	llm1Enabled, llm1Mode, llm1ControlURL = false, "using", ""
	llm2URL, llm2Model, llm2Key, llm2Specialty = "", "", "", ""
	llm2Enabled, llm2Mode, llm2ControlURL = false, "using", ""
	llm3URL, llm3Model, llm3Key, llm3Specialty = "", "", "", ""
	llm3Enabled, llm3Mode, llm3ControlURL = false, "using", ""
	opLLMURL, opLLMModel, opLLMKey = "", "", ""
	opLLMEnabled, opLLMMode, opLLMControlURL = false, "using", ""
	currentPersonality = ""
	webUITitle = "Lily"
	hostUser = ""
	hostPass = ""
	llmTimeoutSec = 300
	webSearchProvider = "duckduckgo"
	webSearchKey = ""
	webSearchCX = ""
	discordToken, discordChannelID = "", ""
	twitterKey, twitterSecret, twitterToken, twitterTokenSec = "", "", "", ""
	telegramToken, telegramChatID = "", ""
	slackToken, slackChannel = "", ""
	whatsAppSID, whatsAppToken, whatsAppFrom, whatsAppTo = "", "", "", ""

	data, err := os.ReadFile(CONFIG_FILE)
	if err != nil {
		saveConfigLocked()
		return
	}

	var cfg Config
	if err := json.Unmarshal(data, &cfg); err == nil {
		// Main LLM
		if cfg.MainLLMURL != "" {
			mainLLMURL = cfg.MainLLMURL
		}
		if cfg.MainLLMModel != "" {
			mainLLMModel = cfg.MainLLMModel
		}
		mainLLMKey = cfg.MainLLMKey

		// Expert LLMs
		llm1URL = cfg.LLM1URL
		llm1Model = cfg.LLM1Model
		llm1Key = cfg.LLM1Key
		llm1Specialty = cfg.LLM1Specialty
		llm1Enabled = cfg.LLM1Enabled
		llm1Mode = cfg.LLM1Mode
		llm1ControlURL = cfg.LLM1ControlURL

		llm2URL = cfg.LLM2URL
		llm2Model = cfg.LLM2Model
		llm2Key = cfg.LLM2Key
		llm2Specialty = cfg.LLM2Specialty
		llm2Enabled = cfg.LLM2Enabled
		llm2Mode = cfg.LLM2Mode
		llm2ControlURL = cfg.LLM2ControlURL

		llm3URL = cfg.LLM3URL
		llm3Model = cfg.LLM3Model
		llm3Key = cfg.LLM3Key
		llm3Specialty = cfg.LLM3Specialty
		llm3Enabled = cfg.LLM3Enabled
		llm3Mode = cfg.LLM3Mode
		llm3ControlURL = cfg.LLM3ControlURL

		// Operational LLM
		opLLMURL = cfg.OpLLMURL
		opLLMModel = cfg.OpLLMModel
		opLLMKey = cfg.OpLLMKey
		opLLMEnabled = cfg.OpLLMEnabled
		opLLMMode = cfg.OpLLMMode
		opLLMControlURL = cfg.OpLLMControlURL

		// Personality & UI
		currentPersonality = cfg.Personality
		if cfg.WebUITitle != "" {
			webUITitle = cfg.WebUITitle
		}

		// Host
		hostUser = cfg.HostUser
		hostPass = cfg.HostPass

		// Timeout
		if cfg.LLMTimeoutSec > 0 {
			llmTimeoutSec = cfg.LLMTimeoutSec
		} else {
			llmTimeoutSec = 300
		}

		// Web search
		webSearchProvider = cfg.WebSearchProvider
		if webSearchProvider == "" {
			webSearchProvider = "duckduckgo"
		}
		webSearchKey = cfg.WebSearchKey
		webSearchCX = cfg.WebSearchCX

		// Social
		discordToken = cfg.DiscordToken
		discordChannelID = cfg.DiscordChannelID
		twitterKey = cfg.TwitterKey
		twitterSecret = cfg.TwitterSecret
		twitterToken = cfg.TwitterToken
		twitterTokenSec = cfg.TwitterTokenSec
		telegramToken = cfg.TelegramToken
		telegramChatID = cfg.TelegramChatID
		slackToken = cfg.SlackToken
		slackChannel = cfg.SlackChannel
		whatsAppSID = cfg.WhatsAppSID
		whatsAppToken = cfg.WhatsAppToken
		whatsAppFrom = cfg.WhatsAppFrom
		whatsAppTo = cfg.WhatsAppTo
	} else {
		saveConfigLocked()
	}
}

func saveConfigLocked() {
	cfg := Config{
		MainLLMURL:   mainLLMURL,
		MainLLMModel: mainLLMModel,
		MainLLMKey:   mainLLMKey,

		LLM1URL:       llm1URL,
		LLM1Model:     llm1Model,
		LLM1Key:       llm1Key,
		LLM1Specialty: llm1Specialty,
		LLM1Enabled:   llm1Enabled,
		LLM1Mode:      llm1Mode,
		LLM1ControlURL: llm1ControlURL,

		LLM2URL:       llm2URL,
		LLM2Model:     llm2Model,
		LLM2Key:       llm2Key,
		LLM2Specialty: llm2Specialty,
		LLM2Enabled:   llm2Enabled,
		LLM2Mode:      llm2Mode,
		LLM2ControlURL: llm2ControlURL,

		LLM3URL:       llm3URL,
		LLM3Model:     llm3Model,
		LLM3Key:       llm3Key,
		LLM3Specialty: llm3Specialty,
		LLM3Enabled:   llm3Enabled,
		LLM3Mode:      llm3Mode,
		LLM3ControlURL: llm3ControlURL,

		OpLLMURL:       opLLMURL,
		OpLLMModel:     opLLMModel,
		OpLLMKey:       opLLMKey,
		OpLLMEnabled:   opLLMEnabled,
		OpLLMMode:      opLLMMode,
		OpLLMControlURL: opLLMControlURL,

		Personality: currentPersonality,
		WebUITitle:  webUITitle,

		HostUser: hostUser,
		HostPass: hostPass,

		LLMTimeoutSec: llmTimeoutSec,

		WebSearchProvider: webSearchProvider,
		WebSearchKey:      webSearchKey,
		WebSearchCX:       webSearchCX,

		DiscordToken:     discordToken,
		DiscordChannelID: discordChannelID,
		TwitterKey:       twitterKey,
		TwitterSecret:    twitterSecret,
		TwitterToken:     twitterToken,
		TwitterTokenSec:  twitterTokenSec,
		TelegramToken:    telegramToken,
		TelegramChatID:   telegramChatID,
		SlackToken:       slackToken,
		SlackChannel:     slackChannel,
		WhatsAppSID:      whatsAppSID,
		WhatsAppToken:    whatsAppToken,
		WhatsAppFrom:     whatsAppFrom,
		WhatsAppTo:       whatsAppTo,
	}
	data, _ := json.MarshalIndent(cfg, "", "  ")
	os.WriteFile(CONFIG_FILE, data, 0644)
}