package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"sort"
	"strconv"
	"strings"
)

type cliCmd struct {
	usage string
	desc  string
	run   func(args []string)
}

var cliCommands map[string]cliCmd

func initCLI() {
	cliCommands = map[string]cliCmd{
		"start": {
			"start",
			"Start the agent (default when no command given)",
			func(args []string) { runAgent() },
		},
		"task": {
			"task <text>",
			"Send a task to the running agent",
			func(args []string) {
				if len(args) == 0 {
					fmt.Println("Usage: agent task <text>")
					os.Exit(1)
				}
				cliPost("/api/task", map[string]string{"task": strings.Join(args, " ")})
				fmt.Println("✓ Task queued.")
			},
		},
		"chat": {
			"chat",
			"Show recent chat messages",
			func(args []string) {
				var msgs []map[string]interface{}
				cliGetJSON("/api/chat_messages", &msgs)
				if len(msgs) == 0 {
					fmt.Println("(no messages)")
					return
				}
				for _, m := range msgs {
					role, _ := m["role"].(string)
					content, _ := m["content"].(string)
					t, _ := m["timestamp"].(string)
					if len(t) > 16 {
						t = t[:16]
					}
					if role == "user" {
						fmt.Printf("[%s] 👤 %s\n", t, content)
					} else {
						fmt.Printf("[%s] 🤖 %s\n", t, content)
					}
				}
			},
		},
		"new-chat": {
			"new-chat",
			"Clear current chat session and start fresh",
			func(args []string) {
				cliPost("/api/new_chat", nil)
				fmt.Println("✓ New chat session started.")
			},
		},
		"logs": {
			"logs [n]",
			"Show last N audit log entries (default 20)",
			func(args []string) {
				n := 20
				if len(args) > 0 {
					fmt.Sscanf(args[0], "%d", &n)
				}
				var entries []map[string]interface{}
				cliGetJSON("/api/logs", &entries)
				if len(entries) == 0 {
					fmt.Println("(no log entries)")
					return
				}
				start := 0
				if len(entries) > n {
					start = len(entries) - n
				}
				for _, e := range entries[start:] {
					lvl, _ := e["level"].(string)
					msg, _ := e["content"].(string)
					t, _ := e["timestamp"].(string)
					if len(t) > 19 {
						t = t[:19]
					}
					fmt.Printf("[%s] %-12s %s\n", t, lvl, msg)
				}
			},
		},
		"tasks": {
			"tasks [--status pending|running|complete|failed|all]",
			"List tasks (optionally filtered by status)",
			func(args []string) {
				fs := flag.NewFlagSet("tasks", flag.ContinueOnError)
				status := fs.String("status", "all", "Filter by status")
				fs.Parse(args)
				var tasks []map[string]interface{}
				cliGetJSON("/api/tasks", &tasks)
				if len(tasks) == 0 {
					fmt.Println("(no tasks)")
					return
				}
				prio := []string{"", "🔴 HIGH", "🟡 NORMAL", "🟢 LOW"}
				for _, t := range tasks {
					st, _ := t["status"].(string)
					if *status != "all" && st != *status {
						continue
					}
					id := int(t["id"].(float64))
					title, _ := t["title"].(string)
					pri := int(t["priority"].(float64))
					pLabel := ""
					if pri >= 1 && pri <= 3 {
						pLabel = prio[pri]
					}
					result, _ := t["result"].(string)
					fmt.Printf("#%d [%-8s] %s %s\n", id, strings.ToUpper(st), title, pLabel)
					if result != "" {
						fmt.Printf("    → %s\n", result)
					}
				}
			},
		},
		"task-add": {
			"task-add --title <title> [--desc <desc>] [--priority 1|2|3]",
			"Create a new task",
			func(args []string) {
				fs := flag.NewFlagSet("task-add", flag.ContinueOnError)
				title := fs.String("title", "", "Task title (required)")
				desc := fs.String("desc", "", "Task description")
				priority := fs.Int("priority", 2, "Priority: 1=high 2=normal 3=low")
				fs.Parse(args)
				if *title == "" {
					fmt.Println("--title is required")
					os.Exit(1)
				}
				cliPost("/api/tasks", map[string]interface{}{"title": *title, "description": *desc, "priority": *priority})
				fmt.Println("✓ Task created.")
			},
		},
		"task-update": {
			"task-update <id> [--title t] [--desc d] [--status s] [--priority n] [--result r]",
			"Edit a task by ID",
			func(args []string) {
				if len(args) == 0 {
					fmt.Println("Usage: agent task-update <id> [flags]")
					os.Exit(1)
				}
				id := args[0]
				rest := args[1:]
				fs := flag.NewFlagSet("task-update", flag.ContinueOnError)
				title := fs.String("title", "", "New title")
				desc := fs.String("desc", "", "New description")
				status := fs.String("status", "", "New status: pending|running|complete|failed")
				priority := fs.Int("priority", 0, "New priority")
				result := fs.String("result", "", "New result")
				fs.Parse(rest)
				payload := map[string]interface{}{}
				if *title != "" {
					payload["title"] = *title
				}
				if *desc != "" {
					payload["description"] = *desc
				}
				if *status != "" {
					payload["status"] = *status
				}
				if *priority > 0 {
					payload["priority"] = *priority
				}
				if *result != "" {
					payload["result"] = *result
				}
				cliPut("/api/tasks/"+id, payload)
				fmt.Printf("✓ Task #%s updated.\n", id)
			},
		},
		"task-delete": {
			"task-delete <id>",
			"Delete a task by ID",
			func(args []string) {
				if len(args) == 0 {
					fmt.Println("Usage: agent task-delete <id>")
					os.Exit(1)
				}
				cliDelete("/api/tasks/" + args[0])
				fmt.Printf("✓ Task #%s deleted.\n", args[0])
			},
		},
		"memory": {
			"memory [--search query]",
			"List memories (optionally search)",
			func(args []string) {
				fs := flag.NewFlagSet("memory", flag.ContinueOnError)
				search := fs.String("search", "", "Search query")
				fs.Parse(args)
				var mems []map[string]interface{}
				cliGetJSON("/api/memory", &mems)
				q := strings.ToLower(*search)
				for _, m := range mems {
					content, _ := m["content"].(string)
					tags, _ := m["tags"].(string)
					if q != "" && !strings.Contains(strings.ToLower(content), q) && !strings.Contains(strings.ToLower(tags), q) {
						continue
					}
					fmt.Printf("[%s] %s\n", tags, content)
				}
			},
		},
		"sessions": {
			"sessions",
			"List all chat sessions",
			func(args []string) {
				var sessions []map[string]interface{}
				cliGetJSON("/api/sessions", &sessions)
				if len(sessions) == 0 {
					fmt.Println("(no sessions)")
					return
				}
				for _, s := range sessions {
					id, _ := s["id"].(string)
					title, _ := s["title"].(string)
					t, _ := s["created_at"].(string)
					if len(t) > 19 {
						t = t[:19]
					}
					fmt.Printf("[%s] %s — %s\n", t, id[:8], title)
				}
			},
		},
		"personality": {
			"personality [--set <text>] [--show]",
			"Show or set agent personality",
			func(args []string) {
				fs := flag.NewFlagSet("personality", flag.ContinueOnError)
				set := fs.String("set", "", "New personality text")
				show := fs.Bool("show", false, "Show current personality")
				fs.Parse(args)
				if *set != "" {
					cliPost("/api/personality", map[string]string{"personality": *set})
					fmt.Println("✓ Personality updated.")
				} else {
					var d map[string]string
					cliGetJSON("/api/personality", &d)
					fmt.Println(d["personality"])
				}
				_ = show
			},
		},
		"title": {
			"title [--set <text>]",
			"Show or set the agent UI title",
			func(args []string) {
				fs := flag.NewFlagSet("title", flag.ContinueOnError)
				set := fs.String("set", "", "New title")
				fs.Parse(args)
				if *set != "" {
					cliPost("/api/ui_title", map[string]string{"title": *set})
					fmt.Println("✓ Title updated.")
				} else {
					var d map[string]string
					cliGetJSON("/api/ui_title", &d)
					fmt.Println(d["title"])
				}
			},
		},
		"llm1": {
			"llm1 [--url u] [--model m] [--key k] [--specialty s] [--enabled true|false] [--mode using|training] [--control-url cu] [--timeout t]",
			"Configure LLM1",
			func(args []string) {
				fs := flag.NewFlagSet("llm1", flag.ContinueOnError)
				url := fs.String("url", "", "Base URL")
				model := fs.String("model", "", "Model name")
				key := fs.String("key", "", "API key")
				specialty := fs.String("specialty", "", "Specialty description")
				enabled := fs.Bool("enabled", false, "Enable LLM")
				mode := fs.String("mode", "using", "Mode: using or training")
				controlURL := fs.String("control-url", "", "Control endpoint URL")
				timeout := fs.Int("timeout", 0, "Timeout seconds")
				fs.Parse(args)
				payload := map[string]interface{}{}
				if *url != "" {
					payload["url"] = *url
				}
				if *model != "" {
					payload["model"] = *model
				}
				if *key != "" {
					payload["key"] = *key
				}
				if *specialty != "" {
					payload["specialty"] = *specialty
				}
				payload["enabled"] = *enabled
				if *mode != "" {
					payload["mode"] = *mode
				}
				if *controlURL != "" {
					payload["control_url"] = *controlURL
				}
				if *timeout > 0 {
					payload["timeout"] = *timeout
				}
				cliPost("/api/llm1_config", payload)
				fmt.Println("✓ LLM1 updated.")
			},
		},
		"llm2": {
			"llm2 [--url u] [--model m] [--key k] [--specialty s] [--enabled true|false] [--mode using|training] [--control-url cu] [--timeout t]",
			"Configure LLM2",
			func(args []string) {
				fs := flag.NewFlagSet("llm2", flag.ContinueOnError)
				url := fs.String("url", "", "Base URL")
				model := fs.String("model", "", "Model name")
				key := fs.String("key", "", "API key")
				specialty := fs.String("specialty", "", "Specialty description")
				enabled := fs.Bool("enabled", false, "Enable LLM")
				mode := fs.String("mode", "using", "Mode: using or training")
				controlURL := fs.String("control-url", "", "Control endpoint URL")
				timeout := fs.Int("timeout", 0, "Timeout seconds")
				fs.Parse(args)
				payload := map[string]interface{}{}
				if *url != "" {
					payload["url"] = *url
				}
				if *model != "" {
					payload["model"] = *model
				}
				if *key != "" {
					payload["key"] = *key
				}
				if *specialty != "" {
					payload["specialty"] = *specialty
				}
				payload["enabled"] = *enabled
				if *mode != "" {
					payload["mode"] = *mode
				}
				if *controlURL != "" {
					payload["control_url"] = *controlURL
				}
				if *timeout > 0 {
					payload["timeout"] = *timeout
				}
				cliPost("/api/llm2_config", payload)
				fmt.Println("✓ LLM2 updated.")
			},
		},
		"llm3": {
			"llm3 [--url u] [--model m] [--key k] [--specialty s] [--enabled true|false] [--mode using|training] [--control-url cu] [--timeout t]",
			"Configure LLM3",
			func(args []string) {
				fs := flag.NewFlagSet("llm3", flag.ContinueOnError)
				url := fs.String("url", "", "Base URL")
				model := fs.String("model", "", "Model name")
				key := fs.String("key", "", "API key")
				specialty := fs.String("specialty", "", "Specialty description")
				enabled := fs.Bool("enabled", false, "Enable LLM")
				mode := fs.String("mode", "using", "Mode: using or training")
				controlURL := fs.String("control-url", "", "Control endpoint URL")
				timeout := fs.Int("timeout", 0, "Timeout seconds")
				fs.Parse(args)
				payload := map[string]interface{}{}
				if *url != "" {
					payload["url"] = *url
				}
				if *model != "" {
					payload["model"] = *model
				}
				if *key != "" {
					payload["key"] = *key
				}
				if *specialty != "" {
					payload["specialty"] = *specialty
				}
				payload["enabled"] = *enabled
				if *mode != "" {
					payload["mode"] = *mode
				}
				if *controlURL != "" {
					payload["control_url"] = *controlURL
				}
				if *timeout > 0 {
					payload["timeout"] = *timeout
				}
				cliPost("/api/llm3_config", payload)
				fmt.Println("✓ LLM3 updated.")
			},
		},
		"opllm": {
			"opllm [--url u] [--model m] [--key k] [--enabled true|false] [--mode using|training] [--control-url cu] [--timeout t]",
			"Configure the operational LLM",
			func(args []string) {
				fs := flag.NewFlagSet("opllm", flag.ContinueOnError)
				url := fs.String("url", "", "Base URL")
				model := fs.String("model", "", "Model name")
				key := fs.String("key", "", "API key")
				enabled := fs.Bool("enabled", false, "Enable LLM")
				mode := fs.String("mode", "using", "Mode: using or training")
				controlURL := fs.String("control-url", "", "Control endpoint URL")
				timeout := fs.Int("timeout", 0, "Timeout seconds")
				fs.Parse(args)
				payload := map[string]interface{}{}
				if *url != "" {
					payload["url"] = *url
				}
				if *model != "" {
					payload["model"] = *model
				}
				if *key != "" {
					payload["key"] = *key
				}
				payload["enabled"] = *enabled
				if *mode != "" {
					payload["mode"] = *mode
				}
				if *controlURL != "" {
					payload["control_url"] = *controlURL
				}
				if *timeout > 0 {
					payload["timeout"] = *timeout
				}
				cliPost("/api/op_llm_config", payload)
				fmt.Println("✓ Operational LLM updated.")
			},
		},
		"llm-test": {
			"llm-test <1|2|3|main|op>",
			"Test connection to an LLM",
			func(args []string) {
				if len(args) == 0 {
					fmt.Println("Usage: agent llm-test <1|2|3|main|op>")
					os.Exit(1)
				}
				ep := map[string]string{
					"1":    "/api/llm1_test",
					"2":    "/api/llm2_test",
					"3":    "/api/llm3_test",
					"main": "/api/main_llm_test",
					"op":   "/api/op_llm_test",
				}
				endpoint, ok := ep[args[0]]
				if !ok {
					fmt.Printf("Unknown LLM: %s\n", args[0])
					os.Exit(1)
				}
				var d map[string]interface{}
				cliPostJSON(endpoint, nil, &d)
				if e, ok := d["error"].(string); ok {
					fmt.Printf("✗ Error: %s\n", e)
				} else {
					fmt.Printf("✓ %s\n", d["response"])
				}
			},
		},
		"llm-control": {
			"llm-control <1|2|3|op> <suspend|wake>",
			"Send suspend/wake command to an LLM's control endpoint",
			func(args []string) {
				if len(args) != 2 {
					fmt.Println("Usage: agent llm-control <1|2|3|op> <suspend|wake>")
					os.Exit(1)
				}
				indexMap := map[string]int{
					"1":  1,
					"2":  2,
					"3":  3,
					"op": 0,
				}
				idx, ok := indexMap[args[0]]
				if !ok {
					fmt.Printf("Unknown LLM: %s\n", args[0])
					os.Exit(1)
				}
				command := args[1]
				if command != "suspend" && command != "wake" {
					fmt.Println("Command must be 'suspend' or 'wake'")
					os.Exit(1)
				}
				err := controlLLM(idx, command)
				if err != nil {
					fmt.Printf("✗ %v\n", err)
				} else {
					fmt.Println("✓ Command sent.")
				}
			},
		},
		"search": {
			"search <query>",
			"Run a web search using the configured provider",
			func(args []string) {
				if len(args) == 0 {
					fmt.Println("Usage: agent search <query>")
					os.Exit(1)
				}
				query := strings.Join(args, " ")
				var d map[string]interface{}
				cliPostJSON("/api/websearch_test", map[string]string{"query": query}, &d)
				fmt.Println(d["result"])
			},
		},
		"search-config": {
			"search-config [--provider duckduckgo|google|brave] [--key k] [--cx id]",
			"Show or set web search configuration",
			func(args []string) {
				if len(args) == 0 {
					var d map[string]interface{}
					cliGetJSON("/api/websearch_config", &d)
					fmt.Printf("Provider: %v\nKey:      %v\nCX:       %v\n", d["provider"], d["key"], d["cx"])
					return
				}
				fs := flag.NewFlagSet("search-config", flag.ContinueOnError)
				provider := fs.String("provider", "", "duckduckgo|google|brave")
				key := fs.String("key", "", "API key")
				cx := fs.String("cx", "", "Google CX ID")
				fs.Parse(args)
				payload := map[string]interface{}{}
				if *provider != "" {
					payload["provider"] = *provider
				}
				if *key != "" {
					payload["key"] = *key
				}
				if *cx != "" {
					payload["cx"] = *cx
				}
				cliPost("/api/websearch_config", payload)
				fmt.Println("✓ Search config updated.")
			},
		},
		"social-send": {
			"social-send <discord|telegram|slack|twitter|whatsapp> <message>",
			"Send a message via a social platform",
			func(args []string) {
				if len(args) < 2 {
					fmt.Println("Usage: agent social-send <platform> <message>")
					os.Exit(1)
				}
				platform := args[0]
				msg := strings.Join(args[1:], " ")
				var d map[string]interface{}
				cliPostJSON("/api/social_test", map[string]string{"platform": platform, "message": msg}, &d)
				if ok, _ := d["ok"].(bool); ok {
					fmt.Printf("✓ %s\n", d["result"])
				} else {
					fmt.Printf("✗ %s\n", d["result"])
				}
			},
		},
	}
}

// HTTP helper functions for CLI commands

func cliPost(path string, body interface{}) {
	cliRequest("POST", path, body, nil)
}

func cliPut(path string, body interface{}) {
	cliRequest("PUT", path, body, nil)
}

func cliDelete(path string) {
	cliRequest("DELETE", path, nil, nil)
}

func cliGetJSON(path string, v interface{}) {
	cliRequest("GET", path, nil, v)
}

func cliPostJSON(path string, body interface{}, v interface{}) {
	cliRequest("POST", path, body, v)
}

func cliRequest(method, path string, body interface{}, result interface{}) {
	var reqBody []byte
	var err error
	if body != nil {
		reqBody, err = json.Marshal(body)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error marshaling request: %v\n", err)
			os.Exit(1)
		}
	}
	url := "http://localhost:8080" + path
	req, err := http.NewRequest(method, url, bytes.NewBuffer(reqBody))
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error creating request: %v\n", err)
		os.Exit(1)
	}
	req.Header.Set("Content-Type", "application/json")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error making request: %v\n", err)
		os.Exit(1)
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		bodyBytes, _ := io.ReadAll(resp.Body)
		fmt.Fprintf(os.Stderr, "HTTP %d: %s\n", resp.StatusCode, string(bodyBytes))
		os.Exit(1)
	}
	if result != nil {
		if err := json.NewDecoder(resp.Body).Decode(result); err != nil {
			fmt.Fprintf(os.Stderr, "Error decoding response: %v\n", err)
			os.Exit(1)
		}
	}
}

// printHelp displays all available commands
func printHelp() {
	fmt.Println("Usage: agent [command] [args]")
	fmt.Println("Commands:")
	names := make([]string, 0, len(cliCommands))
	for name := range cliCommands {
		names = append(names, name)
	}
	sort.Strings(names)
	for _, name := range names {
		cmd := cliCommands[name]
		fmt.Printf("  %-20s %s\n", cmd.usage, cmd.desc)
	}
}