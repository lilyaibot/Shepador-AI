package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strings"
	"time"
)

const (
	MEMORY_FILE = "memory.json"
)

func loadMemory() {
	mu.Lock()
	defer mu.Unlock()
	data, err := os.ReadFile(MEMORY_FILE)
	if err == nil {
		json.Unmarshal(data, &memoryDb)
	}
}

func saveMemoryToFile() {
	mu.Lock()
	defer mu.Unlock()
	data, _ := json.MarshalIndent(memoryDb, "", "  ")
	os.WriteFile(MEMORY_FILE, data, 0644)
}

func storeMemory(params map[string]interface{}) string {
	content, _ := params["content"].(string)
	tagsStr, _ := params["tags"].(string)
	tags := strings.Split(tagsStr, ",")
	for i := range tags {
		tags[i] = strings.TrimSpace(tags[i])
	}
	mu.Lock()
	memoryDb = append(memoryDb, Memory{
		ID:        len(memoryDb) + 1,
		Content:   content,
		Tags:      tags,
		CreatedAt: time.Now(),
	})
	mu.Unlock()
	saveMemoryToFile()
	auditLog("MEMORY", fmt.Sprintf("Auto-Saved: %s", content))
	return "Memory stored."
}

func recallMemory(params map[string]interface{}) string {
	query, _ := params["query"].(string)
	query = strings.ToLower(query)
	mu.RLock()
	defer mu.RUnlock()
	var results []string
	for _, m := range memoryDb {
		if strings.Contains(strings.ToLower(m.Content), query) {
			results = append(results, fmt.Sprintf("[%d] %s", m.ID, m.Content))
		}
	}
	if len(results) == 0 {
		return "No memories found."
	}
	return strings.Join(results, "\n")
}

// HTTP handlers
func init() {
	registerTool("store_memory", storeMemory)
	registerTool("recall_memory", recallMemory)

	http.HandleFunc("/api/memory", func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		defer mu.RUnlock()
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(memoryDb)
	})
}