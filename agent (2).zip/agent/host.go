package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os/exec"
	"strings"
)

func init() {
	http.HandleFunc("/api/host_config", hostConfigHandler)
	http.HandleFunc("/api/host_verify", hostVerifyHandler)
}

func hostConfigHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method == "GET" {
		mu.RLock()
		u, hasPass := hostUser, hostPass != ""
		mu.RUnlock()
		json.NewEncoder(w).Encode(map[string]interface{}{
			"user":      u,
			"pass_set":  hasPass,
			"pass":      "",
		})
		return
	}
	if r.Method == "POST" {
		var req struct {
			User string `json:"user"`
			Pass string `json:"pass"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		mu.Lock()
		hostUser = req.User
		hostPass = req.Pass
		saveConfigLocked()
		mu.Unlock()
		if req.Pass != "" {
			auditLog("CONFIG", fmt.Sprintf("Host credentials set for user: %s", req.User))
		} else {
			auditLog("CONFIG", "Host credentials cleared.")
		}
		json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
		return
	}
	http.Error(w, "Invalid method", 405)
}

func hostVerifyHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Invalid method", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	mu.Lock()
	user, pass := hostUser, hostPass
	mu.Unlock()
	if pass == "" {
		json.NewEncoder(w).Encode(map[string]string{"error": "No password configured. Set credentials first."})
		return
	}
	rootUser := user
	if rootUser == "" {
		rootUser = "root"
	}
	// Run id + whoami to confirm effective identity
	testCmd := fmt.Sprintf("echo %s | sudo -S -u %s bash -c 'id && whoami && echo HOST=$(hostname)'",
		shellQuote(pass), shellQuote(rootUser))
	cmd := exec.Command("bash", "-c", testCmd)
	out, err := cmd.CombinedOutput()
	if err != nil {
		json.NewEncoder(w).Encode(map[string]string{"error": fmt.Sprintf("Failed: %v\n%s", err, string(out))})
		return
	}
	auditLog("CONFIG", fmt.Sprintf("Host root access verified for user: %s", rootUser))
	json.NewEncoder(w).Encode(map[string]string{"output": strings.TrimSpace(string(out))})
}