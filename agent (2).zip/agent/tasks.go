package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

const (
	TASKS_FILE = "tasks.json"
)

func loadTasks() {
	mu.Lock()
	defer mu.Unlock()
	data, err := os.ReadFile(TASKS_FILE)
	if err == nil {
		json.Unmarshal(data, &tasksDb)
	}
}

func saveTasksLocked() {
	data, _ := json.MarshalIndent(tasksDb, "", "  ")
	os.WriteFile(TASKS_FILE, data, 0644)
}

// nextTaskID returns max(existing IDs) + 1.  Must be called with mu held.
func nextTaskID() int {
	maxID := 0
	for _, t := range tasksDb {
		if t.ID > maxID {
			maxID = t.ID
		}
	}
	return maxID + 1
}

func createTask(params map[string]interface{}) string {
	title, _ := params["title"].(string)
	desc, _ := params["description"].(string)
	if title == "" {
		return "Error: 'title' is required."
	}
	priority := 2
	if p, ok := params["priority"].(float64); ok {
		priority = int(p)
	}
	mu.Lock()
	task := Task{
		ID:          nextTaskID(),
		Title:       title,
		Description: desc,
		Status:      "pending",
		Priority:    priority,
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
	}
	tasksDb = append(tasksDb, task)
	saveTasksLocked()
	mu.Unlock()
	auditLog("TASK", fmt.Sprintf("Created task #%d: %s", task.ID, title))
	return fmt.Sprintf("Task #%d created: %s", task.ID, title)
}

func listTasks(params map[string]interface{}) string {
	statusFilter, _ := params["status"].(string)
	if statusFilter == "" {
		statusFilter = "all"
	}
	mu.RLock()
	defer mu.RUnlock()
	var lines []string
	for _, t := range tasksDb {
		if statusFilter != "all" && t.Status != statusFilter {
			continue
		}
		line := fmt.Sprintf("[#%d][%s][P%d] %s", t.ID, t.Status, t.Priority, t.Title)
		if t.Description != "" {
			line += ": " + t.Description
		}
		if t.Result != "" {
			line += " => " + t.Result
		}
		lines = append(lines, line)
	}
	if len(lines) == 0 {
		return fmt.Sprintf("No tasks with status '%s'.", statusFilter)
	}
	return strings.Join(lines, "\n")
}

func updateTask(params map[string]interface{}) string {
	idF, _ := params["id"].(float64)
	id := int(idF)
	status, _ := params["status"].(string)
	result, _ := params["result"].(string)
	if id == 0 {
		return "Error: 'id' is required."
	}
	mu.Lock()
	defer mu.Unlock()
	for i, t := range tasksDb {
		if t.ID == id {
			if status != "" {
				tasksDb[i].Status = status
			}
			if result != "" {
				tasksDb[i].Result = result
			}
			tasksDb[i].UpdatedAt = time.Now()
			saveTasksLocked()
			auditLog("TASK", fmt.Sprintf("Updated task #%d: status=%s", id, tasksDb[i].Status))
			return fmt.Sprintf("Task #%d updated.", id)
		}
	}
	return fmt.Sprintf("Task #%d not found.", id)
}

func completeTask(params map[string]interface{}) string {
	params["status"] = "complete"
	return updateTask(params)
}

// HTTP handlers
func init() {
	registerTool("create_task", createTask)
	registerTool("list_tasks", listTasks)
	registerTool("update_task", updateTask)
	registerTool("complete_task", completeTask)

	http.HandleFunc("/api/tasks", tasksHandler)
	http.HandleFunc("/api/tasks/", taskDetailHandler)
}

func tasksHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	switch r.Method {
	case "GET":
		mu.RLock()
		tasks := make([]Task, len(tasksDb))
		copy(tasks, tasksDb)
		mu.RUnlock()
		json.NewEncoder(w).Encode(tasks)
	case "POST":
		var req struct {
			Title       string `json:"title"`
			Description string `json:"description"`
			Priority    int    `json:"priority"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		if req.Title == "" {
			http.Error(w, `{"error":"title required"}`, 400)
			return
		}
		if req.Priority == 0 {
			req.Priority = 2
		}
		mu.Lock()
		task := Task{
			ID:          nextTaskID(),
			Title:       req.Title,
			Description: req.Description,
			Status:      "pending",
			Priority:    req.Priority,
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
		}
		tasksDb = append(tasksDb, task)
		saveTasksLocked()
		mu.Unlock()
		auditLog("TASK", fmt.Sprintf("Task #%d created via UI: %s", task.ID, task.Title))
		taskQueue <- fmt.Sprintf("TASK #%d: %s\n%s", task.ID, task.Title, task.Description)
		json.NewEncoder(w).Encode(task)
	default:
		http.Error(w, "Method not allowed", 405)
	}
}

func taskDetailHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	pathParts := strings.Split(strings.TrimPrefix(r.URL.Path, "/api/tasks/"), "/")
	if len(pathParts) == 0 || pathParts[0] == "" {
		http.Error(w, "task id required", 400)
		return
	}
	id, err := strconv.Atoi(pathParts[0])
	if err != nil || id == 0 {
		http.Error(w, "invalid task id", 400)
		return
	}

	switch r.Method {
	case "DELETE":
		mu.Lock()
		var newTasks []Task
		found := false
		for _, t := range tasksDb {
			if t.ID == id {
				found = true
				continue
			}
			newTasks = append(newTasks, t)
		}
		if newTasks == nil {
			newTasks = []Task{}
		}
		tasksDb = newTasks
		saveTasksLocked()
		mu.Unlock()
		if found {
			auditLog("TASK", fmt.Sprintf("Task #%d deleted via UI", id))
			json.NewEncoder(w).Encode(map[string]string{"status": "deleted"})
		} else {
			http.Error(w, `{"error":"not found"}`, 404)
		}
	case "PUT", "PATCH":
		var req struct {
			Title       string `json:"title"`
			Description string `json:"description"`
			Status      string `json:"status"`
			Priority    int    `json:"priority"`
			Result      string `json:"result"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		mu.Lock()
		updated := false
		for i, t := range tasksDb {
			if t.ID == id {
				if req.Title != "" {
					tasksDb[i].Title = req.Title
				}
				if req.Description != "" {
					tasksDb[i].Description = req.Description
				}
				if req.Status != "" {
					tasksDb[i].Status = req.Status
				}
				if req.Priority != 0 {
					tasksDb[i].Priority = req.Priority
				}
				if req.Result != "" {
					tasksDb[i].Result = req.Result
				}
				tasksDb[i].UpdatedAt = time.Now()
				updated = true
				break
			}
		}
		saveTasksLocked()
		mu.Unlock()
		if updated {
			auditLog("TASK", fmt.Sprintf("Task #%d updated via UI", id))
			json.NewEncoder(w).Encode(map[string]string{"status": "updated"})
		} else {
			http.Error(w, `{"error":"not found"}`, 404)
		}
	default:
		http.Error(w, "Method not allowed", 405)
	}
}