package main

import (
	"strings"
	"sync"
	"time"
)

// --- DATA STRUCTURES ---
type Config struct {
	// Main LLM
	MainLLMURL   string `json:"main_llm_url"`
	MainLLMModel string `json:"main_llm_model"`
	MainLLMKey   string `json:"main_llm_key"`

	// Expert LLMs (generic)
	LLM1URL       string `json:"llm1_url"`
	LLM1Model     string `json:"llm1_model"`
	LLM1Key       string `json:"llm1_key"`
	LLM1Specialty string `json:"llm1_specialty"`
	LLM1Enabled   bool   `json:"llm1_enabled"`
	LLM1Mode      string `json:"llm1_mode"`       // "using" or "training"
	LLM1ControlURL string `json:"llm1_control_url"`

	LLM2URL       string `json:"llm2_url"`
	LLM2Model     string `json:"llm2_model"`
	LLM2Key       string `json:"llm2_key"`
	LLM2Specialty string `json:"llm2_specialty"`
	LLM2Enabled   bool   `json:"llm2_enabled"`
	LLM2Mode      string `json:"llm2_mode"`
	LLM2ControlURL string `json:"llm2_control_url"`

	LLM3URL       string `json:"llm3_url"`
	LLM3Model     string `json:"llm3_model"`
	LLM3Key       string `json:"llm3_key"`
	LLM3Specialty string `json:"llm3_specialty"`
	LLM3Enabled   bool   `json:"llm3_enabled"`
	LLM3Mode      string `json:"llm3_mode"`
	LLM3ControlURL string `json:"llm3_control_url"`

	// Operational LLM (future use – memory, learning, etc.)
	OpLLMURL       string `json:"op_llm_url"`
	OpLLMModel     string `json:"op_llm_model"`
	OpLLMKey       string `json:"op_llm_key"`
	OpLLMEnabled   bool   `json:"op_llm_enabled"`
	OpLLMMode      string `json:"op_llm_mode"`       // "using" or "training"
	OpLLMControlURL string `json:"op_llm_control_url"`

	// Personality & UI
	Personality string `json:"personality"`
	WebUITitle  string `json:"web_ui_title"`

	// Host credentials
	HostUser string `json:"host_user"`
	HostPass string `json:"host_pass"`

	// LLM timeout (shared across all LLMs)
	LLMTimeoutSec int `json:"llm_timeout_sec"`

	// Web Search
	WebSearchProvider string `json:"web_search_provider"`
	WebSearchKey      string `json:"web_search_key"`
	WebSearchCX       string `json:"web_search_cx"`

	// Social
	DiscordToken     string `json:"discord_token"`
	DiscordChannelID string `json:"discord_channel_id"`
	TwitterKey       string `json:"twitter_key"`
	TwitterSecret    string `json:"twitter_secret"`
	TwitterToken     string `json:"twitter_token"`
	TwitterTokenSec  string `json:"twitter_token_sec"`
	TelegramToken    string `json:"telegram_token"`
	TelegramChatID   string `json:"telegram_chat_id"`
	SlackToken       string `json:"slack_token"`
	SlackChannel     string `json:"slack_channel"`
	WhatsAppSID      string `json:"whatsapp_sid"`
	WhatsAppToken    string `json:"whatsapp_token"`
	WhatsAppFrom     string `json:"whatsapp_from"`
	WhatsAppTo       string `json:"whatsapp_to"`
}

type Message struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type AuditEntry struct {
	Timestamp time.Time `json:"timestamp"`
	Level     string    `json:"level"`
	Content   string    `json:"content"`
}

type Memory struct {
	ID        int       `json:"id"`
	Content   string    `json:"content"`
	Tags      []string  `json:"tags"`
	CreatedAt time.Time `json:"created_at"`
}

type ChatSession struct {
	ID        int          `json:"id"`
	Title     string       `json:"title"`
	CreatedAt time.Time    `json:"created_at"`
	Logs      []AuditEntry `json:"logs"`
}

type ChatMessage struct {
	Role      string    `json:"role"` // "user" | "agent"
	Content   string    `json:"content"`
	Timestamp time.Time `json:"timestamp"`
}

type Task struct {
	ID          int       `json:"id"`
	Title       string    `json:"title"`
	Description string    `json:"description"`
	Status      string    `json:"status"` // pending | running | complete | failed
	Priority    int       `json:"priority"` // 1=high 2=normal 3=low
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
	Result      string    `json:"result,omitempty"`
}

// --- GLOBAL STATE ---
var (
	mu                 sync.RWMutex
	auditLogs          []AuditEntry
	memoryDb           []Memory
	chatSessions       []ChatSession
	chatMessages       []ChatMessage
	tasksDb            []Task
	currentPersonality string

	// Main LLM
	mainLLMURL   string
	mainLLMModel string
	mainLLMKey   string

	// Expert LLMs
	llm1URL, llm1Model, llm1Key, llm1Specialty string
	llm1Enabled bool
	llm1Mode, llm1ControlURL string

	llm2URL, llm2Model, llm2Key, llm2Specialty string
	llm2Enabled bool
	llm2Mode, llm2ControlURL string

	llm3URL, llm3Model, llm3Key, llm3Specialty string
	llm3Enabled bool
	llm3Mode, llm3ControlURL string

	// Operational LLM
	opLLMURL, opLLMModel, opLLMKey string
	opLLMEnabled bool
	opLLMMode, opLLMControlURL string

	// UI
	webUITitle    string
	llmTimeoutSec int

	// Host credentials
	hostUser string
	hostPass string

	// Web Search
	webSearchProvider string
	webSearchKey      string
	webSearchCX       string

	// Social
	discordToken     string
	discordChannelID string
	twitterKey       string
	twitterSecret    string
	twitterToken     string
	twitterTokenSec  string
	telegramToken    string
	telegramChatID   string
	slackToken       string
	slackChannel     string
	whatsAppSID      string
	whatsAppToken    string
	whatsAppFrom     string
	whatsAppTo       string

	// Task queue
	taskQueue = make(chan string, 20)

	// Tools registry (filled by init() in each feature file)
	tools = make(map[string]func(map[string]interface{}) string)
)

// --- HELPER FUNCTIONS (shared) ---
func maskKey(k string) string {
	if k == "" {
		return ""
	}
	if len(k) > 8 {
		return k[:4] + strings.Repeat("*", len(k)-8) + k[len(k)-4:]
	}
	return strings.Repeat("*", len(k))
}

func isAllAsterisks(s string) bool {
	for _, c := range s {
		if c != '*' {
			return false
		}
	}
	return true
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}

// shellQuote wraps s in single quotes, escaping internal single quotes.
func shellQuote(s string) string {
	replaced := strings.ReplaceAll(s, "'", "'"+"\\"+"''")
	return "'" + replaced + "'"
}

// registerTool allows other packages to add their tools to the global map.
func registerTool(name string, fn func(map[string]interface{}) string) {
	tools[name] = fn
}