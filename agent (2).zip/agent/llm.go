package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

// OpenAI-compatible request/response
type OpenAIRequest struct {
	Model    string    `json:"model"`
	Messages []Message `json:"messages"`
}

type OpenAIChoice struct {
	Message Message `json:"message"`
}

type OpenAIResponse struct {
	Choices []OpenAIChoice `json:"choices"`
}

// callLLM sends messages to any OpenAI-compatible endpoint.
func callLLM(urlBase, model, key string, messages []Message) (string, error) {
	if urlBase == "" {
		return "", fmt.Errorf("LLM URL not configured")
	}
	if model == "" {
		return "", fmt.Errorf("LLM model not configured")
	}

	endpoint := strings.TrimRight(urlBase, "/")
	if !strings.HasSuffix(endpoint, "/chat/completions") {
		endpoint += "/v1/chat/completions"
	}

	reqBody := OpenAIRequest{Model: model, Messages: messages}
	jsonData, err := json.Marshal(reqBody)
	if err != nil {
		return "", err
	}

	mu.RLock()
	timeoutSec := llmTimeoutSec
	mu.RUnlock()
	if timeoutSec <= 0 {
		timeoutSec = 300
	}
	// Use a plain client — timeout is enforced via per-request context below.
	client := &http.Client{}

	const maxRetries = 2
	var lastErr error
	for attempt := 0; attempt <= maxRetries; attempt++ {
		if attempt > 0 {
			auditLog("SYSTEM", fmt.Sprintf("LLM retry %d/%d for %s", attempt, maxRetries, model))
			time.Sleep(time.Duration(attempt*2) * time.Second)
		}

		// Fresh context (and cancel) for every attempt so a timeout on one
		// attempt does not bleed into the next.
		ctx, cancel := context.WithTimeout(context.Background(),
			time.Duration(timeoutSec)*time.Second)

		httpReq, err := http.NewRequestWithContext(ctx, "POST", endpoint, bytes.NewBuffer(jsonData))
		if err != nil {
			cancel()
			return "", err
		}
		httpReq.Header.Set("Content-Type", "application/json")
		if key != "" {
			httpReq.Header.Set("Authorization", "Bearer "+key)
		}

		resp, err := client.Do(httpReq)
		cancel() // always release the context, whether success or failure
		if err != nil {
			errStr := err.Error()
			if strings.Contains(errStr, "context deadline exceeded") || strings.Contains(errStr, "Client.Timeout") {
				lastErr = fmt.Errorf("timeout after %ds — model '%s' at %s is not responding. Try increasing timeout or check server.", timeoutSec, model, urlBase)
			} else if strings.Contains(errStr, "connection refused") {
				lastErr = fmt.Errorf("connection refused — is your LLM server running at %s?", urlBase)
			} else if strings.Contains(errStr, "no such host") {
				lastErr = fmt.Errorf("host not found: %s", urlBase)
			} else {
				lastErr = fmt.Errorf("request failed: %v", err)
			}
			continue
		}

		body, _ := io.ReadAll(resp.Body)
		resp.Body.Close()

		if resp.StatusCode == 503 || resp.StatusCode == 502 {
			lastErr = fmt.Errorf("server unavailable (HTTP %d) — model may still be loading", resp.StatusCode)
			continue
		}
		if resp.StatusCode == 404 {
			return "", fmt.Errorf("model '%s' not found (HTTP 404) — pull it first", model)
		}
		if resp.StatusCode != 200 {
			return "", fmt.Errorf("HTTP %d: %s", resp.StatusCode, string(body))
		}

		var openAIResp OpenAIResponse
		if err := json.Unmarshal(body, &openAIResp); err != nil {
			return "", fmt.Errorf("could not parse response: %v", err)
		}
		if len(openAIResp.Choices) == 0 {
			return "", fmt.Errorf("LLM returned no choices")
		}
		return openAIResp.Choices[0].Message.Content, nil
	}
	return "", lastErr
}

// chatWithMainLLM calls the main LLM.
func chatWithMainLLM(messages []Message) (string, error) {
	mu.RLock()
	url, model, key := mainLLMURL, mainLLMModel, mainLLMKey
	mu.RUnlock()
	return callLLM(url, model, key, messages)
}

// callExpertLLM sends a prompt to one of the three expert LLMs (index 1-3).
func callExpertLLM(index int, prompt, system string) (string, error) {
	mu.RLock()
	var url, model, key, mode, controlURL string
	var enabled bool
	switch index {
	case 1:
		url, model, key, enabled, mode, controlURL = llm1URL, llm1Model, llm1Key, llm1Enabled, llm1Mode, llm1ControlURL
	case 2:
		url, model, key, enabled, mode, controlURL = llm2URL, llm2Model, llm2Key, llm2Enabled, llm2Mode, llm2ControlURL
	case 3:
		url, model, key, enabled, mode, controlURL = llm3URL, llm3Model, llm3Key, llm3Enabled, llm3Mode, llm3ControlURL
	default:
		mu.RUnlock()
		return "", fmt.Errorf("invalid expert LLM index %d", index)
	}
	mu.RUnlock()

	if !enabled {
		return "", fmt.Errorf("LLM%d is disabled", index)
	}
	if mode == "training" {
		return "", fmt.Errorf("LLM%d is in training mode", index)
	}
	if url == "" || model == "" {
		return "", fmt.Errorf("LLM%d not fully configured", index)
	}

	messages := []Message{
		{Role: "system", Content: system},
		{Role: "user", Content: prompt},
	}
	return callLLM(url, model, key, messages)
}

// callOperationalLLM calls the operational LLM (index 0).
func callOperationalLLM(prompt, system string) (string, error) {
	mu.RLock()
	url, model, key, enabled, mode := opLLMURL, opLLMModel, opLLMKey, opLLMEnabled, opLLMMode
	mu.RUnlock()

	if !enabled {
		return "", fmt.Errorf("operational LLM is disabled")
	}
	if mode == "training" {
		return "", fmt.Errorf("operational LLM is in training mode")
	}
	if url == "" || model == "" {
		return "", fmt.Errorf("operational LLM not fully configured")
	}

	messages := []Message{
		{Role: "system", Content: system},
		{Role: "user", Content: prompt},
	}
	return callLLM(url, model, key, messages)
}

// controlLLM sends a suspend/wake command to an LLM's control endpoint.
// index: 0 = operational, 1-3 = expert LLMs.
func controlLLM(index int, command string) error {
	mu.RLock()
	var controlURL string
	switch index {
	case 0:
		controlURL = opLLMControlURL
	case 1:
		controlURL = llm1ControlURL
	case 2:
		controlURL = llm2ControlURL
	case 3:
		controlURL = llm3ControlURL
	default:
		mu.RUnlock()
		return fmt.Errorf("invalid LLM index %d", index)
	}
	mu.RUnlock()

	if controlURL == "" {
		return fmt.Errorf("no control URL configured for LLM%d", index)
	}

	payload, _ := json.Marshal(map[string]string{"command": command})
	resp, err := http.Post(controlURL, "application/json", bytes.NewBuffer(payload))
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		body, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("control command failed: %s", string(body))
	}
	return nil
}