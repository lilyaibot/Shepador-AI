package main

import (
	"fmt"
	"time"
)

const (
	HEARTBEAT_INTERVAL = 30 * time.Minute
)

func startHeartbeat() {
	auditLog("SYSTEM", fmt.Sprintf("Heartbeat started. Interval: %v", HEARTBEAT_INTERVAL))
	ticker := time.NewTicker(HEARTBEAT_INTERVAL)
	for range ticker.C {
		auditLog("HEARTBEAT", "Waking up to check for pending tasks...")
		mu.RLock()
		pendingCount := 0
		for _, t := range tasksDb {
			if t.Status == "pending" {
				pendingCount++
			}
		}
		mu.RUnlock()

		// Only enqueue if the agent is idle — avoids stacking maintenance
		// tasks behind a long-running job and growing the queue unboundedly.
		if len(taskQueue) == 0 {
			heartbeatMsg := fmt.Sprintf("AUTONOMOUS MAINTENANCE: Use list_tasks(status=pending) to find pending work and execute it. There are currently %d pending tasks. Review audit logs for any errors.", pendingCount)
			taskQueue <- heartbeatMsg
		} else {
			auditLog("HEARTBEAT", fmt.Sprintf("Agent is busy (%d task(s) queued) — skipping maintenance cycle.", len(taskQueue)))
		}

		mu.RLock()
		hasControlURL := opLLMControlURL != ""
		mu.RUnlock()
		if hasControlURL {
			auditLog("HEARTBEAT", "Sending wake command to operational LLM")
			go controlLLM(0, "wake") // async to not block
		}
	}
}