package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strings"
	"time"
)

func init() {
	registerTool("llm2", llm2Tool)
	http.HandleFunc("/api/llm2_config", llm2ConfigHandler)
	http.HandleFunc("/api/llm2_test", llm2TestHandler)
}

func llm2Tool(params map[string]interface{}) string {
	prompt, _ := params["prompt"].(string)
	if prompt == "" {
		return "Error: 'prompt' argument is required."
	}
	mu.RLock()
	specialty := llm2Specialty
	mu.RUnlock()

	auditLog("LLM2", fmt.Sprintf("Delegating to LLM2 (%s): %s", specialty, truncate(prompt, 80)))
	system := "You are an expert AI. " + specialty
	result, err := callExpertLLM(2, prompt, system)
	if err != nil {
		auditLog("ERROR", fmt.Sprintf("LLM2 error: %v", err))
		return fmt.Sprintf("LLM2 Error: %v", err)
	}
	auditLog("LLM2", fmt.Sprintf("LLM2 responded (%d chars)", len(result)))
	// Save output to documents/llm2/
	timestamp := time.Now().Format("20060102-150405")
	outFile := docPath("llm2", fmt.Sprintf("llm2_%s.md", timestamp))
	os.WriteFile(outFile, []byte(fmt.Sprintf("# LLM2 Output\n**Prompt:** %s\n\n%s", truncate(prompt, 200), result)), 0644)
	auditLog("LLM2", fmt.Sprintf("Saved to %s", outFile))
	return result
}

func llm2ConfigHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method == "GET" {
		mu.Lock()
		data := map[string]interface{}{
			"url":         llm2URL,
			"model":       llm2Model,
			"key":         maskKey(llm2Key),
			"specialty":   llm2Specialty,
			"enabled":     llm2Enabled,
			"mode":        llm2Mode,
			"control_url": llm2ControlURL,
			"timeout":     llmTimeoutSec,
		}
		mu.RUnlock()
		json.NewEncoder(w).Encode(data)
		return
	}
	if r.Method == "POST" {
		var req struct {
			URL        string `json:"url"`
			Model      string `json:"model"`
			Key        string `json:"key"`
			Specialty  string `json:"specialty"`
			Enabled    bool   `json:"enabled"`
			Mode       string `json:"mode"`
			ControlURL string `json:"control_url"`
			Timeout    int    `json:"timeout"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		mu.Lock()
		llm2URL = strings.TrimRight(req.URL, "/")
		llm2Model = req.Model
		if req.Key != "" && !isAllAsterisks(req.Key) {
			llm2Key = req.Key
		}
		llm2Specialty = req.Specialty
		llm2Enabled = req.Enabled
		llm2Mode = req.Mode
		llm2ControlURL = req.ControlURL
		if req.Timeout > 0 {
			llmTimeoutSec = req.Timeout
		}
		saveConfigLocked()
		mu.Unlock()
		auditLog("CONFIG", fmt.Sprintf("LLM2 updated: specialty=%s enabled=%v mode=%s", req.Specialty, req.Enabled, req.Mode))
		json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
		return
	}
	http.Error(w, "Invalid method", 405)
}

func llm2TestHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Invalid method", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	result, err := callExpertLLM(2, "Reply with exactly one sentence confirming you are online and state your model name.", "You are a helpful assistant.")
	if err != nil {
		json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		return
	}
	auditLog("LLM2", "Test connection successful.")
	json.NewEncoder(w).Encode(map[string]string{"response": result})
}